//! Sound-effect lumps and the software mixer that plays them together with
//! music.

use std::sync::Arc;

use crate::music::{Genmidi, MusicPlayer, Song};

/// A decoded sound effect: unsigned 8-bit mono PCM.
#[derive(Clone, Debug)]
pub struct Sound {
    pub rate: u32,
    pub samples: Vec<u8>,
}

impl Sound {
    /// Decode a DMX sound lump (format 3). Like DMX, the 16 padding bytes at
    /// each end of the sample data are skipped.
    pub fn parse_dmx(lump: &[u8]) -> Option<Sound> {
        if lump.len() < 8 || lump[0] != 0x03 || lump[1] != 0x00 {
            return None;
        }
        let rate = u16::from_le_bytes([lump[2], lump[3]]) as u32;
        let length = u32::from_le_bytes([lump[4], lump[5], lump[6], lump[7]]) as usize;
        if length > lump.len() - 8 || length <= 48 || rate == 0 {
            return None;
        }
        Some(Sound { rate, samples: lump[8 + 16..8 + 16 + length - 32].to_vec() })
    }

    /// Duration in seconds.
    pub fn seconds(&self) -> f64 {
        self.samples.len() as f64 / self.rate as f64
    }
}

/// A request from the game thread to the audio thread.
#[derive(Clone, Debug)]
pub enum AudioCommand {
    /// Start `sound` on mixer channel `channel` (replacing what it plays).
    /// `volume` 0..=127, `separation` 0..=255 (128 = centre), as computed by
    /// `S_StartSound`.
    StartSound { channel: usize, sound: Arc<Sound>, volume: i32, separation: i32 },
    UpdateSound { channel: usize, volume: i32, separation: i32 },
    StopSound { channel: usize },
    PlayMusic { song: Arc<Song>, looping: bool },
    StopMusic,
    PauseMusic(bool),
    /// 0..=127.
    SetMusicVolume(u32),
}

#[derive(Clone, Debug)]
struct Voice {
    sound: Arc<Sound>,
    /// Position in source samples, 32.32 fixed point.
    pos: u64,
    step: u64,
    left: f32,
    right: f32,
}

/// Mixes sound-effect channels and music into interleaved stereo `f32`.
pub struct Mixer {
    rate: u32,
    voices: Vec<Option<Voice>>,
    music: Option<MusicPlayer>,
    music_buf: Vec<i16>,
    /// DC blocker state per channel (x[n-1], y[n-1]).
    dc: [(f32, f32); 2],
    dc_r: f32,
}

impl Mixer {
    /// `genmidi`: the instrument bank; without one, music is silent.
    pub fn new(rate: u32, channels: usize, genmidi: Option<Arc<Genmidi>>) -> Self {
        Mixer {
            rate,
            voices: vec![None; channels],
            music: genmidi.map(|g| MusicPlayer::new(g, rate)),
            music_buf: Vec::new(),
            dc: [(0.0, 0.0); 2],
            // One-pole high-pass at ~3 Hz.
            dc_r: 1.0 - (2.0 * std::f32::consts::PI * 3.0 / rate as f32),
        }
    }

    pub fn sample_rate(&self) -> u32 {
        self.rate
    }

    /// `I_UpdateSoundParams` (i_sdlsound.c): DMX separation to SDL_mixer
    /// panning gains.
    fn gains(volume: i32, separation: i32) -> (f32, f32) {
        let left = ((254 - separation) * volume / 127).clamp(0, 255);
        let right = (separation * volume / 127).clamp(0, 255);
        (left as f32 / 255.0, right as f32 / 255.0)
    }

    pub fn apply(&mut self, cmd: AudioCommand) {
        match cmd {
            AudioCommand::StartSound { channel, sound, volume, separation } => {
                if channel >= self.voices.len() {
                    return;
                }
                let (left, right) = Self::gains(volume, separation);
                let step = ((sound.rate as u64) << 32) / self.rate as u64;
                self.voices[channel] = Some(Voice { sound, pos: 0, step, left, right });
            }
            AudioCommand::UpdateSound { channel, volume, separation } => {
                if let Some(Some(v)) = self.voices.get_mut(channel) {
                    (v.left, v.right) = Self::gains(volume, separation);
                }
            }
            AudioCommand::StopSound { channel } => {
                if let Some(v) = self.voices.get_mut(channel) {
                    *v = None;
                }
            }
            AudioCommand::PlayMusic { song, looping } => {
                if let Some(m) = &mut self.music {
                    m.play(song, looping);
                }
            }
            AudioCommand::StopMusic => {
                if let Some(m) = &mut self.music {
                    m.stop();
                }
            }
            AudioCommand::PauseMusic(p) => {
                if let Some(m) = &mut self.music {
                    m.set_paused(p);
                }
            }
            AudioCommand::SetMusicVolume(v) => {
                if let Some(m) = &mut self.music {
                    m.set_volume(v);
                }
            }
        }
    }

    /// Fill `out` (interleaved stereo) with the next samples.
    pub fn render(&mut self, out: &mut [f32]) {
        let frames = out.len() / 2;
        out.fill(0.0);
        if let Some(m) = &mut self.music {
            self.music_buf.resize(frames * 2, 0);
            m.render(&mut self.music_buf);
            // The OPL's half/absolute-sine waveforms carry DC; sound cards
            // AC-couple their output, so block it here.
            for (i, (o, &s)) in out.iter_mut().zip(&self.music_buf).enumerate() {
                let x = s as f32 / 32768.0;
                let (x1, y1) = &mut self.dc[i & 1];
                let y = x - *x1 + self.dc_r * *y1;
                *x1 = x;
                *y1 = y;
                *o = y;
            }
        }
        for slot in &mut self.voices {
            let Some(v) = slot else { continue };
            let n = v.sound.samples.len() as u64;
            for frame in out.chunks_exact_mut(2) {
                let i = (v.pos >> 32) as usize;
                if i as u64 >= n {
                    *slot = None;
                    break;
                }
                // Linear interpolation between neighbouring samples.
                let a = v.sound.samples[i] as f32 - 128.0;
                let b = v.sound.samples.get(i + 1).map_or(a, |&b| b as f32 - 128.0);
                let t = (v.pos & 0xffff_ffff) as f32 / 4294967296.0;
                let s = (a + (b - a) * t) / 128.0;
                frame[0] += s * v.left;
                frame[1] += s * v.right;
                v.pos += v.step;
            }
        }
        for o in out.iter_mut() {
            *o = o.clamp(-1.0, 1.0);
        }
    }
}

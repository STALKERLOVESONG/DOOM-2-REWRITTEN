#!/bin/sh
# Record reference per-tic traces of the IWAD's demos with refdoom.
# Usage: tools/refdoom/gen_demo_fixtures.sh <refdoom binary> <iwad>
# Writes crates/doom_sim/tests/fixtures/<DEMOn>.trace, each starting with a
# line "iwad <fnv1a64 of the IWAD>" so tests skip on a different IWAD.
set -e
BIN=$(cd "$(dirname "$1")" && pwd)/$(basename "$1")
IWAD=$(cd "$(dirname "$2")" && pwd)/$(basename "$2")
HERE=$(cd "$(dirname "$0")" && pwd)
OUT="$HERE/../../crates/doom_sim/tests/fixtures"
mkdir -p "$OUT"
HASH=$(python3 -c "
import sys
h=0xcbf29ce484222325
for b in open(sys.argv[1],'rb').read():
    h=((h^b)*0x100000001b3)&0xffffffffffffffff
print('%016x'%h)" "$IWAD")
TMP=$(mktemp -d)
for d in 1 2 3 4; do
    ( cd "$TMP" && HOME="$TMP" REFDOOM_OUT="$TMP/t.txt" "$BIN" -iwad "$IWAD" -timedemo demo$d -nodraw -nosound -nomusic >/dev/null 2>&1 ) || true
    if [ -s "$TMP/t.txt" ]; then
        { echo "iwad $HASH"; cat "$TMP/t.txt"; } > "$OUT/DEMO$d.trace"
        echo "DEMO$d: $(wc -l < "$TMP/t.txt") tics"
    fi
    rm -f "$TMP/t.txt"
done
rm -rf "$TMP"

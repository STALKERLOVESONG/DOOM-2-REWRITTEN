//! Bevy host for the doom_* engine crates.
//!
//! cargo run --release -- --iwad WADS/doom1.wad [--pwad mod.wad ...] [--map E1M1] [--skill 3]
//!
//! The host owns the window, input devices and presentation only. The game
//! runs in `doom_game::Session` at a fixed 35 Hz (`FixedUpdate`); every frame
//! the session renders its 320x200 software framebuffer, which is uploaded
//! to a texture and drawn as a 4:3 sprite. There is no sound yet.
//!
//! Controls: WASD move/strafe, arrows turn, mouse turn, Shift run, Alt +
//! turn = strafe, Ctrl / left mouse fire, Space / E / right mouse use,
//! 1-7 weapons, -/= view size, F5 detail, Pause / F12 pause, Esc release the
//! mouse (click to grab again), F6 skip to the next map, F10 quit.
//! Vanilla cheat codes can be typed (iddqd, idkfa, idfa, idclip, idclevXY).

use std::path::PathBuf;

use bevy::input::mouse::AccumulatedMouseMotion;
use bevy::input::keyboard::KeyboardInput;
use bevy::input::ButtonState;
use bevy::input::InputSystem;
use bevy::prelude::*;
use bevy::render::render_asset::RenderAssetUsages;
use bevy::render::render_resource::{Extent3d, TextureDimension, TextureFormat};
use bevy::window::{CursorGrabMode, PrimaryWindow, WindowResolution};
use clap::Parser;
use doom_game::{CheatMatcher, InputState, Session, SessionConfig, TICRATE};
use doom_render::{SCREENHEIGHT, SCREENWIDTH};
use doom_sim::Skill;

#[derive(Parser, Debug)]
#[command(about = "Doom engine (Rust + Bevy)")]
struct Args {
    /// IWAD path. Default: WADS/doom1.wad, doom1.wad, or $DOOMWADDIR/doom1.wad.
    #[arg(long)]
    iwad: Option<PathBuf>,
    /// PWADs loaded on top of the IWAD, in order.
    #[arg(long, num_args = 1..)]
    pwad: Vec<PathBuf>,
    /// Starting map: E1M1, MAP01, "1 1" ...
    #[arg(long)]
    map: Option<String>,
    /// 1 = I'm too young to die ... 5 = Nightmare!
    #[arg(long, default_value_t = 3, value_parser = clap::value_parser!(u8).range(1..=5))]
    skill: u8,
    #[arg(long)]
    nomonsters: bool,
    #[arg(long)]
    fast: bool,
    #[arg(long)]
    respawn: bool,
    /// Play back a demo (lump name like DEMO1, or a .lmp path).
    #[arg(long)]
    playdemo: Option<String>,
    /// Window size as a multiple of 320x240.
    #[arg(long, default_value_t = 3)]
    scale: u32,
    /// Mouse sensitivity multiplier (1.0 = vanilla units per mouse count).
    #[arg(long, default_value_t = 1.0)]
    sensitivity: f32,
    /// Let vertical mouse movement walk forward/back (vanilla default; off here).
    #[arg(long)]
    mouse_move: bool,
    /// View size 3..=11 as in the vanilla menu (11 = full screen).
    #[arg(long, default_value_t = 11)]
    screen_size: i32,
    #[arg(long)]
    low_detail: bool,
}

fn find_iwad(arg: Option<PathBuf>) -> Option<PathBuf> {
    if let Some(p) = arg {
        return Some(p);
    }
    let mut candidates = vec![PathBuf::from("WADS/doom1.wad"), PathBuf::from("doom1.wad")];
    if let Some(dir) = std::env::var_os("DOOMWADDIR") {
        candidates.push(PathBuf::from(dir).join("doom1.wad"));
    }
    candidates.into_iter().find(|p| p.exists())
}

fn main() {
    let args = Args::parse();
    let Some(iwad) = find_iwad(args.iwad.clone()) else {
        eprintln!("no IWAD found: pass --iwad <path> (or put doom1.wad in WADS/)");
        std::process::exit(1);
    };
    let cfg = SessionConfig {
        iwad,
        pwads: args.pwad.clone(),
        map: args.map.clone(),
        skill: [Skill::Baby, Skill::Easy, Skill::Medium, Skill::Hard, Skill::Nightmare][args.skill as usize - 1],
        nomonsters: args.nomonsters,
        fast: args.fast,
        respawn: args.respawn,
        demo: args.playdemo.clone(),
    };
    let mut session = match Session::new(&cfg) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("error: {e}");
            std::process::exit(1);
        }
    };
    for w in session.warnings.iter().take(20) {
        eprintln!("warning: {w}");
    }
    session.set_view(args.screen_size, args.low_detail);

    let scale = args.scale.max(1) as f32;
    App::new()
        .add_plugins(
            DefaultPlugins
                .set(WindowPlugin {
                    primary_window: Some(Window {
                        title: "doom_bevy".into(),
                        resolution: WindowResolution::new(320.0 * scale, 240.0 * scale),
                        ..default()
                    }),
                    ..default()
                })
                // The framebuffer is upscaled with nearest filtering.
                .set(ImagePlugin::default_nearest()),
        )
        .insert_resource(ClearColor(Color::BLACK))
        .insert_resource(Time::<Fixed>::from_hz(TICRATE as f64))
        .insert_resource(Game(session))
        .insert_resource(Settings {
            sensitivity: args.sensitivity,
            mouse_move: args.mouse_move,
            screen_size: args.screen_size.clamp(3, 11),
            low_detail: args.low_detail,
        })
        .init_resource::<PendingInput>()
        .init_resource::<Cheats>()
        .add_systems(Startup, setup)
        .add_systems(PreUpdate, gather_input.after(InputSystem))
        .add_systems(FixedUpdate, run_tic)
        .add_systems(Update, (host_keys, mouse_grab, present, fit_to_window, update_hud, update_title))
        .run();
}

#[derive(Resource)]
struct Game(Session);

#[derive(Resource)]
struct Settings {
    sensitivity: f32,
    mouse_move: bool,
    screen_size: i32,
    low_detail: bool,
}

/// Input gathered every frame and consumed by the next tic, so short key
/// presses and mouse motion are not lost when a frame runs zero tics.
#[derive(Resource, Default)]
struct PendingInput {
    mouse: Vec2,
    weapon: Option<u8>,
    paused: bool,
}

#[derive(Resource, Default)]
struct Cheats(CheatMatcher);

#[derive(Resource)]
struct Framebuffer(Handle<Image>);

#[derive(Component)]
struct Screen;

#[derive(Component)]
enum HudText {
    Status,
    Message,
    Info,
}

fn setup(mut commands: Commands, mut images: ResMut<Assets<Image>>) {
    commands.spawn(Camera2d);
    let image = Image::new_fill(
        Extent3d { width: SCREENWIDTH as u32, height: SCREENHEIGHT as u32, depth_or_array_layers: 1 },
        TextureDimension::D2,
        &[0, 0, 0, 255],
        // PLAYPAL values are sRGB-encoded.
        TextureFormat::Rgba8UnormSrgb,
        RenderAssetUsages::MAIN_WORLD | RenderAssetUsages::RENDER_WORLD,
    );
    let handle = images.add(image);
    commands.spawn((Sprite::from_image(handle.clone()), Screen));
    commands.insert_resource(Framebuffer(handle));

    let font = |size: f32| TextFont { font_size: size, ..default() };
    let red = TextColor(Color::srgb(0.9, 0.2, 0.15));
    commands.spawn((
        Text::new(""),
        font(26.0),
        red,
        Node { position_type: PositionType::Absolute, left: Val::Px(12.0), bottom: Val::Px(8.0), ..default() },
        HudText::Status,
    ));
    commands.spawn((
        Text::new(""),
        font(18.0),
        red,
        Node { position_type: PositionType::Absolute, left: Val::Px(12.0), top: Val::Px(8.0), ..default() },
        HudText::Message,
    ));
    commands.spawn((
        Text::new(""),
        font(16.0),
        TextColor(Color::srgb(0.85, 0.85, 0.85)),
        Node { position_type: PositionType::Absolute, right: Val::Px(12.0), top: Val::Px(8.0), ..default() },
        HudText::Info,
    ));
}

fn key_char(k: KeyCode) -> Option<char> {
    use KeyCode::*;
    let letters = [
        KeyA, KeyB, KeyC, KeyD, KeyE, KeyF, KeyG, KeyH, KeyI, KeyJ, KeyK, KeyL, KeyM, KeyN, KeyO, KeyP, KeyQ, KeyR,
        KeyS, KeyT, KeyU, KeyV, KeyW, KeyX, KeyY, KeyZ,
    ];
    let digits = [Digit0, Digit1, Digit2, Digit3, Digit4, Digit5, Digit6, Digit7, Digit8, Digit9];
    if let Some(i) = letters.iter().position(|&l| l == k) {
        return Some((b'a' + i as u8) as char);
    }
    digits.iter().position(|&d| d == k).map(|i| (b'0' + i as u8) as char)
}

/// Runs after Bevy's input systems each frame.
fn gather_input(
    mut pending: ResMut<PendingInput>,
    mut cheats: ResMut<Cheats>,
    mut game: ResMut<Game>,
    mut keys_ev: EventReader<KeyboardInput>,
    motion: Res<AccumulatedMouseMotion>,
    settings: Res<Settings>,
    windows: Query<&Window, With<PrimaryWindow>>,
) {
    let grabbed = windows.single().is_ok_and(|w| w.cursor_options.grab_mode != CursorGrabMode::None);
    if grabbed {
        pending.mouse += motion.delta * settings.sensitivity;
    }
    for ev in keys_ev.read() {
        if ev.state != ButtonState::Pressed || ev.repeat {
            continue;
        }
        let Some(c) = key_char(ev.key_code) else { continue };
        if let Some(d) = c.to_digit(10).filter(|d| (1..=7).contains(d)) {
            pending.weapon = Some(d as u8 - 1);
        }
        if let Some(cheat) = cheats.0.feed(c) {
            game.0.apply_cheat(&cheat);
        }
    }
}

fn run_tic(
    mut game: ResMut<Game>,
    mut pending: ResMut<PendingInput>,
    keys: Res<ButtonInput<KeyCode>>,
    mouse: Res<ButtonInput<MouseButton>>,
    settings: Res<Settings>,
) {
    if pending.paused {
        return;
    }
    let k = |c: KeyCode| keys.pressed(c);
    let alt = k(KeyCode::AltLeft) || k(KeyCode::AltRight);
    let m = std::mem::take(&mut pending.mouse);
    let mouse_x = m.x.round() as i32;
    // Keep the fractional part for the next tic.
    pending.mouse.x = m.x - mouse_x as f32;
    let input = InputState {
        forward: k(KeyCode::KeyW) || k(KeyCode::ArrowUp),
        backward: k(KeyCode::KeyS) || k(KeyCode::ArrowDown),
        turn_left: k(KeyCode::ArrowLeft),
        turn_right: k(KeyCode::ArrowRight),
        strafe_left: k(KeyCode::KeyA) || k(KeyCode::Comma),
        strafe_right: k(KeyCode::KeyD) || k(KeyCode::Period),
        strafe: alt,
        speed: k(KeyCode::ShiftLeft) || k(KeyCode::ShiftRight),
        fire: k(KeyCode::ControlLeft) || k(KeyCode::ControlRight) || mouse.pressed(MouseButton::Left),
        use_: k(KeyCode::Space) || k(KeyCode::KeyE) || mouse.pressed(MouseButton::Right),
        weapon: pending.weapon.take(),
        mouse_x,
        // Screen y grows downwards; vanilla moves forward on mouse-up.
        mouse_y: if settings.mouse_move { -(m.y.round() as i32) } else { 0 },
        ..default()
    };
    game.0.tick(&input);
    // No audio backend yet: drop sound events.
    game.0.take_events();
}

fn host_keys(
    keys: Res<ButtonInput<KeyCode>>,
    mut game: ResMut<Game>,
    mut settings: ResMut<Settings>,
    mut pending: ResMut<PendingInput>,
    mut exit: EventWriter<AppExit>,
) {
    if keys.just_pressed(KeyCode::F10) {
        exit.write(AppExit::Success);
    }
    // Not P: it appears in typed cheats (idspispopd).
    if keys.just_pressed(KeyCode::Pause) || keys.just_pressed(KeyCode::F12) {
        pending.paused = !pending.paused;
    }
    if keys.just_pressed(KeyCode::F6) {
        game.0.exit_level();
    }
    let mut view_changed = false;
    if keys.just_pressed(KeyCode::Minus) || keys.just_pressed(KeyCode::NumpadSubtract) {
        settings.screen_size = (settings.screen_size - 1).max(3);
        view_changed = true;
    }
    if keys.just_pressed(KeyCode::Equal) || keys.just_pressed(KeyCode::NumpadAdd) {
        settings.screen_size = (settings.screen_size + 1).min(11);
        view_changed = true;
    }
    if keys.just_pressed(KeyCode::F5) {
        settings.low_detail = !settings.low_detail;
        view_changed = true;
    }
    if view_changed {
        game.0.set_view(settings.screen_size, settings.low_detail);
    }
}

fn mouse_grab(
    mut windows: Query<&mut Window, With<PrimaryWindow>>,
    mouse: Res<ButtonInput<MouseButton>>,
    keys: Res<ButtonInput<KeyCode>>,
) {
    let Ok(mut window) = windows.single_mut() else { return };
    if mouse.just_pressed(MouseButton::Left) && window.focused {
        window.cursor_options.grab_mode = CursorGrabMode::Locked;
        window.cursor_options.visible = false;
    }
    if keys.just_pressed(KeyCode::Escape) || !window.focused {
        window.cursor_options.grab_mode = CursorGrabMode::None;
        window.cursor_options.visible = true;
    }
}

/// Render the current game state into the framebuffer texture.
fn present(mut game: ResMut<Game>, fb: Res<Framebuffer>, mut images: ResMut<Assets<Image>>) {
    let Some(image) = images.get_mut(&fb.0) else { return };
    let Some(data) = image.data.as_mut() else { return };
    game.0.render_rgba(data);
}

/// Scale the 320x200 framebuffer to the largest 4:3 rectangle that fits:
/// Doom's pixels are 20% taller than wide on the CRTs it was made for.
fn fit_to_window(windows: Query<&Window, With<PrimaryWindow>>, mut screen: Query<&mut Sprite, With<Screen>>) {
    let (Ok(window), Ok(mut sprite)) = (windows.single(), screen.single_mut()) else { return };
    let unit = (window.width() / 4.0).min(window.height() / 3.0);
    let size = Vec2::new(unit * 4.0, unit * 3.0);
    if sprite.custom_size != Some(size) {
        sprite.custom_size = Some(size);
    }
}

fn update_hud(game: Res<Game>, pending: Res<PendingInput>, mut texts: Query<(&mut Text, &HudText)>) {
    let hud = game.0.hud();
    for (mut text, kind) in &mut texts {
        let s = match kind {
            HudText::Status => {
                let ammo = hud.ammo.map_or("--".to_string(), |(a, _)| a.to_string());
                let keys: String = ["B", "Y", "R", "b", "y", "r"]
                    .iter()
                    .zip(hud.keys)
                    .filter(|(_, have)| *have)
                    .map(|(k, _)| *k)
                    .collect();
                format!("HEALTH {}%   ARMOR {}%   AMMO {}   {:?}   {}", hud.health, hud.armor, ammo, hud.weapon, keys)
            }
            HudText::Message => {
                let mut m = hud.message.clone().unwrap_or_default();
                if hud.dead {
                    m = "You died. Press Use to restart the level.".into();
                }
                if pending.paused {
                    m = "PAUSED".into();
                }
                m
            }
            HudText::Info => {
                let flags = match (hud.god, hud.noclip) {
                    (true, true) => " [god, noclip]",
                    (true, false) => " [god]",
                    (false, true) => " [noclip]",
                    _ => "",
                };
                format!(
                    "{}{}  {}:{:02}\nK {}/{}  I {}/{}  S {}/{}",
                    hud.map,
                    flags,
                    hud.level_seconds / 60,
                    hud.level_seconds % 60,
                    hud.kills.0,
                    hud.kills.1,
                    hud.items.0,
                    hud.items.1,
                    hud.secrets.0,
                    hud.secrets.1
                )
            }
        };
        if text.0 != s {
            text.0 = s;
        }
    }
}

fn update_title(game: Res<Game>, mut windows: Query<&mut Window, With<PrimaryWindow>>) {
    let Ok(mut window) = windows.single_mut() else { return };
    let title = format!("doom_bevy - {}{}", game.0.map_name(), if game.0.is_demo() { " (demo)" } else { "" });
    if window.title != title {
        window.title = title;
    }
}

//! Actor definitions: sprites, states, mobj types, sounds (info.c/info.h,
//! sounds.c/sounds.h).
//!
//! The default tables are generated from the reference source
//! (`tools/gen_info.py`). The simulation uses an [`Info`] instance — a
//! mutable copy — so content patches (DEHACKED now, DECORATE later) can
//! modify or extend it without touching gameplay code.

mod generated;

pub use generated::*;

use doom_core::Fixed;

macro_rules! num_type {
    ($(#[$m:meta])* $name:ident) => {
        $(#[$m])*
        #[derive(Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Debug, Default)]
        pub struct $name(pub u16);

        impl $name {
            #[inline]
            pub const fn idx(self) -> usize {
                self.0 as usize
            }
        }
    };
}

num_type!(SpriteNum);
num_type!(StateNum);
num_type!(MobjType);
num_type!(SfxNum);
num_type!(MusicNum);

/// Frame flag: draw at full brightness (`FF_FULLBRIGHT`).
pub const FF_FULLBRIGHT: i32 = 0x8000;
/// Frame number mask (`FF_FRAMEMASK`).
pub const FF_FRAMEMASK: i32 = 0x7fff;

/// `state_t`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct State {
    pub sprite: SpriteNum,
    /// Frame index, possibly ORed with [`FF_FULLBRIGHT`].
    pub frame: i32,
    /// Duration in tics; -1 = forever.
    pub tics: i32,
    pub action: Action,
    pub next: StateNum,
    pub misc1: i32,
    pub misc2: i32,
}

/// `mobjinfo_t`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MobjInfo {
    /// Editor number used in THINGS (-1 = not placeable).
    pub doomednum: i32,
    pub spawnstate: StateNum,
    pub spawnhealth: i32,
    pub seestate: StateNum,
    pub seesound: SfxNum,
    pub reactiontime: i32,
    pub attacksound: SfxNum,
    pub painstate: StateNum,
    pub painchance: i32,
    pub painsound: SfxNum,
    pub meleestate: StateNum,
    pub missilestate: StateNum,
    pub deathstate: StateNum,
    pub xdeathstate: StateNum,
    pub deathsound: SfxNum,
    /// Map units per step for monsters, fixed point per tic for missiles
    /// (the C code uses the same `int` both ways).
    pub speed: i32,
    pub radius: Fixed,
    pub height: Fixed,
    pub mass: i32,
    pub damage: i32,
    pub activesound: SfxNum,
    pub flags: u32,
    pub raisestate: StateNum,
}

/// `sfxinfo_t` (static part).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct SfxInfo {
    /// Lump name without the `DS`/`DP` prefix.
    pub name: &'static str,
    pub priority: i32,
    /// Linked sound (e.g. `chgun` plays `pistol` at a different pitch).
    pub link: Option<SfxNum>,
    pub pitch: i32,
    pub volume: i32,
}

/// Runtime actor tables.
#[derive(Clone, Debug)]
pub struct Info {
    pub sprnames: Vec<String>,
    pub states: Vec<State>,
    pub mobjinfo: Vec<MobjInfo>,
    pub sfx: Vec<SfxInfo>,
}

impl Info {
    /// The vanilla Doom tables.
    pub fn doom() -> Self {
        Self {
            sprnames: SPRNAMES.iter().map(|s| s.to_string()).collect(),
            states: DEFAULT_STATES.to_vec(),
            mobjinfo: DEFAULT_MOBJINFO.to_vec(),
            sfx: DEFAULT_SFX.to_vec(),
        }
    }

    #[inline]
    pub fn state(&self, s: StateNum) -> &State {
        &self.states[s.idx()]
    }

    #[inline]
    pub fn mobj(&self, t: MobjType) -> &MobjInfo {
        &self.mobjinfo[t.idx()]
    }

    /// Linear search by editor number, like `P_SpawnMapThing` (first match).
    pub fn type_for_doomednum(&self, doomednum: i32) -> Option<MobjType> {
        self.mobjinfo.iter().position(|m| m.doomednum == doomednum).map(|i| MobjType(i as u16))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tables_line_up() {
        let info = Info::doom();
        assert_eq!(info.states.len(), NUMSTATES);
        assert_eq!(info.mobj(MT_PLAYER).spawnstate, S_PLAY);
        assert_eq!(info.mobj(MT_PLAYER).radius, Fixed::from_int(16));
        assert_eq!(info.type_for_doomednum(3004), Some(MT_POSSESSED));
        assert_eq!(info.sprnames[SPR_TROO.idx()], "TROO");
        assert_eq!(info.state(S_PLAY_RUN1).next, S_PLAY_RUN2);
        assert_eq!(info.sfx[SFX_CHGUN.idx()].link, Some(SFX_PISTOL));
    }
}

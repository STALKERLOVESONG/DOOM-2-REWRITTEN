//! Host-independent game layer.
//!
//! Everything a front end needs that is not windowing, input devices, audio
//! output or GPU upload: loading content, starting games, running tics,
//! level progression, palette effects, HUD data, developer cheats. The Bevy
//! host is a thin shell over [`Session`]; tools and tests use it headless.

pub mod cheats;
pub mod maps;
pub mod session;

pub use doom_sim::ticcmd::InputState;
pub use cheats::{Cheat, CheatMatcher};
pub use maps::MapRef;
pub use session::{Hud, Session, SessionConfig, TICRATE};

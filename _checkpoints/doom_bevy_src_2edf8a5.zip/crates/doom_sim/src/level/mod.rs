//! Runtime level data (r_defs.h): the map as the simulation and renderer see
//! it after `P_SetupLevel`.

mod setup;

use doom_core::{Angle, BBox, Fixed};

use crate::ids::*;

pub use setup::{LevelLoadError, LevelResources};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Vertex {
    pub x: Fixed,
    pub y: Fixed,
}

/// `degenmobj_t`: a sector's sound origin.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct SoundOrigin {
    pub x: Fixed,
    pub y: Fixed,
    pub z: Fixed,
}

#[derive(Clone, Debug)]
pub struct Sector {
    pub floor_height: Fixed,
    pub ceiling_height: Fixed,
    pub floor_pic: FlatNum,
    pub ceiling_pic: FlatNum,
    pub light_level: i16,
    pub special: i16,
    pub tag: i16,
    /// 0 = untraversed, 1, 2 = sound lines - 1 (`P_RecursiveSound`).
    pub sound_traversed: i32,
    /// Thing that made a sound (monsters wake up on it).
    pub sound_target: Option<MobjId>,
    /// Blockmap bounding box (block coords) used for height changes.
    pub blockbox: [i32; 4],
    pub sound_org: SoundOrigin,
    /// Head of the sector's thing list (`thinglist`, linked via mobj `snext`).
    pub thing_list: Option<MobjId>,
    /// Active floor/ceiling mover (`specialdata`).
    pub special_data: Option<ThinkerId>,
    /// Range into [`Level::sector_lines`] (`lines`/`linecount`).
    pub lines_start: u32,
    pub line_count: u32,
}

#[derive(Clone, Debug)]
pub struct Side {
    pub texture_offset: Fixed,
    pub row_offset: Fixed,
    pub top_texture: TexNum,
    pub bottom_texture: TexNum,
    pub mid_texture: TexNum,
    pub sector: SectorId,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SlopeType {
    Horizontal,
    Vertical,
    Positive,
    Negative,
}

#[derive(Clone, Debug)]
pub struct Line {
    pub v1: VertexId,
    pub v2: VertexId,
    /// Precalculated `v2 - v1`.
    pub dx: Fixed,
    pub dy: Fixed,
    pub flags: u16,
    pub special: i16,
    pub tag: i16,
    /// Front and back sidedefs (`sidenum[2]`, `-1` -> `None`).
    pub sidenum: [Option<SideId>; 2],
    pub bbox: BBox,
    pub slope_type: SlopeType,
    pub front_sector: Option<SectorId>,
    pub back_sector: Option<SectorId>,
    /// Active special thinker (`specialdata`); used by some line actions.
    pub special_data: Option<ThinkerId>,
}

impl Line {
    #[inline]
    pub fn is_two_sided(&self) -> bool {
        self.sidenum[1].is_some()
    }
}

#[derive(Clone, Debug)]
pub struct Seg {
    pub v1: VertexId,
    pub v2: VertexId,
    pub offset: Fixed,
    pub angle: Angle,
    pub sidedef: SideId,
    pub linedef: LineId,
    pub front_sector: SectorId,
    /// `None` for one-sided lines. For the "glass hack" (two-sided flag with
    /// a missing back sidedef) this points at [`Level::null_sector`].
    pub back_sector: Option<SectorId>,
}

#[derive(Clone, Debug)]
pub struct Subsector {
    pub sector: SectorId,
    pub num_lines: u16,
    pub first_line: u16,
}

/// Child index flag: the child is a subsector.
pub const NF_SUBSECTOR: u16 = doom_content::map::NF_SUBSECTOR;

#[derive(Clone, Debug)]
pub struct Node {
    pub x: Fixed,
    pub y: Fixed,
    pub dx: Fixed,
    pub dy: Fixed,
    /// Bounding box per child (right = 0, left = 1).
    pub bbox: [BBox; 2],
    /// Child node index, or subsector index with [`NF_SUBSECTOR`] set.
    pub children: [u16; 2],
}

pub const MAPBLOCKUNITS: i32 = 128;
pub const MAPBLOCKSIZE: i32 = MAPBLOCKUNITS * doom_core::FRACUNIT;
pub const MAPBLOCKSHIFT: u32 = doom_core::FRACBITS as u32 + 7;
pub const MAPBMASK: i32 = MAPBLOCKSIZE - 1;
pub const MAPBTOFRAC: u32 = MAPBLOCKSHIFT - doom_core::FRACBITS as u32;
/// Largest thing radius, used to pad sector block boxes.
pub const MAXRADIUS: Fixed = Fixed(32 * doom_core::FRACUNIT);

/// The BLOCKMAP lump plus the per-block mobj chains (`blocklinks`).
#[derive(Clone, Debug)]
pub struct Blockmap {
    pub org_x: Fixed,
    pub org_y: Fixed,
    pub width: i32,
    pub height: i32,
    /// The whole lump as 16-bit words (`blockmaplump`). Block `i`'s line list
    /// starts at word offset `lump[4 + i]`.
    pub lump: Vec<i16>,
    /// Head of each block's mobj chain (linked via mobj `bnext`).
    pub links: Vec<Option<MobjId>>,
}

impl Blockmap {
    /// Raw line-list words for block (x, y), starting at the list's first
    /// entry and ending before the `-1` terminator.
    ///
    /// Vanilla quirk preserved: every list begins with a `0` delimiter that
    /// `P_BlockLinesIterator` does *not* skip, so linedef 0 is visited from
    /// every block.
    ///
    /// Out-of-range offsets (corrupt or >64K blockmaps) yield an empty list
    /// instead of reading arbitrary memory.
    pub fn block_list(&self, x: i32, y: i32) -> &[i16] {
        if x < 0 || y < 0 || x >= self.width || y >= self.height {
            return &[];
        }
        let Some(&offset) = self.lump.get(4 + (y * self.width + x) as usize) else {
            return &[];
        };
        // C: `offset` is an int read from a short (sign-extended).
        let start = offset as i32;
        if start < 0 || start as usize >= self.lump.len() {
            return &[];
        }
        let list = &self.lump[start as usize..];
        let end = list.iter().position(|&w| w == -1).unwrap_or(list.len());
        &list[..end]
    }

    /// Block coordinate for a map coordinate: `(v - org) >> MAPBLOCKSHIFT`.
    #[inline]
    pub fn block_x(&self, x: Fixed) -> i32 {
        (x - self.org_x).0 >> MAPBLOCKSHIFT
    }
    #[inline]
    pub fn block_y(&self, y: Fixed) -> i32 {
        (y - self.org_y).0 >> MAPBLOCKSHIFT
    }
}

/// Level-wide `validcount` bookkeeping. Kept apart from the geometry so that
/// iteration helpers can mutate it while callbacks read the level.
#[derive(Clone, Debug, Default)]
pub struct ValidCount {
    pub current: i32,
    pub lines: Vec<i32>,
    pub sectors: Vec<i32>,
}

impl ValidCount {
    pub fn new(num_lines: usize, num_sectors: usize) -> Self {
        Self { current: 0, lines: vec![0; num_lines], sectors: vec![0; num_sectors] }
    }

    /// `validcount++`.
    #[inline]
    pub fn bump(&mut self) {
        self.current = self.current.wrapping_add(1);
    }
}

#[derive(Clone, Debug)]
pub struct Level {
    pub name: String,
    pub vertexes: Vec<Vertex>,
    pub sectors: Vec<Sector>,
    pub sides: Vec<Side>,
    pub lines: Vec<Line>,
    pub segs: Vec<Seg>,
    pub subsectors: Vec<Subsector>,
    pub nodes: Vec<Node>,
    pub blockmap: Blockmap,
    /// REJECT matrix, padded to `(numsectors^2 + 7) / 8` bytes exactly like
    /// Chocolate Doom's `PadRejectArray` (emulating the memory vanilla read
    /// past a short lump).
    pub reject: Vec<u8>,
    /// Backing store for every sector's line list.
    pub sector_lines: Vec<LineId>,
    /// Sector used as the back sector of "glass hack" segs; see [`Seg`].
    /// Index `sectors.len() - 1` when present (it is appended last so it
    /// never collides with map sector numbers).
    pub null_sector: Option<SectorId>,
    pub valid: ValidCount,
    /// `skyflatnum`: flat number of `F_SKY1`.
    pub sky_flat: FlatNum,
    /// Raw THINGS, kept for spawning (the playsim consumes them).
    pub things: Vec<doom_content::map::MapThing>,
    /// Non-fatal problems found while building the level.
    pub warnings: Vec<String>,
}

impl Level {
    /// Placeholder with no geometry, used while swapping levels.
    pub fn empty() -> Self {
        Level {
            name: String::new(),
            vertexes: Vec::new(),
            sectors: Vec::new(),
            sides: Vec::new(),
            lines: Vec::new(),
            segs: Vec::new(),
            subsectors: Vec::new(),
            nodes: Vec::new(),
            blockmap: Blockmap { org_x: Fixed(0), org_y: Fixed(0), width: 0, height: 0, lump: Vec::new(), links: Vec::new() },
            reject: Vec::new(),
            sector_lines: Vec::new(),
            null_sector: None,
            valid: ValidCount::default(),
            sky_flat: FlatNum::MISSING,
            things: Vec::new(),
            warnings: Vec::new(),
        }
    }

    #[inline]
    pub fn vertex(&self, v: VertexId) -> Vertex {
        self.vertexes[v.idx()]
    }
    #[inline]
    pub fn sector(&self, s: SectorId) -> &Sector {
        &self.sectors[s.idx()]
    }
    #[inline]
    pub fn sector_mut(&mut self, s: SectorId) -> &mut Sector {
        &mut self.sectors[s.idx()]
    }
    #[inline]
    pub fn line(&self, l: LineId) -> &Line {
        &self.lines[l.idx()]
    }
    #[inline]
    pub fn side(&self, s: SideId) -> &Side {
        &self.sides[s.idx()]
    }

    /// Lines bordering a sector (`sector->lines`).
    pub fn lines_of(&self, s: SectorId) -> &[LineId] {
        let sec = &self.sectors[s.idx()];
        &self.sector_lines[sec.lines_start as usize..(sec.lines_start + sec.line_count) as usize]
    }

    /// Number of real map sectors (excluding the synthetic null sector).
    pub fn num_map_sectors(&self) -> usize {
        self.sectors.len() - self.null_sector.is_some() as usize
    }

    /// REJECT lookup as in `P_CheckSight`: true if `s1` can never see `s2`.
    pub fn rejected(&self, s1: SectorId, s2: SectorId) -> bool {
        let n = self.num_map_sectors();
        let pnum = s1.idx() * n + s2.idx();
        let byte = pnum >> 3;
        self.reject.get(byte).is_some_and(|b| b & (1 << (pnum & 7)) != 0)
    }
}

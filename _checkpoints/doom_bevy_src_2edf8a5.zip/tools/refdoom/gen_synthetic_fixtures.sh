#!/bin/sh
# Generate synthetic demos for every map of the IWAD and record reference
# traces with refdoom.
# Usage: tools/refdoom/gen_synthetic_fixtures.sh <refdoom binary> <iwad> <set name> <seed base> <tics> <maps...>
set -e
BIN=$(cd "$(dirname "$1")" && pwd)/$(basename "$1")
IWAD=$(cd "$(dirname "$2")" && pwd)/$(basename "$2")
SET=$3
SEED=$4
TICS=$5
shift 5
HERE=$(cd "$(dirname "$0")" && pwd)
OUT="$HERE/../../crates/doom_sim/tests/fixtures/synthetic/$SET"
mkdir -p "$OUT"
python3 "$HERE/gen_synthetic_demos.py" "$OUT" "$SEED" "$TICS" "$@"
HASH=$(python3 -c "
import sys
h=0xcbf29ce484222325
for b in open(sys.argv[1],'rb').read():
    h=((h^b)*0x100000001b3)&0xffffffffffffffff
print('%016x'%h)" "$IWAD")
TMP=$(mktemp -d)
for m in "$@"; do
    ( cd "$TMP" && HOME="$TMP" REFDOOM_COMPACT=1 REFDOOM_OUT="$TMP/t.txt" "$BIN" -iwad "$IWAD" -timedemo "$OUT/D$m.lmp" -nodraw -nosound -nomusic >/dev/null 2>&1 ) || true
    { echo "iwad $HASH"; cat "$TMP/t.txt" 2>/dev/null; } > "$OUT/D$m.trace"
    echo "$m: $(($(wc -l < "$OUT/D$m.trace") - 1)) level tics"
    rm -f "$TMP/t.txt"
done
rm -rf "$TMP"

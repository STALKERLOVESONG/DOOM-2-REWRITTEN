/*
 * refdoom: headless build of Chocolate Doom's game code used as a
 * behavioural oracle. These stubs replace the SDL-dependent platform layer
 * (video, sound, input, timer, networking) with no-ops. Nothing here affects
 * the playsim: the game logic files are compiled unmodified.
 */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "doomtype.h"
#include "net_defs.h"

/* ---- variables normally defined by i_*.c / net_*.c ---- */
float mouse_acceleration = 2.0;
int mouse_threshold = 10;
int use_analog = 0;
int joystick_turn_sensitivity = 10;
int joystick_move_sensitivity = 10;
int joystick_look_sensitivity = 10;
int snd_musicdevice = 0;
int snd_pitchshift = 0;
boolean screenvisible = true;
int vanilla_keyboard_mapping = 1;
boolean screensaver_mode = false;
int usegamma = 0;
byte *I_VideoBuffer = NULL;
unsigned int joywait = 0;
int usemouse = 0;
boolean net_client_connected = false;
net_waitdata_t net_client_wait_data;
char *net_client_reject_reason = NULL;
boolean drone = false;
net_module_t net_loop_client_module;
net_module_t net_loop_server_module;
net_module_t net_sdl_module;

/* ---- system ---- */
void I_Error(const char *error, ...)
{
    va_list ap;
    int timed = strncmp(error, "timed", 5) == 0;
    va_start(ap, error);
    vfprintf(stderr, error, ap);
    va_end(ap);
    fprintf(stderr, "\n");
    fflush(NULL);
    exit(timed ? 0 : 1);
}
void I_Quit(void) { fflush(NULL); exit(0); }
void I_AtExit(void (*func)(void), boolean run_if_error) { (void)func; (void)run_if_error; }
byte *I_ZoneBase(int *size) { *size = 64 * 1024 * 1024; return malloc(*size); }
boolean I_ConsoleStdout(void) { return false; }
void *I_Realloc(void *ptr, size_t size) { void *p = realloc(ptr, size); if (!p && size) I_Error("I_Realloc failed"); return p; }
void I_PrintBanner(const char *msg) { (void)msg; }
void I_PrintDivider(void) {}
void I_PrintStartupBanner(const char *gamedescription) { (void)gamedescription; }
void I_Tactile(int on, int off, int total) { (void)on; (void)off; (void)total; }
void I_Endoom(byte *data) { (void)data; }
void I_DisplayFPSDots(boolean dots_on) { (void)dots_on; }
void I_CheckIsScreensaver(void) {}
void I_GraphicsCheckCommandLine(void) {}
void I_BindInputVariables(void) {}
void I_BindJoystickVariables(void) {}
void I_BindSoundVariables(void) {}
void I_BindVideoVariables(void) {}
void I_InitJoystick(void) {}
void I_SetGrabMouseCallback(void *func) { (void)func; }
void I_RegisterWindowIcon(const unsigned int *icon, int width, int height) { (void)icon; (void)width; (void)height; }
void I_SetWindowTitle(const char *title) { (void)title; }
void I_StartTextInput(int x1, int y1, int x2, int y2) { (void)x1; (void)y1; (void)x2; (void)y2; }
void I_StopTextInput(void) {}
void *I_StartMultiGlob(const char *d, int f, const char *g, ...) { (void)d; (void)f; (void)g; return NULL; }
const char *I_NextGlob(void *g) { (void)g; return NULL; }
void I_EndGlob(void *g) { (void)g; }

/* DOS memory emulation for NULL dereferences, copied from i_system.c
 * (default: DOS 7.1 / Windows 98 dump). */
boolean I_GetMemoryValue(unsigned int offset, void *value, int size)
{
    static const unsigned char mem_dump_win98[10] = {
        0x9E, 0x0F, 0xC9, 0x00, 0x65, 0x04, 0x70, 0x00, 0x16, 0x00};
    const unsigned char *d = mem_dump_win98;
    switch (size) {
    case 1: *((unsigned char *)value) = d[offset]; return true;
    case 2: *((unsigned short *)value) = d[offset] | (d[offset + 1] << 8); return true;
    case 4: *((unsigned int *)value) = d[offset] | (d[offset + 1] << 8) | (d[offset + 2] << 16) | (d[offset + 3] << 24); return true;
    }
    return false;
}

/* ---- timer: advances on every query so loops never block ---- */
static int fake_ms = 0;
int I_GetTimeMS(void) { return fake_ms += 29; }
int I_GetTime(void) { return (fake_ms += 29) * 35 / 1000; }
void I_Sleep(int ms) { fake_ms += ms; }
void I_WaitVBL(int count) { (void)count; }
void I_InitTimer(void) {}

/* ---- video ---- */
void I_InitGraphics(void) { I_VideoBuffer = calloc(320 * 200, 1); }
void I_StartFrame(void) {}
void I_StartTic(void) {}
void I_UpdateNoBlit(void) {}
/* REFDOOM_SHOT_DIR=<dir>: every presented frame whose gametic lies in
 * [REFDOOM_SHOT_FROM, REFDOOM_SHOT_TO] (and is a multiple of
 * REFDOOM_SHOT_EVERY) is written as <dir>/shot_<gametic>.raw
 * (320x200 palette indices, then fuzzpos at frame start as 4 LE bytes).
 * Later frames at the same gametic overwrite. */
extern int gametic;
extern int fuzzpos;
void I_FinishUpdate(void)
{
    /* fuzzpos at the start of this frame = its value after the last one. */
    static int frame_fuzzpos = 0;
    static int init = 0, from = 0, to = -1, every = 1;
    static const char *dir = NULL;
    if (!init) {
        const char *f = getenv("REFDOOM_SHOT_FROM"), *t = getenv("REFDOOM_SHOT_TO");
        dir = getenv("REFDOOM_SHOT_DIR");
        from = f ? atoi(f) : 0;
        to = t ? atoi(t) : 0x7fffffff;
        every = getenv("REFDOOM_SHOT_EVERY") ? atoi(getenv("REFDOOM_SHOT_EVERY")) : 1;
        if (every < 1)
            every = 1;
        init = 1;
    }
    if (dir && gametic >= from && gametic <= to && gametic % every == 0) {
        char path[1024];
        FILE *fp;
        snprintf(path, sizeof path, "%s/shot_%d.raw", dir, gametic);
        fp = fopen(path, "wb");
        if (fp) {
            unsigned char t[4] = {frame_fuzzpos & 0xff, (frame_fuzzpos >> 8) & 0xff, 0, 0};
            fwrite(I_VideoBuffer, 1, 320 * 200, fp);
            fwrite(t, 1, 4, fp); /* trailer: fuzzpos at frame start (LE) */
            fclose(fp);
        }
    }
    frame_fuzzpos = fuzzpos;
}
void I_ReadScreen(byte *scr) { memcpy(scr, I_VideoBuffer, 320 * 200); }
void I_SetPalette(byte *palette) { (void)palette; }
int I_GetPaletteIndex(int r, int g, int b) { (void)r; (void)g; (void)b; return 0; }

/* ---- sound / music ---- */
void I_InitSound(int game) { (void)game; }
void I_ShutdownSound(void) {}
int I_GetSfxLumpNum(void *sfx) { (void)sfx; return 0; }
void I_UpdateSound(void) {}
void I_UpdateSoundParams(int channel, int vol, int sep) { (void)channel; (void)vol; (void)sep; }
int I_StartSound(void *sfx, int channel, int vol, int sep, int pitch) { (void)sfx; (void)vol; (void)sep; (void)pitch; return channel; }
void I_StopSound(int channel) { (void)channel; }
boolean I_SoundIsPlaying(int channel) { (void)channel; return false; }
void I_PrecacheSounds(void *sounds, int num) { (void)sounds; (void)num; }
void I_InitMusic(void) {}
void I_ShutdownMusic(void) {}
void I_SetMusicVolume(int volume) { (void)volume; }
void I_PauseSong(void) {}
void I_ResumeSong(void) {}
void *I_RegisterSong(void *data, int len) { (void)data; (void)len; return NULL; }
void I_UnRegisterSong(void *handle) { (void)handle; }
void I_PlaySong(void *handle, boolean looping) { (void)handle; (void)looping; }
void I_StopSong(void) {}
boolean I_MusicIsPlaying(void) { return false; }
void I_OPL_DevMessages(char *b, size_t n) { (void)b; (void)n; }
void I_SetOPLDriverVer(int ver) { (void)ver; }

/* ---- networking (single player only) ---- */
void NET_BindVariables(void) {}
void NET_Init(void) {}
boolean NET_CL_Connect(void *addr, void *data) { (void)addr; (void)data; return false; }
void NET_CL_Disconnect(void) {}
boolean NET_CL_GetSettings(void *settings) { (void)settings; return false; }
void NET_CL_Run(void) {}
void NET_CL_SendTiccmd(void *ticcmd, int maketic) { (void)ticcmd; (void)maketic; }
void NET_CL_StartGame(void *settings) { (void)settings; }
char *NET_AddrToString(void *addr) { (void)addr; return "none"; }
void NET_DedicatedServer(void) {}
void *NET_FindLANServer(void) { return NULL; }
int NET_LANQuery(void) { return 0; }
void NET_MasterQuery(void) {}
void NET_QueryAddress(char *addr) { (void)addr; }
void NET_ReferenceAddress(void *addr) { (void)addr; }
void NET_ReleaseAddress(void *addr) { (void)addr; }
void NET_SV_AddModule(void *module) { (void)module; }
void NET_SV_Init(void) {}
void NET_SV_RegisterWithMaster(void) {}
void NET_SV_Run(void) {}
void NET_SV_Shutdown(void) {}
void NET_WaitForLaunch(void) {}

//! Headless session tests: level flow, death, cheats, demo playback and frame
//! output. Skipped when the IWAD is absent.

use std::path::PathBuf;

use doom_game::{InputState, MapRef, Session, SessionConfig};
use doom_sim::player::{PlayerState, Weapon};

fn iwad() -> Option<PathBuf> {
    let p = std::env::var_os("DOOM_IWAD")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../WADS/doom1.wad"));
    p.exists().then_some(p).or_else(|| {
        eprintln!("skipping: no IWAD");
        None
    })
}

fn session(map: Option<&str>) -> Option<Session> {
    let mut cfg = SessionConfig::new(iwad()?);
    cfg.map = map.map(str::to_string);
    Some(Session::new(&cfg).unwrap())
}

fn idle(s: &mut Session, tics: usize) {
    for _ in 0..tics {
        s.tick(&InputState::default());
    }
}

#[test]
fn starts_on_first_map_and_renders() {
    let Some(mut s) = session(None) else { return };
    assert_eq!(s.map(), MapRef::new(1, 1));
    idle(&mut s, 5);
    let mut rgba = vec![0u8; 320 * 200 * 4];
    s.render_rgba(&mut rgba);
    assert!(rgba.chunks(4).all(|p| p[3] == 255));
    let lit = rgba.chunks(4).filter(|p| p[0] as u32 + p[1] as u32 + p[2] as u32 > 30).count();
    assert!(lit > 320 * 200 / 2, "frame mostly dark: {lit} lit pixels");
    let hud = s.hud();
    assert_eq!((hud.health, hud.weapon, hud.ammo), (100, Weapon::Pistol, Some((50, 200))));
}

#[test]
fn walking_and_firing_runs() {
    let Some(mut s) = session(Some("E1M1")) else { return };
    let start = s.hud().ammo.unwrap().0;
    let inp = InputState { forward: true, fire: true, turn_left: true, ..Default::default() };
    for _ in 0..200 {
        s.tick(&inp);
        s.render_indexed();
    }
    assert!(s.hud().ammo.unwrap().0 < start, "pistol fired");
    assert!(!s.take_events().is_empty(), "sound events were produced");
}

#[test]
fn exit_carries_inventory_to_next_map() {
    let Some(mut s) = session(Some("E1M1")) else { return };
    s.give_all();
    idle(&mut s, 2);
    s.exit_level();
    assert_eq!(s.map(), MapRef::new(1, 2));
    idle(&mut s, 2);
    let hud = s.hud();
    assert_eq!(hud.armor, 200);
    assert!(hud.weapons_owned.iter().all(|&o| o));
    assert_eq!(hud.keys, [false; 6], "keys are cleared between levels");
    assert_eq!(hud.health, 100);
}

#[test]
fn secret_exit_and_return() {
    let Some(mut s) = session(Some("E1M3")) else { return };
    // Secret exit goes to E1M9, which returns to E1M4.
    s.world.gameexit = Some(doom_sim::world::GameExit::Secret);
    idle(&mut s, 1);
    assert_eq!(s.map(), MapRef::new(1, 9));
    s.exit_level();
    assert_eq!(s.map(), MapRef::new(1, 4));
}

#[test]
fn death_then_use_reloads_level() {
    let Some(mut s) = session(Some("E1M1")) else { return };
    s.give_all();
    idle(&mut s, 2);
    let mo = s.world.console_player().mo.unwrap();
    doom_sim::inter::damage_mobj(&mut s.world, mo, None, None, 10_000);
    idle(&mut s, 40);
    assert!(s.hud().dead);
    s.tick(&InputState { use_: true, ..Default::default() });
    idle(&mut s, 2);
    let p = s.world.console_player();
    assert_eq!(p.playerstate, PlayerState::Live);
    assert_eq!(p.health, 100);
    assert!(!p.weaponowned[Weapon::Shotgun as usize], "reborn with pistol start");
    assert_eq!(s.map(), MapRef::new(1, 1));
}

#[test]
fn god_mode_survives_damage_and_warp_resets() {
    let Some(mut s) = session(Some("E1M1")) else { return };
    s.toggle_god();
    let mo = s.world.console_player().mo.unwrap();
    // Damage >= 1000 (telefrag) ignores god mode in vanilla; stay below it.
    doom_sim::inter::damage_mobj(&mut s.world, mo, None, None, 999);
    idle(&mut s, 2);
    assert!(!s.hud().dead);
    s.give_all();
    s.warp("E2M1").unwrap();
    assert_eq!(s.map(), MapRef::new(2, 1));
    assert!(!s.hud().god, "warp starts a new game");
    assert!(!s.hud().weapons_owned[Weapon::Shotgun as usize]);
    assert!(s.warp("E9M9").is_err());
}

#[test]
fn demo_playback_ends() {
    let Some(iwad) = iwad() else { return };
    let mut cfg = SessionConfig::new(iwad);
    cfg.demo = Some("DEMO1".into());
    let mut s = Session::new(&cfg).unwrap();
    assert!(s.is_demo());
    let mut tics = 0;
    while !s.demo_finished() && tics < 10_000 {
        s.tick(&InputState::default());
        tics += 1;
    }
    assert!(s.demo_finished());
    // DEMO1 exits E1M5 near its end (the level-exit tic consumes one tic).
    assert!(tics > 1700, "{tics}");
}

#[test]
fn palette_effects() {
    let Some(mut s) = session(Some("E1M1")) else { return };
    assert_eq!(s.palette_index(), 0);
    let cp = s.world.params.consoleplayer;
    s.world.players[cp].damagecount = 20;
    assert_eq!(s.palette_index(), 1 + 3);
    s.world.players[cp].damagecount = 0;
    s.world.players[cp].bonuscount = 6;
    assert_eq!(s.palette_index(), 10);
}

#[test]
fn session_is_send_and_sync() {
    // Hosts (Bevy) keep the session in a resource.
    fn check<T: Send + Sync + 'static>() {}
    check::<Session>();
}

#[test]
fn warp_cheat() {
    let Some(mut s) = session(Some("E1M1")) else { return };
    let mut m = doom_game::CheatMatcher::default();
    let cheat = "idclev15".chars().filter_map(|c| m.feed(c)).next().unwrap();
    s.apply_cheat(&cheat);
    assert_eq!(s.map(), MapRef::new(1, 5));
}

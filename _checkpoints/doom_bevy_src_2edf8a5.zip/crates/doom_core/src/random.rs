//! Doom's table-driven "random" numbers (m_random.c).
//!
//! There are two independent cursors into the same 256-byte table:
//! `P_Random` for the playsim (must stay in sync for demos and netgames) and
//! `M_Random` for everything else (menus, rendering effects, sound pitch).
//! Mixing them up desyncs demos, so they are separate methods.

pub static RNDTABLE: [u8; 256] = [
    0, 8, 109, 220, 222, 241, 149, 107, 75, 248, 254, 140, 16, 66, 74, 21, 211, 47, 80, 242, 154, 27,
    205, 128, 161, 89, 77, 36, 95, 110, 85, 48, 212, 140, 211, 249, 22, 79, 200, 50, 28, 188, 52, 140,
    202, 120, 68, 145, 62, 70, 184, 190, 91, 197, 152, 224, 149, 104, 25, 178, 252, 182, 202, 182, 141,
    197, 4, 81, 181, 242, 145, 42, 39, 227, 156, 198, 225, 193, 219, 93, 122, 175, 249, 0, 175, 143, 70,
    239, 46, 246, 163, 53, 163, 109, 168, 135, 2, 235, 25, 92, 20, 145, 138, 77, 69, 166, 78, 176, 173,
    212, 166, 113, 94, 161, 41, 50, 239, 49, 111, 164, 70, 60, 2, 37, 171, 75, 136, 156, 11, 56, 42, 146,
    138, 229, 73, 146, 77, 61, 98, 196, 135, 106, 63, 197, 195, 86, 96, 203, 113, 101, 170, 247, 181,
    113, 80, 250, 108, 7, 255, 237, 129, 226, 79, 107, 112, 166, 103, 241, 24, 223, 239, 120, 198, 58,
    60, 82, 128, 3, 184, 66, 143, 224, 145, 224, 81, 206, 163, 45, 63, 90, 168, 114, 59, 33, 159, 95, 28,
    139, 123, 98, 125, 196, 15, 70, 194, 253, 54, 14, 109, 226, 71, 17, 161, 93, 186, 87, 244, 138, 20,
    52, 123, 251, 26, 36, 17, 46, 52, 231, 232, 76, 31, 221, 84, 37, 216, 165, 212, 106, 197, 242, 98,
    43, 39, 175, 254, 145, 190, 84, 118, 222, 187, 136, 120, 163, 236, 249,
];

#[derive(Clone, Debug, Default, PartialEq, Eq, Hash)]
pub struct DoomRandom {
    /// `rndindex` (M_Random).
    pub menu_index: u8,
    /// `prndindex` (P_Random). Vanilla only resets it in `G_InitNew` (via
    /// `M_ClearRandom`) and does not store it in savegames.
    pub play_index: u8,
}

impl DoomRandom {
    pub const fn new() -> Self {
        Self { menu_index: 0, play_index: 0 }
    }

    /// `P_Random`: playsim RNG, 0..=255.
    #[inline]
    pub fn p_random(&mut self) -> i32 {
        self.play_index = self.play_index.wrapping_add(1);
        RNDTABLE[self.play_index as usize] as i32
    }

    /// `M_Random`: non-playsim RNG, 0..=255.
    #[inline]
    pub fn m_random(&mut self) -> i32 {
        self.menu_index = self.menu_index.wrapping_add(1);
        RNDTABLE[self.menu_index as usize] as i32
    }

    /// `P_Random() - P_Random()` with the evaluation order fixed to
    /// left-then-right, matching the DOS executable (Chocolate Doom's
    /// `P_SubRandom`). C leaves this order unspecified, so code that spells
    /// the subtraction out inline must call this instead.
    #[inline]
    pub fn p_sub_random(&mut self) -> i32 {
        let r = self.p_random();
        r - self.p_random()
    }

    /// `M_ClearRandom`.
    #[inline]
    pub fn clear(&mut self) {
        self.menu_index = 0;
        self.play_index = 0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sequence_starts_at_index_one() {
        let mut r = DoomRandom::new();
        assert_eq!(r.p_random(), 8);
        assert_eq!(r.p_random(), 109);
        assert_eq!(r.m_random(), 8); // independent cursor
    }

    #[test]
    fn wraps_after_256() {
        let mut r = DoomRandom::new();
        for _ in 0..255 {
            r.p_random();
        }
        assert_eq!(r.p_random(), 0); // index wrapped back to 0
        assert_eq!(r.p_random(), 8);
    }

    #[test]
    fn sub_random_order() {
        let mut r = DoomRandom::new();
        assert_eq!(r.p_sub_random(), 8 - 109);
    }
}

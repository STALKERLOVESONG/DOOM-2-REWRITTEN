//! DECORATE (ZDoom's actor definition language), subset: new actors and
//! replacements built from Doom's own action functions.
//!
//! Supported:
//! - `actor Name [: Parent] [replaces Other] [doomednum]`, inheriting from
//!   another DECORATE actor or a Doom class (`ZombieMan`, `DoomImp`,
//!   `Medikit`, ...; unknown parents start from `Actor` defaults);
//! - properties `Radius`, `Height`, `Health`, `Speed`, `Mass`, `PainChance`,
//!   `Damage`, `ReactionTime`; the `Monster` and `Projectile` combos;
//! - `+FLAG`/`-FLAG` for the flags Doom has;
//! - `States` with sprite frames, tics (`random(a, b)` takes the middle),
//!   `Bright`, Doom action functions (`A_Look`, `A_Chase`, ...), labels and
//!   `Stop`/`Loop`/`Wait`/`Fail`/`Goto [Super::]Label[+n]`;
//! - `#include` of other lumps or archive paths.
//!
//! Everything else (ZDoom-only actions, sounds, inventory properties,
//! render styles, ZScript) is ignored with a warning, so the actor still
//! appears and animates. Pickups and weapons keep working only through
//! inherited Doom behaviour (the playsim dispatches pickups by sprite).

use std::collections::{BTreeSet, HashMap};

use doom_content::script::{Scanner, Token};
use doom_content::ResourceStack;
use doom_core::Fixed;

use crate::info::*;
use crate::mobj::flags::*;

/// Doom classes by their ZDoom names.
const CLASSES: &[(&str, MobjType)] = &[
    ("doomplayer", MT_PLAYER),
    ("zombieman", MT_POSSESSED),
    ("shotgunguy", MT_SHOTGUY),
    ("archvile", MT_VILE),
    ("archvilefire", MT_FIRE),
    ("revenant", MT_UNDEAD),
    ("revenanttracer", MT_TRACER),
    ("revenanttracersmoke", MT_SMOKE),
    ("fatso", MT_FATSO),
    ("fatshot", MT_FATSHOT),
    ("chaingunguy", MT_CHAINGUY),
    ("doomimp", MT_TROOP),
    ("demon", MT_SERGEANT),
    ("spectre", MT_SHADOWS),
    ("cacodemon", MT_HEAD),
    ("baronofhell", MT_BRUISER),
    ("baronball", MT_BRUISERSHOT),
    ("hellknight", MT_KNIGHT),
    ("lostsoul", MT_SKULL),
    ("spidermastermind", MT_SPIDER),
    ("arachnotron", MT_BABY),
    ("cyberdemon", MT_CYBORG),
    ("painelemental", MT_PAIN),
    ("wolfensteinss", MT_WOLFSS),
    ("commanderkeen", MT_KEEN),
    ("bossbrain", MT_BOSSBRAIN),
    ("bosseye", MT_BOSSSPIT),
    ("bosstarget", MT_BOSSTARGET),
    ("spawnshot", MT_SPAWNSHOT),
    ("spawnfire", MT_SPAWNFIRE),
    ("explosivebarrel", MT_BARREL),
    ("doomimpball", MT_TROOPSHOT),
    ("cacodemonball", MT_HEADSHOT),
    ("rocket", MT_ROCKET),
    ("plasmaball", MT_PLASMA),
    ("bfgball", MT_BFG),
    ("arachnotronplasma", MT_ARACHPLAZ),
    ("bulletpuff", MT_PUFF),
    ("blood", MT_BLOOD),
    ("teleportfog", MT_TFOG),
    ("itemfog", MT_IFOG),
    ("teleportdest", MT_TELEPORTMAN),
    ("bfgextra", MT_EXTRABFG),
    ("greenarmor", MT_MISC0),
    ("bluearmor", MT_MISC1),
    ("healthbonus", MT_MISC2),
    ("armorbonus", MT_MISC3),
    ("bluecard", MT_MISC4),
    ("redcard", MT_MISC5),
    ("yellowcard", MT_MISC6),
    ("yellowskull", MT_MISC7),
    ("redskull", MT_MISC8),
    ("blueskull", MT_MISC9),
    ("stimpack", MT_MISC10),
    ("medikit", MT_MISC11),
    ("soulsphere", MT_MISC12),
    ("invulnerabilitysphere", MT_INV),
    ("berserk", MT_MISC13),
    ("blursphere", MT_INS),
    ("radsuit", MT_MISC14),
    ("allmap", MT_MISC15),
    ("infrared", MT_MISC16),
    ("megasphere", MT_MEGA),
    ("clip", MT_CLIP),
    ("clipbox", MT_MISC17),
    ("rocketammo", MT_MISC18),
    ("rocketbox", MT_MISC19),
    ("cell", MT_MISC20),
    ("cellpack", MT_MISC21),
    ("shell", MT_MISC22),
    ("shellbox", MT_MISC23),
    ("backpack", MT_MISC24),
    ("bfg9000", MT_MISC25),
    ("chaingun", MT_CHAINGUN),
    ("chainsaw", MT_MISC26),
    ("rocketlauncher", MT_MISC27),
    ("plasmarifle", MT_MISC28),
    ("shotgun", MT_SHOTGUN),
    ("supershotgun", MT_SUPERSHOTGUN),
    ("techlamp", MT_MISC29),
    ("techlamp2", MT_MISC30),
    ("column", MT_MISC31),
];

const FLAGS: &[(&str, u32)] = &[
    ("special", MF_SPECIAL),
    ("solid", MF_SOLID),
    ("shootable", MF_SHOOTABLE),
    ("nosector", MF_NOSECTOR),
    ("noblockmap", MF_NOBLOCKMAP),
    ("ambush", MF_AMBUSH),
    ("justhit", MF_JUSTHIT),
    ("justattacked", MF_JUSTATTACKED),
    ("spawnceiling", MF_SPAWNCEILING),
    ("nogravity", MF_NOGRAVITY),
    ("dropoff", MF_DROPOFF),
    ("pickup", MF_PICKUP),
    ("noclip", MF_NOCLIP),
    ("slide", MF_SLIDE),
    ("float", MF_FLOAT),
    ("teleport", MF_TELEPORT),
    ("missile", MF_MISSILE),
    ("dropped", MF_DROPPED),
    ("shadow", MF_SHADOW),
    ("noblood", MF_NOBLOOD),
    ("corpse", MF_CORPSE),
    ("infloat", MF_INFLOAT),
    ("countkill", MF_COUNTKILL),
    ("countitem", MF_COUNTITEM),
    ("skullfly", MF_SKULLFLY),
    ("notdmatch", MF_NOTDMATCH),
];

/// Per-actor state labels (lower case) -> state.
type Labels = HashMap<String, StateNum>;

struct Actor {
    mtype: MobjType,
    labels: Labels,
}

pub struct Decorate<'a> {
    info: &'a mut Info,
    actors: HashMap<String, Actor>,
    pub warnings: Vec<String>,
    ignored: BTreeSet<String>,
}

fn standard_labels(m: &MobjInfo) -> Labels {
    let mut l = Labels::new();
    for (name, s) in [
        ("spawn", m.spawnstate),
        ("see", m.seestate),
        ("pain", m.painstate),
        ("melee", m.meleestate),
        ("missile", m.missilestate),
        ("death", m.deathstate),
        ("xdeath", m.xdeathstate),
        ("raise", m.raisestate),
    ] {
        if s.0 != 0 {
            l.insert(name.to_string(), s);
        }
    }
    l
}

impl<'a> Decorate<'a> {
    pub fn new(info: &'a mut Info) -> Self {
        let mut actors = HashMap::new();
        for &(name, t) in CLASSES {
            let labels = standard_labels(info.mobj(t));
            actors.insert(name.to_string(), Actor { mtype: t, labels });
        }
        Decorate { info, actors, warnings: Vec::new(), ignored: BTreeSet::new() }
    }

    /// Apply every `DECORATE` lump in the stack, in load order.
    pub fn apply_stack(info: &mut Info, stack: &ResourceStack) -> Vec<String> {
        let mut d = Decorate::new(info);
        for &id in stack.all_named("DECORATE") {
            let text = String::from_utf8_lossy(stack.data(id)).into_owned();
            d.parse(&text, stack, 0);
        }
        if !d.ignored.is_empty() {
            let list: Vec<_> = d.ignored.iter().take(30).cloned().collect();
            d.warnings.push(format!("DECORATE: ignored (not supported): {}", list.join(", ")));
        }
        d.warnings
    }

    fn ignore(&mut self, what: &str) {
        self.ignored.insert(what.to_string());
    }

    pub fn parse(&mut self, text: &str, stack: &ResourceStack, depth: u32) {
        let mut sc = Scanner::new(text);
        while let Some(t) = sc.next() {
            match t {
                Token::Punct('#') if sc.eat_word("include") => {
                    let Some(Token::Str(path)) = sc.next() else { continue };
                    let id = stack.find_path(&path).or_else(|| stack.check_num_for_name(&path));
                    match id {
                        Some(id) if depth < 16 => {
                            let text = String::from_utf8_lossy(stack.data(id)).into_owned();
                            self.parse(&text, stack, depth + 1);
                        }
                        _ => self.warnings.push(format!("DECORATE: #include {path:?} not found")),
                    }
                }
                Token::Ident(w) if w.eq_ignore_ascii_case("actor") => self.actor(&mut sc),
                Token::Ident(w) => {
                    // const, enum, damagetype, ...: skip to the end of the
                    // statement or block.
                    self.ignore(&w.to_ascii_lowercase());
                    while let Some(t) = sc.peek().cloned() {
                        if t.is_punct('{') {
                            sc.skip_block();
                            break;
                        }
                        sc.next();
                        if t.is_punct(';') {
                            break;
                        }
                    }
                }
                _ => {}
            }
        }
    }

    fn sprite(&mut self, name: &str) -> SpriteNum {
        let up = name.to_ascii_uppercase();
        match self.info.sprnames.iter().position(|s| *s == up) {
            Some(i) => SpriteNum(i as u16),
            None => {
                self.info.sprnames.push(up);
                SpriteNum((self.info.sprnames.len() - 1) as u16)
            }
        }
    }

    fn actor(&mut self, sc: &mut Scanner) {
        let Some(name) = sc.next().and_then(|t| t.text().map(str::to_string)) else { return };
        let mut parent = None;
        let mut replaces = None;
        let mut doomednum = None;
        // Header: [: Parent] [replaces X] [doomednum] [native]
        loop {
            if sc.eat(':') {
                parent = sc.next().and_then(|t| t.text().map(str::to_ascii_lowercase));
            } else if sc.eat_word("replaces") {
                replaces = sc.next().and_then(|t| t.text().map(str::to_ascii_lowercase));
            } else if sc.eat_word("native") {
            } else if let Some(Token::Int(n)) = sc.peek() {
                doomednum = Some(*n as i32);
                sc.next();
            } else {
                break;
            }
        }
        let (mut mi, mut labels) = match parent.as_deref().and_then(|p| self.actors.get(p)) {
            Some(a) => (*self.info.mobj(a.mtype), a.labels.clone()),
            None => {
                if let Some(p) = &parent {
                    if p != "actor" {
                        self.warnings.push(format!("DECORATE {name}: unknown parent {p}; using Actor defaults"));
                    }
                }
                (
                    MobjInfo {
                        doomednum: -1,
                        spawnstate: StateNum(0),
                        spawnhealth: 1000,
                        seestate: StateNum(0),
                        seesound: SfxNum(0),
                        reactiontime: 8,
                        attacksound: SfxNum(0),
                        painstate: StateNum(0),
                        painchance: 0,
                        painsound: SfxNum(0),
                        meleestate: StateNum(0),
                        missilestate: StateNum(0),
                        deathstate: StateNum(0),
                        xdeathstate: StateNum(0),
                        deathsound: SfxNum(0),
                        speed: 0,
                        radius: Fixed::from_int(20),
                        height: Fixed::from_int(16),
                        mass: 100,
                        damage: 0,
                        activesound: SfxNum(0),
                        flags: 0,
                        raisestate: StateNum(0),
                    },
                    Labels::new(),
                )
            }
        };
        let parent_labels = labels.clone();
        mi.doomednum = -1;
        let mut speed_units: Option<f64> = None;
        if !sc.eat('{') {
            self.warnings.push(format!("DECORATE {name}: expected '{{'"));
            return;
        }
        while let Some(t) = sc.next() {
            match t {
                Token::Punct('}') => break,
                Token::Punct(c @ ('+' | '-')) => {
                    let Some(flag) = sc.next().and_then(|t| t.text().map(str::to_ascii_lowercase)) else { continue };
                    // "+FOO.BAR" qualified names: use the last part.
                    let short = flag.rsplit('.').next().unwrap_or(&flag).to_string();
                    match FLAGS.iter().find(|(n, _)| *n == short) {
                        Some(&(_, bit)) => {
                            if c == '+' {
                                mi.flags |= bit;
                            } else {
                                mi.flags &= !bit;
                            }
                        }
                        None => self.ignore(&format!("flag {short}")),
                    }
                }
                Token::Ident(p) => {
                    let line = sc.line();
                    let key = p.to_ascii_lowercase();
                    match key.as_str() {
                        "states" => {
                            self.states(sc, &name, &mut labels, &parent_labels);
                            continue;
                        }
                        "monster" => mi.flags |= MF_SHOOTABLE | MF_COUNTKILL | MF_SOLID,
                        "projectile" => mi.flags |= MF_NOBLOCKMAP | MF_NOGRAVITY | MF_DROPOFF | MF_MISSILE,
                        "radius" | "height" | "health" | "speed" | "mass" | "painchance" | "damage" | "reactiontime" => {
                            let v = sc.number().unwrap_or(0.0);
                            match key.as_str() {
                                "radius" => mi.radius = Fixed((v * 65536.0) as i32),
                                "height" => mi.height = Fixed((v * 65536.0) as i32),
                                "health" => mi.spawnhealth = v as i32,
                                "speed" => speed_units = Some(v),
                                "mass" => mi.mass = v as i32,
                                "painchance" => mi.painchance = v as i32,
                                "damage" => mi.damage = v as i32,
                                _ => mi.reactiontime = v as i32,
                            }
                        }
                        other => {
                            self.ignore(&format!("property {other}"));
                            // Its arguments: the rest of the line, up to a
                            // block, flag or `States`.
                            while sc.line() == line
                                && sc.peek().is_some_and(|t| {
                                    !t.is_punct('}') && !t.is_punct('{') && !t.is_punct('+') && !t.is_word("states")
                                })
                            {
                                sc.next();
                            }
                        }
                    }
                }
                _ => {}
            }
        }
        if let Some(v) = speed_units {
            // Missiles move in fixed point per tic; monsters in whole units.
            mi.speed = if mi.flags & MF_MISSILE != 0 { (v * 65536.0) as i32 } else { v as i32 };
        }
        let get = |l: &Labels, k: &str| l.get(k).copied().unwrap_or(StateNum(0));
        mi.spawnstate = get(&labels, "spawn");
        mi.seestate = get(&labels, "see");
        mi.painstate = get(&labels, "pain");
        mi.meleestate = get(&labels, "melee");
        mi.missilestate = get(&labels, "missile");
        mi.deathstate = get(&labels, "death");
        mi.xdeathstate = get(&labels, "xdeath");
        mi.raisestate = get(&labels, "raise");
        if let Some(n) = doomednum {
            // The last definition of an editor number wins.
            for m in self.info.mobjinfo.iter_mut().filter(|m| m.doomednum == n) {
                m.doomednum = -1;
            }
            mi.doomednum = n;
        }
        self.info.mobjinfo.push(mi);
        let mtype = MobjType((self.info.mobjinfo.len() - 1) as u16);
        if let Some(r) = replaces {
            match self.actors.get(&r).map(|a| a.mtype) {
                Some(target) => {
                    let keep = self.info.mobjinfo[target.idx()].doomednum;
                    self.info.mobjinfo[target.idx()] = MobjInfo { doomednum: keep, ..mi };
                }
                None => self.warnings.push(format!("DECORATE {name}: replaces unknown actor {r}")),
            }
        }
        self.actors.insert(name.to_ascii_lowercase(), Actor { mtype, labels });
    }

    fn states(&mut self, sc: &mut Scanner, actor: &str, labels: &mut Labels, parent_labels: &Labels) {
        if !sc.eat('{') {
            return;
        }
        let mut pending: Vec<String> = Vec::new();
        // Index of the first state since the last label (for Loop).
        let mut loop_start: Option<usize> = None;
        // Deferred gotos: (state index whose next to set, label, offset).
        let mut gotos: Vec<(Option<usize>, Vec<String>, String, i32)> = Vec::new();
        let mut last: Option<usize> = None;
        loop {
            let Some(t) = sc.next() else { return };
            match t {
                Token::Punct('}') => break,
                Token::Ident(w) if sc.peek().is_some_and(|t| t.is_punct(':')) && !sc.peek_at(1).is_some_and(|t| t.is_punct(':')) => {
                    sc.next();
                    pending.push(w.to_ascii_lowercase());
                }
                Token::Ident(w) if matches!(w.to_ascii_lowercase().as_str(), "stop" | "loop" | "wait" | "fail" | "goto") => {
                    let kw = w.to_ascii_lowercase();
                    match kw.as_str() {
                        "stop" | "fail" => {
                            if let Some(i) = last {
                                self.info.states[i].next = StateNum(0);
                            }
                            for l in pending.drain(..) {
                                labels.insert(l, StateNum(0));
                            }
                        }
                        "wait" => {
                            if let Some(i) = last {
                                self.info.states[i].next = StateNum(i as u16);
                            }
                        }
                        "loop" => {
                            if let (Some(i), Some(s)) = (last, loop_start) {
                                self.info.states[i].next = StateNum(s as u16);
                            }
                        }
                        _ => {
                            // goto [Super::]Label[+n]
                            let mut target = sc.next().and_then(|t| t.text().map(str::to_ascii_lowercase)).unwrap_or_default();
                            let mut super_ = false;
                            if target == "super" && sc.eat(':') && sc.eat(':') {
                                super_ = true;
                                target = sc.next().and_then(|t| t.text().map(str::to_ascii_lowercase)).unwrap_or_default();
                            } else if sc.peek().is_some_and(|t| t.is_punct(':')) && sc.peek_at(1).is_some_and(|t| t.is_punct(':')) {
                                // Class::Label: treat like Super.
                                sc.next();
                                sc.next();
                                super_ = true;
                                target = sc.next().and_then(|t| t.text().map(str::to_ascii_lowercase)).unwrap_or_default();
                            }
                            let offset = if sc.eat('+') { sc.number().unwrap_or(0.0) as i32 } else { 0 };
                            let key = if super_ { format!("super::{target}") } else { target };
                            gotos.push((last, std::mem::take(&mut pending), key, offset));
                        }
                    }
                    last = None;
                    loop_start = None;
                }
                Token::Ident(sprite) | Token::Str(sprite) => {
                    // SPRT FRAMES TICS [modifiers] [action]
                    let frames = match sc.next() {
                        Some(Token::Ident(f)) | Some(Token::Str(f)) => f,
                        Some(Token::Punct(c)) => c.to_string(),
                        Some(Token::Int(i)) => i.to_string(),
                        _ => continue,
                    };
                    let tics = if sc.eat_word("random") {
                        sc.eat('(');
                        let a = sc.number().unwrap_or(0.0);
                        sc.eat(',');
                        let b = sc.number().unwrap_or(a);
                        sc.eat(')');
                        ((a + b) / 2.0).round() as i32
                    } else {
                        sc.number().unwrap_or(0.0) as i32
                    };
                    let mut bright = false;
                    let mut action = Action::None;
                    loop {
                        let Some(Token::Ident(m)) = sc.peek().cloned() else { break };
                        let lower = m.to_ascii_lowercase();
                        if sc.peek_at(1).is_some_and(|t| t.is_punct(':')) {
                            break; // next label
                        }
                        match lower.as_str() {
                            "bright" => {
                                bright = true;
                                sc.next();
                            }
                            "fast" | "slow" | "nodelay" | "canraise" => {
                                sc.next();
                            }
                            "offset" | "light" => {
                                sc.next();
                                skip_parens(sc);
                            }
                            _ if lower.starts_with("a_") => {
                                sc.next();
                                let has_args = sc.peek().is_some_and(|t| t.is_punct('('));
                                if has_args {
                                    skip_parens(sc);
                                }
                                action = Action::ALL.iter().copied().find(|a| a.name().eq_ignore_ascii_case(&m)).unwrap_or_else(|| {
                                    self.ignore(&format!("action {m}"));
                                    Action::None
                                });
                            }
                            _ => break,
                        }
                    }
                    let keep_sprite = sprite == "####" || sprite == "----";
                    let spr = if keep_sprite {
                        last.map_or(SpriteNum(0), |i| self.info.states[i].sprite)
                    } else {
                        self.sprite(&sprite)
                    };
                    for ch in frames.chars() {
                        let frame = if ch == '#' {
                            last.map_or(0, |i| self.info.states[i].frame & FF_FRAMEMASK)
                        } else {
                            (ch.to_ascii_uppercase() as i32 - 'A' as i32).clamp(0, 28)
                        };
                        let idx = self.info.states.len();
                        if let Some(prev) = last {
                            self.info.states[prev].next = StateNum(idx as u16);
                        }
                        self.info.states.push(State {
                            sprite: spr,
                            frame: frame | if bright { FF_FULLBRIGHT } else { 0 },
                            tics,
                            action,
                            next: StateNum(0),
                            misc1: 0,
                            misc2: 0,
                        });
                        for l in pending.drain(..) {
                            labels.insert(l, StateNum(idx as u16));
                            loop_start = Some(idx);
                        }
                        if loop_start.is_none() {
                            loop_start = Some(idx);
                        }
                        last = Some(idx);
                    }
                }
                _ => {}
            }
        }
        // Resolve gotos now that every label is known.
        for (from, label_names, key, offset) in gotos {
            let target = if let Some(l) = key.strip_prefix("super::") {
                parent_labels.get(l).copied()
            } else {
                labels.get(&key).copied().or_else(|| parent_labels.get(&key).copied())
            };
            let Some(t) = target else {
                self.warnings.push(format!("DECORATE {actor}: goto {key}: unknown label"));
                continue;
            };
            let t = StateNum((t.0 as i32 + offset) as u16);
            if let Some(i) = from {
                self.info.states[i].next = t;
            }
            for l in label_names {
                labels.insert(l, t);
            }
        }
    }
}

fn skip_parens(sc: &mut Scanner) {
    if !sc.eat('(') {
        return;
    }
    let mut depth = 1;
    while let Some(t) = sc.next() {
        if t.is_punct('(') {
            depth += 1;
        } else if t.is_punct(')') {
            depth -= 1;
            if depth == 0 {
                return;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn decorations_and_inheritance() {
        let mut info = Info::doom();
        let base_states = info.states.len();
        let mut d = Decorate::new(&mut info);
        let stack = ResourceStack::new();
        d.parse(
            "ACTOR Shrubbery01 21006\n{\n  Radius 8\n  Height 16\n  +NOBLOCKMAP\n  +MOVEWITHSECTOR\n  States\n  {\n  Spawn:\n    BSH2 A -1\n    Stop\n  }\n}\n\
             ACTOR Shrubbery02 : Shrubbery01 21007\n{\n  States\n  {\n  Spawn:\n    BSH3 AB 5 Bright\n    Loop\n  }\n}\n\
             actor FastImp : DoomImp replaces DoomImp { Speed 16 States { See: TROO AABB 2 A_Chase Loop } }",
            &stack,
            0,
        );
        let warnings = d.warnings.clone();
        assert!(warnings.is_empty(), "{warnings:?}");
        let t = info.type_for_doomednum(21006).unwrap();
        let m = *info.mobj(t);
        assert_eq!(m.radius, Fixed::from_int(8));
        assert_eq!(m.flags & MF_NOBLOCKMAP, MF_NOBLOCKMAP);
        let s = info.state(m.spawnstate);
        assert_eq!(info.sprnames[s.sprite.idx()], "BSH2");
        assert_eq!((s.tics, s.next), (-1, StateNum(0)));
        // Inherited radius, own looping two-frame bright spawn.
        let t2 = info.type_for_doomednum(21007).unwrap();
        let m2 = *info.mobj(t2);
        assert_eq!(m2.radius, Fixed::from_int(8));
        let a = m2.spawnstate;
        let b = info.state(a).next;
        assert_eq!(info.state(b).next, a);
        assert_eq!(info.state(a).frame, FF_FULLBRIGHT);
        // Replacement keeps the imp's editor number, takes the new states.
        let imp = info.type_for_doomednum(3001).unwrap();
        assert_eq!(imp, MT_TROOP);
        let see = info.mobj(MT_TROOP).seestate;
        assert!(see.idx() >= base_states);
        assert_eq!(info.state(see).action, Action::Chase);
        assert_eq!(info.mobj(MT_TROOP).speed, 16);
        assert_eq!(info.mobj(MT_TROOP).spawnstate, S_TROO_STND);
    }
}

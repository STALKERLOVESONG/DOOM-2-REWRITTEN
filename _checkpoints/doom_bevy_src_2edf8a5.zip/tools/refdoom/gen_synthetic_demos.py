#!/usr/bin/env python3
"""Generate deterministic pseudo-random vanilla (v1.9) demo lumps that
exercise movement, combat, specials and monsters on every map.

Usage: gen_synthetic_demos.py <out dir> <seed base> <tics> <maps...>   (e.g. E1M1 MAP07)

The inputs are not meant to play well, just to wander, turn, fire, use and
switch weapons so the playsim visits as many code paths as possible.
"""
import os
import re
import sys



class Rng:
    def __init__(self, seed):
        self.s = (seed * 2654435761 + 12345) & 0xFFFFFFFF or 1

    def next(self):
        s = self.s
        s ^= (s << 13) & 0xFFFFFFFF
        s ^= s >> 17
        s ^= (s << 5) & 0xFFFFFFFF
        self.s = s
        return s

    def range(self, n):
        return self.next() % n


def make_demo(name, seed, tics):
    m = re.match(r"E(\d)M(\d)$", name)
    if m:
        episode, mapnum = int(m.group(1)), int(m.group(2))
    else:
        episode, mapnum = 1, int(name[3:])
    r = Rng(seed)
    skill = [3, 3, 2, 4, 1][seed % 5]  # mostly UV, some HMP/nightmare/easy
    header = bytes([109, skill, episode, mapnum, 0, 0, 0, 0, 0, 1, 0, 0, 0])
    body = bytearray()
    turn = 0
    mode_left = 0
    forward = 50
    side = 0
    for tic in range(tics):
        if mode_left == 0:
            mode_left = 10 + r.range(60)
            choice = r.range(10)
            forward = [50, 50, 50, 25, -25, 0, 50, 50, 50, -50][choice]
            side = [0, 0, 40, -40, 0, 40, 0, 0, -24, 24][r.range(10)]
            turn = [0, 0, 0, 3, -3, 6, -6, 1, -1, 12][r.range(10)]
        mode_left -= 1
        buttons = 0
        if r.range(3) == 0:
            buttons |= 1  # BT_ATTACK
        if r.range(25) == 0:
            buttons |= 2  # BT_USE
        if r.range(150) == 0:
            buttons |= 4 | (r.range(7) << 3)  # BT_CHANGE + weapon
        body += bytes([forward & 0xFF, side & 0xFF, turn & 0xFF, buttons])
    body.append(0x80)
    return header + bytes(body)


def main():
    out, seed, tics = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    os.makedirs(out, exist_ok=True)
    for i, name in enumerate(sys.argv[4:]):
        # The file name becomes a lump name when loaded, so it must not
        # collide with the map marker.
        with open(os.path.join(out, "D" + name + ".lmp"), "wb") as f:
            f.write(make_demo(name, seed + i, tics))


if __name__ == "__main__":
    main()

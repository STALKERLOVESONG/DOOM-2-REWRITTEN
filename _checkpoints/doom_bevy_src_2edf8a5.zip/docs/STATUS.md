# Status

Updated 2026-10-06.

## Project direction

- **The goal:** a clean, dependency-light, Rust-native Doom engine. It should be broadly faithful to classic Doom and serve as a foundation for new rendering features, gameplay systems, weapons, monsters, maps, effects and scripting.
- **Chocolate Doom is an oracle, not a spec.** Use it to catch major correctness bugs. Minor visual differences are acceptable.
- **Vanilla quirks:** reproduce them only when they materially affect gameplay or compatibility. Prefer clear, extensible code over copying how the C engine was implemented.
- **Done means playable and extensible,** not bit-exact.

## Works

- **Content:** WAD loading with PWAD overrides; palettes, colormaps, patches, flats, textures, sprites, sounds, music, maps (vanilla format); IWAD identification.
- **Playsim:** complete vanilla single-player gameplay. The 4 IWAD demos and 72 synthetic demos stay in sync with Chocolate Doom.
- **Classic renderer:** the vanilla column/span renderer. It matches Chocolate Doom frame for frame on the IWAD demos at the default view size.
- **Perspective renderer (default):** a polygon renderer through a free camera with yaw and **true pitch** (freelook).
  - Walls, flats, sky, sprites, masked midtextures are all perspective correct; nothing is stretched.
  - It uses the vanilla pegging rules, light tables, sprite rotations, fuzz and translations.
  - At pitch 0 it lines up with the classic renderer.
  - Sky follows vanilla's rules (sky ceilings are open to the sky; the both-sky upper-wall rule; missing upper/lower textures show the neighbouring flat as in vanilla). Above and below the sky texture it fades into a solid colour.
  - ~2–4 ms per frame at 320×200 on the IWAD maps (release build, one core).
- **Sound:** sound effects with vanilla `s_sound.c` logic (8 channels, priorities, distance attenuation and stereo separation); OPL2 music from MUS + GENMIDI, emulating the DMX driver.
- **Presentation:** title pages and the demo loop, menus (new game, episode, skill, options, sound volume, read-this, quit/end-game prompts), status bar and face, full-screen HUD, view border, HUD messages, automap (with `iddt`), intermission tally and episode maps, finales (text, art, bunny scroll, cast call), pause, palette flashes. All drawn in screen space from WAD graphics.
- **Bevy host:** window, keyboard/mouse at 35 Hz, auto mouse capture, mouse/keyboard freelook, audio output, 4:3 presentation, fullscreen, screenshots.
  - The previous host version compiled against real Bevy 0.16.1 on Windows. This version (audio, freelook, key routing) was type-checked against a stub here, because crates.io is unreachable from this container; it still needs a real build.

## Corpses at map start

- The corpses at map start are **authored map things**, not engine-created.
  - E1M1 has dead marines (doomednum 15), bloody messes (10/12) and pools of blood (24).
- All monsters are alive at spawn and still alive after 10 seconds (checked on E1M1–3 and E2M1).
- Demo state hashes from tic 0 match Chocolate Doom.
- `crates/doom_game/examples/corpse_probe.rs` lists them per map.

## Known limitations

- **Freelook is presentation only.** Hitscan and projectiles still aim with vanilla autoaim, not along the view pitch.
- **Perspective renderer:**
  - Sprites are clipped by the depth buffer, so a sprite partly inside a wall is cut where vanilla would draw it whole.
  - There is no occlusion culling beyond the view cone, so very large maps may be slower.
- **Audio:**
  - OPL rhythm mode and 4-op voices are not emulated (DMX doesn't use them).
  - There is no PC speaker, MIDI or OGG/MP3/MOD music.
  - Sound lumps are resampled linearly.
- **Not implemented:** savegames (the save/load menus say so), multiplayer, DEHACKED, PK3, UDMF, ZDoom nodes.
- **IWAD quirk:** the bundled `doom1.wad` is Ultimate Doom but lacks `M_EPI4`, so the menu draws "Thy Flesh Consumed" in the HUD font.

## Next (proposed order)

1. **Play-test on real hardware:** feel of mouse/freelook, audio latency, renderer edge cases.
2. **Savegames:** serialize the World and session state.
3. **Optional vertical aiming along the view pitch,** as a compatibility option that is off for demos.
4. **Mod formats:** DEHACKED, then PK3 (zip/inflate), UDMF, ZDoom nodes. These are prerequisites for MyHouse-style content.
5. **Data-driven actors and weapons,** plus renderer extension points: dynamic lights, 3D floors and slopes on the perspective renderer.

## Tooling

- **Frame dumps:** `cargo run -p doom_render --release --example demo_frames -- <iwad> DEMO1 <out> 11 0 70 400` writes PNGs.
- **Pitch shots:** `cargo run -p doom_game --release --example pitch_shots -- <iwad> <out> E1M1` renders classic vs perspective at several pitches, plus sky views.
- **UI shots:** `cargo run -p doom_game --release --example ui_shots -- <iwad> <out>` saves every presentation state.
- **Reference oracle:** see `tools/refdoom`. Fixtures cover demo sync and frame hashes.
- **Open renderer item, parked:** a 1-pixel low-detail difference in two frames of `full_low` DEMO2/DEMO3.

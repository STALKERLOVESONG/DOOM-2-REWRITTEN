//! [`Session`]: one running game. Owns the loaded content, the simulation
//! [`World`] and the software [`Renderer`], and does what g_game.c,
//! st_stuff.c (palette) and hu_stuff.c (messages) do around the playsim.
//!
//! Hosts (the Bevy app, tools, tests) drive it with [`Session::tick`] at
//! 35 Hz and read frames with [`Session::render_rgba`].

use std::path::PathBuf;

use doom_content::game::{GameInfo, GameMode};
use doom_content::texture::TextureSet;
use doom_content::ResourceStack;
use doom_render::{Limits, RenderData, Renderer, SCREENHEIGHT, SCREENWIDTH};
use doom_sim::content::ContentInfo;
use doom_sim::demo::Demo;
use doom_sim::info::Info;
use doom_sim::player::{cheat, power, PlayerState, Weapon, MAXPLAYERS, NUMWEAPONS};
use doom_sim::ticcmd::{InputState, TicCmd, TicCmdBuilder};
use doom_sim::world::{GameExit, SimEvent};
use doom_sim::{GameAction, GameParams, Level, Skill, World};

use crate::maps::{next_map, MapRef, Next};

/// Tics per second.
pub const TICRATE: u32 = 35;
/// `HU_MSGTIMEOUT`.
const MESSAGE_TICS: u32 = 4 * TICRATE;

#[derive(Clone, Debug)]
pub struct SessionConfig {
    pub iwad: PathBuf,
    pub pwads: Vec<PathBuf>,
    /// Starting map (`E1M1`, `MAP01`, `-warp` forms). Default: first map.
    pub map: Option<String>,
    pub skill: Skill,
    pub nomonsters: bool,
    pub fast: bool,
    pub respawn: bool,
    /// Play this demo (lump name or file path) instead of taking input.
    pub demo: Option<String>,
}

impl SessionConfig {
    pub fn new(iwad: impl Into<PathBuf>) -> Self {
        SessionConfig {
            iwad: iwad.into(),
            pwads: Vec::new(),
            map: None,
            skill: Skill::Medium,
            nomonsters: false,
            fast: false,
            respawn: false,
            demo: None,
        }
    }
}

/// Snapshot of what a status bar / HUD shows.
#[derive(Clone, Debug, Default)]
pub struct Hud {
    pub map: String,
    pub health: i32,
    pub armor: i32,
    pub weapon: Weapon,
    /// (current, max) for the ready weapon's ammo type; `None` for fist/chainsaw.
    pub ammo: Option<(i32, i32)>,
    /// (current, max) per ammo type: bullets, shells, cells, rockets.
    pub all_ammo: [(i32, i32); 4],
    pub weapons_owned: [bool; NUMWEAPONS],
    /// Blue, yellow, red cards; blue, yellow, red skulls.
    pub keys: [bool; 6],
    pub kills: (i32, i32),
    pub items: (i32, i32),
    pub secrets: (i32, i32),
    pub dead: bool,
    pub god: bool,
    pub noclip: bool,
    /// Pickup/cheat/level message currently shown.
    pub message: Option<String>,
    /// Seconds into the level.
    pub level_seconds: u32,
}

struct DemoPlayback {
    demo: Demo,
    pos: usize,
}

pub struct Session {
    pub stack: ResourceStack,
    pub textures: TextureSet,
    pub game: GameInfo,
    pub render_data: RenderData,
    pub world: World,
    pub renderer: Renderer,
    current: MapRef,
    base_params: GameParams,
    screen: Vec<u8>,
    builder: TicCmdBuilder,
    demo: Option<DemoPlayback>,
    message: Option<(String, u32)>,
    events: Vec<SimEvent>,
    /// Content warnings collected while loading (PWAD problems etc.).
    pub warnings: Vec<String>,
}

impl Session {
    pub fn new(cfg: &SessionConfig) -> Result<Session, String> {
        let stack = ResourceStack::load(&cfg.iwad, &cfg.pwads).map_err(|e| format!("loading WADs: {e}"))?;
        let textures = TextureSet::load(&stack).map_err(|e| format!("textures: {e}"))?;
        let game = doom_content::game::identify(&stack, None).ok_or("not a Doom IWAD (no map or game lumps found)")?;
        let render_data = RenderData::build(&stack, &textures, &Info::doom().sprnames).map_err(|e| format!("graphics: {e}"))?;
        let mut warnings = stack.warnings.clone();
        warnings.extend(render_data.warnings.iter().cloned());

        let demo = match &cfg.demo {
            Some(d) => {
                let data = match stack.lump(&d.to_ascii_uppercase()) {
                    Some(l) => l.to_vec(),
                    None => std::fs::read(d).map_err(|e| format!("demo {d}: {e}"))?,
                };
                Some(Demo::parse(&data)?)
            }
            None => None,
        };

        let (start, params, playeringame) = match &demo {
            Some(d) => (
                MapRef::new(d.episode, d.map),
                GameParams {
                    mode: game.mode,
                    version: game.version,
                    skill: d.skill,
                    episode: d.episode,
                    map: d.map,
                    deathmatch: d.deathmatch,
                    netgame: d.playeringame[1..].iter().any(|&p| p),
                    respawnmonsters: d.respawnparm,
                    nomonsters: d.nomonsters,
                    fastparm: d.fastparm,
                    consoleplayer: d.consoleplayer,
                },
                d.playeringame,
            ),
            None => {
                let start = match &cfg.map {
                    Some(m) => MapRef::parse(m, game.mode).ok_or_else(|| format!("bad map name {m}"))?,
                    None => first_map(&stack, game.mode).ok_or("the WADs contain no playable map")?,
                };
                let params = GameParams {
                    mode: game.mode,
                    version: game.version,
                    skill: cfg.skill,
                    episode: start.episode,
                    map: start.map,
                    deathmatch: 0,
                    netgame: false,
                    respawnmonsters: cfg.respawn,
                    nomonsters: cfg.nomonsters,
                    fastparm: cfg.fast,
                    consoleplayer: 0,
                };
                let mut pig = [false; MAXPLAYERS];
                pig[0] = true;
                (start, params, pig)
            }
        };
        if !start.exists(&stack, game.mode) {
            return Err(format!("map {} not found", start.lump_name(game.mode)));
        }
        let level = Level::load(&stack, &textures, &start.lump_name(game.mode)).map_err(|e| e.to_string())?;
        warnings.extend(level.warnings.iter().cloned());
        let content = ContentInfo::from_content(&stack, &textures);
        let world = World::new_game(Info::doom(), content, params, playeringame, level)?;

        let mut s = Session {
            stack,
            textures,
            game,
            render_data,
            world,
            renderer: Renderer::new(11, false, Limits::VANILLA),
            current: start,
            base_params: params,
            screen: vec![0; SCREENWIDTH * SCREENHEIGHT],
            builder: TicCmdBuilder::default(),
            demo: demo.map(|demo| DemoPlayback { demo, pos: 0 }),
            message: None,
            events: Vec::new(),
            warnings,
        };
        s.show_message(format!("{}", s.map_name()));
        Ok(s)
    }

    pub fn map(&self) -> MapRef {
        self.current
    }

    pub fn map_name(&self) -> String {
        self.current.lump_name(self.game.mode)
    }

    pub fn is_demo(&self) -> bool {
        self.demo.is_some()
    }

    /// True once a demo has played all its tics.
    pub fn demo_finished(&self) -> bool {
        self.demo.as_ref().is_some_and(|d| d.pos >= d.demo.tics.len())
    }

    /// View size as in the vanilla menu: 3..=11 (10 = full width with status
    /// bar area, 11 = full screen).
    pub fn set_view(&mut self, screenblocks: i32, low_detail: bool) {
        self.renderer.set_view_size(screenblocks.clamp(3, 11), low_detail);
    }

    /// Show a HUD message for the standard 4 seconds.
    pub fn show_message(&mut self, m: impl Into<String>) {
        self.message = Some((m.into(), MESSAGE_TICS));
    }

    /// Run one 35 Hz tic with this input (ignored during demo playback).
    pub fn tick(&mut self, input: &InputState) {
        let mut cmds = [TicCmd::default(); MAXPLAYERS];
        match &mut self.demo {
            Some(d) => {
                let Some(c) = d.demo.tics.get(d.pos) else { return };
                cmds = *c;
                d.pos += 1;
            }
            None => cmds[self.world.params.consoleplayer] = self.builder.build(input),
        }

        match self.world.tick(&cmds) {
            None => {}
            Some(GameAction::LoadLevel) => {
                // Single-player death: `G_DoReborn` reloads the level; the
                // tic then runs on the fresh level as in G_Ticker.
                if let Err(e) = self.reload_level() {
                    self.show_message(e);
                    return;
                }
                self.world.tick(&cmds);
            }
            Some(GameAction::Completed(exit)) => self.level_completed(exit),
        }

        // HU_Ticker: pick up the player's message.
        let p = &mut self.world.players[self.world.params.consoleplayer];
        if let Some(m) = p.message.take() {
            self.message = Some((m.to_string(), MESSAGE_TICS));
        }
        if let Some((_, t)) = &mut self.message {
            *t = t.saturating_sub(1);
            if *t == 0 {
                self.message = None;
            }
        }
        self.events.append(&mut self.world.events);
    }

    /// Sound and other presentation events produced since the last call.
    pub fn take_events(&mut self) -> Vec<SimEvent> {
        std::mem::take(&mut self.events)
    }

    fn load_level(&self, m: MapRef) -> Result<Level, String> {
        Level::load(&self.stack, &self.textures, &m.lump_name(self.game.mode)).map_err(|e| e.to_string())
    }

    fn reload_level(&mut self) -> Result<(), String> {
        let level = self.load_level(self.current)?;
        self.world.setup_level(level)
    }

    /// Intermission is not implemented yet: report the level's totals as a
    /// message and continue immediately.
    fn level_completed(&mut self, exit: GameExit) {
        let p = self.world.console_player();
        let pct = |n: i32, total: i32| if total > 0 { n * 100 / total } else { 100 };
        let summary = format!(
            "{} done - kills {}% items {}% secrets {}%",
            self.map_name(),
            pct(p.killcount, self.world.totalkills),
            pct(p.itemcount, self.world.totalitems),
            pct(p.secretcount, self.world.totalsecret)
        );
        let result = match next_map(self.game.mode, self.current, exit == GameExit::Secret) {
            Next::Map(m) if m.exists(&self.stack, self.game.mode) => self.enter_map(m),
            // Finale not implemented: start the next episode (or the first
            // one again) as a new game.
            _ => {
                let m = MapRef::new(self.current.episode + 1, 1);
                let m = if self.game.mode != GameMode::Commercial && m.exists(&self.stack, self.game.mode) {
                    m
                } else {
                    first_map(&self.stack, self.game.mode).unwrap_or(self.current)
                };
                self.new_game(m)
            }
        };
        match result {
            Ok(()) => self.show_message(summary),
            Err(e) => self.show_message(e),
        }
    }

    /// Continue to `m` keeping inventory.
    fn enter_map(&mut self, m: MapRef) -> Result<(), String> {
        let level = self.load_level(m)?;
        self.world.next_level(m.episode, m.map, level)?;
        self.current = m;
        Ok(())
    }

    /// Start a fresh game on `m` (new inventory), like `G_InitNew`.
    pub fn new_game(&mut self, m: MapRef) -> Result<(), String> {
        if !m.exists(&self.stack, self.game.mode) {
            return Err(format!("map {} not found", m.lump_name(self.game.mode)));
        }
        let level = self.load_level(m)?;
        let mut params = self.base_params;
        params.episode = m.episode;
        params.map = m.map;
        let content = ContentInfo::from_content(&self.stack, &self.textures);
        self.world = World::new_game(Info::doom(), content, params, self.world.playeringame, level)?;
        self.current = m;
        self.show_message(self.map_name());
        Ok(())
    }

    // ---- developer cheats (st_stuff.c equivalents) ------------------------

    fn player_mut(&mut self) -> &mut doom_sim::player::Player {
        let cp = self.world.params.consoleplayer;
        &mut self.world.players[cp]
    }

    /// `iddqd`.
    pub fn toggle_god(&mut self) {
        let p = self.player_mut();
        p.cheats ^= cheat::GODMODE;
        let on = p.cheats & cheat::GODMODE != 0;
        if on {
            p.health = 100;
            if let Some(mo) = p.mo {
                self.world.mo_mut(mo).health = 100;
            }
        }
        self.show_message(if on { "Degreelessness Mode On" } else { "Degreelessness Mode Off" });
    }

    /// `idclip`.
    pub fn toggle_noclip(&mut self) {
        let p = self.player_mut();
        p.cheats ^= cheat::NOCLIP;
        let on = p.cheats & cheat::NOCLIP != 0;
        self.show_message(if on { "No Clipping Mode ON" } else { "No Clipping Mode OFF" });
    }

    /// `idkfa`.
    pub fn give_all(&mut self) {
        let p = self.player_mut();
        p.armorpoints = 200;
        p.armortype = 2;
        p.weaponowned = [true; NUMWEAPONS];
        p.ammo = p.maxammo;
        p.cards = [true; 6];
        self.show_message("Very Happy Ammo Added");
    }

    /// `idclev`: new game on another map.
    pub fn warp(&mut self, map: &str) -> Result<(), String> {
        let m = MapRef::parse(map, self.game.mode).ok_or_else(|| format!("bad map name {map}"))?;
        self.new_game(m)
    }

    /// Exit the level as if the exit switch was used.
    pub fn exit_level(&mut self) {
        self.level_completed(GameExit::Normal);
    }

    // ---- presentation -------------------------------------------------------

    /// `ST_doPaletteStuff`: PLAYPAL index for damage/pickup/radiation tints.
    pub fn palette_index(&self) -> usize {
        let p = self.world.console_player();
        let mut cnt = p.damagecount;
        if p.powers[power::STRENGTH] != 0 {
            // Slowly fade the berserk out.
            let bzc = 12 - (p.powers[power::STRENGTH] >> 6);
            cnt = cnt.max(bzc);
        }
        if cnt > 0 {
            1 + (((cnt + 7) >> 3) as usize).min(7)
        } else if p.bonuscount > 0 {
            9 + (((p.bonuscount + 7) >> 3) as usize).min(3)
        } else if p.powers[power::IRONFEET] > 4 * 32 || p.powers[power::IRONFEET] & 8 != 0 {
            13
        } else {
            0
        }
    }

    /// Render the console player's view into the 320x200 palette-indexed
    /// framebuffer and return it.
    pub fn render_indexed(&mut self) -> &[u8] {
        if self.world.console_player().mo.is_some() {
            self.renderer.render_player_view(&self.render_data, &self.world, self.world.params.consoleplayer, &mut self.screen);
        }
        &self.screen
    }

    /// Render and convert to RGBA8 (`out.len() == 320 * 200 * 4`), applying
    /// the current palette effect.
    pub fn render_rgba(&mut self, out: &mut [u8]) {
        assert_eq!(out.len(), SCREENWIDTH * SCREENHEIGHT * 4);
        let pal = *self.render_data.palettes.get(self.palette_index());
        let screen = self.render_indexed();
        for (px, &i) in out.chunks_exact_mut(4).zip(screen) {
            let [r, g, b] = pal[i as usize];
            px.copy_from_slice(&[r, g, b, 255]);
        }
    }

    pub fn hud(&self) -> Hud {
        let w = &self.world;
        let p = w.console_player();
        let ammo_of = |i: usize| (p.ammo[i], p.maxammo[i]);
        let ammo_type = w.weaponinfo.get(p.readyweapon as usize).map_or(usize::MAX, |wi| wi.ammo);
        Hud {
            map: self.map_name(),
            health: p.health,
            armor: p.armorpoints,
            weapon: p.readyweapon,
            ammo: (ammo_type < 4).then(|| ammo_of(ammo_type)),
            // Bullets, shells, cells, rockets (status bar order).
            all_ammo: [ammo_of(0), ammo_of(1), ammo_of(3), ammo_of(2)],
            weapons_owned: p.weaponowned,
            keys: p.cards,
            kills: (p.killcount, w.totalkills),
            items: (p.itemcount, w.totalitems),
            secrets: (p.secretcount, w.totalsecret),
            dead: p.playerstate == PlayerState::Dead,
            god: p.cheats & cheat::GODMODE != 0,
            noclip: p.cheats & cheat::NOCLIP != 0,
            message: self.message.as_ref().map(|(m, _)| m.clone()),
            level_seconds: (w.leveltime.max(0) as u32) / TICRATE,
        }
    }
}

/// The first map present: E1M1 / MAP01, else the first map lump found.
fn first_map(stack: &ResourceStack, mode: GameMode) -> Option<MapRef> {
    let preferred = MapRef::new(1, 1);
    if preferred.exists(stack, mode) {
        return Some(preferred);
    }
    doom_content::map::list_maps(stack).iter().find_map(|n| MapRef::parse(&n.to_string(), mode))
}

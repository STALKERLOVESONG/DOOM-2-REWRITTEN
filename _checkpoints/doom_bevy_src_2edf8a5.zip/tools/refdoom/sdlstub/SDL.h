#include "SDL_stdinc.h"
#include "SDL_filesystem.h"
#include "SDL_endian.h"
typedef union { int type; } SDL_Event;

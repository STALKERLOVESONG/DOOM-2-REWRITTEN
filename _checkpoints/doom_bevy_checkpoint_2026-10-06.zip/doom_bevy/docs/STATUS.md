# Status

Updated 2026-10-06.

## Project direction

- **The goal:** a clean, dependency-light, Rust-native Doom engine. It should be broadly faithful to classic Doom and serve as a foundation for new rendering features, gameplay systems, weapons, monsters, maps, effects and scripting.
- **Chocolate Doom is an oracle, not a spec.** Use it to catch major correctness bugs. Minor visual differences are acceptable.
- **Vanilla quirks:** reproduce them only when they materially affect gameplay or compatibility. Prefer clear, extensible code over copying how the C engine was implemented.
- **Done means playable and extensible,** not bit-exact.

## Works

- **Content:** WAD loading with PWAD overrides; palettes, colormaps, patches, flats, textures, sprites, maps (vanilla format); IWAD identification.
- **Playsim:** complete vanilla single-player gameplay, i.e. movement/collision, monsters, weapons, damage, pickups, doors/lifts/floors/ceilings/lights/switches/teleports, specials.
  - The 4 IWAD demos and 72 synthetic demos stay in sync with Chocolate Doom.
- **Renderer:** full software renderer (walls, flats, sky, sprites, weapon sprites, fuzz, low detail, view sizes).
  - It matches Chocolate Doom on the IWAD demos at the default view size.
- **Session layer (`doom_game`):**
  - start a game, run tics, death → restart, level exits (normal and secret) with inventory carried over
  - episode end → next episode
  - demo playback, palette flashes, HUD data, typed cheats, warp
- **Bevy host:** window, keyboard/mouse input at 35 Hz, scaled 4:3 presentation, text HUD.
  - It was written against the Bevy 0.16.1 source and type-checked against a stub. It has **not been built against the real Bevy here**: crates.io is unreachable from this container.

## Not yet

- **No sound.** Sound events are produced and dropped.
- **No status bar graphics, menus, automap, intermission screens or finales.** Levels advance immediately and show a one-line summary.
- **No savegames.**
- **No DEHACKED, PK3, UDMF or extended (ZDoom) nodes.** These are needed for most modern mods, including MyHouse.
- **No multiplayer.**

## Next (proposed order)

1. Build and run the host on a real machine, then fix whatever Bevy compile errors or runtime issues show up.
2. **Sound effects:** decode DMX lumps and mix them in the host via `SimEvent`s, positioned like `S_StartSound`.
3. **Status bar and HUD** drawn from WAD graphics; menus (new game, options, quit); automap.
4. **Intermission and finale screens.**
5. **Savegames:** serialize the World.
6. **Mod-format support:** DEHACKED, PK3 (zip/inflate), UDMF, ZDoom nodes, then actor/gameplay definitions.
7. **Engine extensibility:** data-driven actors and weapons, renderer extension points.

## Tooling

- **Frame dumps:** `cargo run -p doom_render --release --example demo_frames -- <iwad> DEMO1 <out> 11 0 70 400` writes PNGs.
- **Reference oracle:** see `tools/refdoom` for the reference build and fixture generators. Fixtures cover demo sync and frame hashes.
- **Open renderer item, parked:** a 1-pixel low-detail difference in two frames of `full_low` DEMO2/DEMO3. It isn't worth chasing unless it shows a broader problem.

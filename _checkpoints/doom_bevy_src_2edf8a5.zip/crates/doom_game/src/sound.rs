//! Sound and music logic (s_sound.c): channel allocation by priority,
//! distance attenuation and stereo separation relative to the listener,
//! per-tic parameter updates, and music selection. Produces
//! [`AudioCommand`]s for whatever mixer the host runs.

use std::collections::HashMap;
use std::sync::Arc;

use doom_audio::{AudioCommand, Genmidi, Song, Sound};
use doom_content::game::GameMode;
use doom_content::ResourceStack;
use doom_core::fixed::fixed_mul;
use doom_core::geom::point_to_angle;
use doom_core::tables::finesine;
use doom_core::{Fixed, FRACBITS, FRACUNIT};
use doom_sim::info::{Info, MusicNum, SfxNum, MUSIC_NAMES, SFX_ITEMUP, SFX_SAWHIT, SFX_SAWUP, SFX_TINK};
use doom_sim::world::{SimEvent, SoundSource};
use doom_sim::{MobjId, World};

const S_CLIPPING_DIST: i32 = 1200 * FRACUNIT;
const S_CLOSE_DIST: i32 = 160 * FRACUNIT;
const S_ATTENUATOR: i32 = (S_CLIPPING_DIST - S_CLOSE_DIST) >> FRACBITS;
const S_STEREO_SWING: i32 = 96 * FRACUNIT;
const NORM_SEP: i32 = 128;
pub const NUM_CHANNELS: usize = 8;

#[derive(Clone, Copy, Debug)]
struct Channel {
    sfx: SfxNum,
    priority: i32,
    origin: Origin,
    /// Game tic at which the sample finishes playing.
    ends_at: u64,
}

/// Where a sound comes from. Mobj origins remember their last position so
/// a sound keeps its place after the mobj is removed.
#[derive(Clone, Copy, Debug, PartialEq)]
enum Origin {
    None,
    Mobj(MobjId, Fixed, Fixed),
    Point(Fixed, Fixed),
}

impl Origin {
    fn same_source(&self, other: &Origin) -> bool {
        match (self, other) {
            (Origin::Mobj(a, ..), Origin::Mobj(b, ..)) => a == b,
            (Origin::Point(ax, ay), Origin::Point(bx, by)) => ax == bx && ay == by,
            _ => false,
        }
    }
}

pub struct SoundSystem {
    channels: [Option<Channel>; NUM_CHANNELS],
    sounds: HashMap<usize, Option<Arc<Sound>>>,
    songs: HashMap<String, Option<Arc<Song>>>,
    pub genmidi: Option<Arc<Genmidi>>,
    /// snd_SfxVolume, 0..=127.
    sfx_volume: i32,
    current_music: Option<String>,
    out: Vec<AudioCommand>,
    tic: u64,
}

impl SoundSystem {
    pub fn new(stack: &ResourceStack) -> Self {
        let genmidi = stack.lump("GENMIDI").and_then(|l| Genmidi::parse(l).ok()).map(Arc::new);
        SoundSystem {
            channels: [None; NUM_CHANNELS],
            sounds: HashMap::new(),
            songs: HashMap::new(),
            genmidi,
            sfx_volume: 64,
            current_music: None,
            out: Vec::new(),
            tic: 0,
        }
    }

    /// Mixer commands produced since the last call.
    pub fn take_commands(&mut self) -> Vec<AudioCommand> {
        std::mem::take(&mut self.out)
    }

    /// Volumes in menu units (0..=15).
    pub fn set_volumes(&mut self, sfx: i32, music: i32) {
        self.sfx_volume = sfx.clamp(0, 15) * 8;
        self.out.push(AudioCommand::SetMusicVolume((music.clamp(0, 15) * 8) as u32));
    }

    fn sound(&mut self, stack: &ResourceStack, info: &Info, sfx: SfxNum) -> Option<Arc<Sound>> {
        // Linked sounds (chgun -> pistol) play the linked lump.
        let mut idx = sfx.0 as usize;
        if let Some(l) = info.sfx.get(idx).and_then(|s| s.link) {
            idx = l.0 as usize;
        }
        self.sounds
            .entry(idx)
            .or_insert_with(|| {
                let name = info.sfx.get(idx)?.name;
                let lump = stack.lump(&format!("DS{}", name.to_ascii_uppercase()))?;
                Sound::parse_dmx(lump).map(Arc::new)
            })
            .clone()
    }

    fn stop_channel(&mut self, c: usize) {
        if self.channels[c].take().is_some() {
            self.out.push(AudioCommand::StopSound { channel: c });
        }
    }

    /// `S_Start`: stop all sounds at level start.
    pub fn stop_all(&mut self) {
        for c in 0..NUM_CHANNELS {
            self.stop_channel(c);
        }
    }

    /// `S_AdjustSoundParams`: volume and separation for a source, or None
    /// if out of earshot. `boss_map` disables clipping (vanilla map 8).
    fn adjust(&self, listener: (Fixed, Fixed, u32), x: Fixed, y: Fixed, boss_map: bool) -> Option<(i32, i32)> {
        let adx = (listener.0 - x).0.abs();
        let ady = (listener.1 - y).0.abs();
        // From _GG1_ p.428. Approx. Euclidean distance fast.
        let mut approx_dist = adx + ady - (adx.min(ady) >> 1);
        if !boss_map && approx_dist > S_CLIPPING_DIST {
            return None;
        }
        let mut angle = point_to_angle(x - listener.0, y - listener.1).0;
        if angle > listener.2 {
            angle = angle.wrapping_sub(listener.2);
        } else {
            angle = angle.wrapping_add(0xffff_ffff - listener.2);
        }
        let sep = 128 - (fixed_mul(Fixed(S_STEREO_SWING), finesine((angle >> 19) as usize)).0 >> FRACBITS);
        let vol = if approx_dist < S_CLOSE_DIST {
            self.sfx_volume
        } else if boss_map {
            approx_dist = approx_dist.min(S_CLIPPING_DIST);
            15 + ((self.sfx_volume - 15) * ((S_CLIPPING_DIST - approx_dist) >> FRACBITS)) / S_ATTENUATOR
        } else {
            (self.sfx_volume * ((S_CLIPPING_DIST - approx_dist) >> FRACBITS)) / S_ATTENUATOR
        };
        (vol > 0).then_some((vol, sep))
    }

    fn listener(w: &World) -> Option<(Fixed, Fixed, u32, MobjId)> {
        let id = w.console_player().mo?;
        let mo = w.thinkers.get_mobj(id)?;
        Some((mo.x, mo.y, mo.angle.0, id))
    }

    fn origin_of(w: &World, src: SoundSource) -> Origin {
        match src {
            SoundSource::None => Origin::None,
            SoundSource::Mobj(id) => match w.thinkers.get_mobj(id) {
                Some(m) => Origin::Mobj(id, m.x, m.y),
                None => Origin::None,
            },
            SoundSource::Sector(s) => {
                let o = w.level.sector(s).sound_org;
                Origin::Point(o.x, o.y)
            }
        }
    }

    /// `S_StartSound` for a sound with no world position (menus, HUD).
    pub fn start_local(&mut self, stack: &ResourceStack, info: &Info, sfx: SfxNum, rng: &mut doom_core::DoomRandom) {
        self.start(stack, info, sfx, Origin::None, None, false, rng);
    }

    /// Handle the sim's sound events for this tic.
    pub fn handle_events(&mut self, stack: &ResourceStack, w: &mut World, events: &[SimEvent], boss_map: bool) {
        let listener = Self::listener(w);
        for ev in events {
            match *ev {
                SimEvent::StartSound { origin, sfx } => {
                    let o = Self::origin_of(w, origin);
                    // The console player's own sounds are not positioned.
                    let o = match (o, listener) {
                        (Origin::Mobj(id, ..), Some((.., me))) if id == me => Origin::None,
                        _ => o,
                    };
                    let (info, rng) = (&w.info, &mut w.rng);
                    self.start(stack, info, sfx, o, listener.map(|l| (l.0, l.1, l.2)), boss_map, rng);
                }
                SimEvent::StopSound { origin } => {
                    for c in 0..NUM_CHANNELS {
                        if self.channels[c].is_some_and(|ch| matches!(ch.origin, Origin::Mobj(id, ..) if id == origin)) {
                            self.stop_channel(c);
                            break;
                        }
                    }
                }
            }
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn start(
        &mut self,
        stack: &ResourceStack,
        info: &Info,
        sfx: SfxNum,
        origin: Origin,
        listener: Option<(Fixed, Fixed, u32)>,
        boss_map: bool,
        rng: &mut doom_core::DoomRandom,
    ) {
        let Some(sinfo) = info.sfx.get(sfx.0 as usize).copied() else { return };
        let mut volume = self.sfx_volume;
        if sinfo.link.is_some() {
            volume += sinfo.volume;
            if volume < 1 {
                return;
            }
            volume = volume.min(self.sfx_volume);
        }
        let mut sep = NORM_SEP;
        if let (Origin::Mobj(_, x, y) | Origin::Point(x, y), Some(l)) = (origin, listener) {
            match self.adjust(l, x, y, boss_map) {
                Some((v, s)) => {
                    volume = v;
                    sep = if x == l.0 && y == l.1 { NORM_SEP } else { s };
                }
                None => return,
            }
        }
        // Pitch shifting is off (snd_pitchshift 0) but M_Random is still
        // consumed as in Chocolate Doom.
        if sfx.0 >= SFX_SAWUP.0 && sfx.0 <= SFX_SAWHIT.0 {
            rng.m_random();
        } else if sfx != SFX_ITEMUP && sfx != SFX_TINK {
            rng.m_random();
        }
        // S_StopSound(origin): kill a sound from the same source.
        if origin != Origin::None {
            for c in 0..NUM_CHANNELS {
                if self.channels[c].is_some_and(|ch| ch.origin.same_source(&origin)) {
                    self.stop_channel(c);
                    break;
                }
            }
        }
        // S_GetChannel
        let mut slot = None;
        for c in 0..NUM_CHANNELS {
            match self.channels[c] {
                None => {
                    slot = Some(c);
                    break;
                }
                Some(ch) if origin != Origin::None && ch.origin.same_source(&origin) => {
                    self.stop_channel(c);
                    slot = Some(c);
                    break;
                }
                _ => {}
            }
        }
        if slot.is_none() {
            // Find a lower or equal priority (higher number) sound to drop.
            slot = (0..NUM_CHANNELS).find(|&c| self.channels[c].is_some_and(|ch| ch.priority >= sinfo.priority));
            match slot {
                Some(c) => self.stop_channel(c),
                None => return,
            }
        }
        let Some(c) = slot else { return };
        let Some(sound) = self.sound(stack, info, sfx) else { return };
        let len_tics = (sound.seconds() * 35.0).ceil() as u64 + 1;
        self.channels[c] = Some(Channel { sfx, priority: sinfo.priority, origin, ends_at: self.tic + len_tics });
        self.out.push(AudioCommand::StartSound { channel: c, sound, volume, separation: sep });
    }

    /// `S_UpdateSounds`: once per tic, follow moving sources and free
    /// finished channels.
    pub fn update(&mut self, w: Option<&World>, boss_map: bool) {
        self.tic += 1;
        let listener = w.and_then(Self::listener);
        for c in 0..NUM_CHANNELS {
            let Some(mut ch) = self.channels[c] else { continue };
            if self.tic >= ch.ends_at {
                self.channels[c] = None;
                continue;
            }
            let Some(w) = w else { continue };
            // Track the source mobj while it exists.
            if let Origin::Mobj(id, ..) = ch.origin {
                if let Some(m) = w.thinkers.get_mobj(id) {
                    ch.origin = Origin::Mobj(id, m.x, m.y);
                    self.channels[c] = Some(ch);
                }
            }
            let (Origin::Mobj(_, x, y) | Origin::Point(x, y)) = ch.origin else { continue };
            let Some(l) = listener else { continue };
            let sinfo = w.info.sfx[ch.sfx.0 as usize];
            let mut vol_base = self.sfx_volume;
            if sinfo.link.is_some() {
                vol_base += sinfo.volume;
                if vol_base < 1 {
                    self.stop_channel(c);
                    continue;
                }
            }
            match self.adjust((l.0, l.1, l.2), x, y, boss_map) {
                Some((volume, separation)) => self.out.push(AudioCommand::UpdateSound { channel: c, volume, separation }),
                None => self.stop_channel(c),
            }
        }
    }

    /// `S_ChangeMusic` by music number.
    pub fn change_music(&mut self, stack: &ResourceStack, music: MusicNum, looping: bool) {
        let Some(name) = MUSIC_NAMES.get(music.0 as usize) else { return };
        self.change_music_lump(stack, &format!("D_{}", name.to_ascii_uppercase()), looping);
    }

    pub fn change_music_lump(&mut self, stack: &ResourceStack, lump: &str, looping: bool) {
        if self.current_music.as_deref() == Some(lump) {
            return;
        }
        let song = self
            .songs
            .entry(lump.to_string())
            .or_insert_with(|| stack.lump(lump).and_then(|d| Song::parse(d).ok()).map(Arc::new))
            .clone();
        self.current_music = Some(lump.to_string());
        match song {
            Some(song) => self.out.push(AudioCommand::PlayMusic { song, looping }),
            None => self.out.push(AudioCommand::StopMusic),
        }
    }

    pub fn stop_music(&mut self) {
        self.current_music = None;
        self.out.push(AudioCommand::StopMusic);
    }

    pub fn pause_music(&mut self, paused: bool) {
        self.out.push(AudioCommand::PauseMusic(paused));
    }

    /// `S_Start`'s music choice for a map.
    pub fn level_music(mode: GameMode, episode: i32, map: i32) -> MusicNum {
        use doom_sim::info::*;
        if mode == GameMode::Commercial {
            return MusicNum(MUS_RUNNIN.0 + (map - 1).clamp(0, 31) as u16);
        }
        let spmus = [MUS_E3M4, MUS_E3M2, MUS_E3M3, MUS_E1M5, MUS_E2M7, MUS_E2M4, MUS_E2M6, MUS_E2M5, MUS_E1M9];
        if episode < 4 {
            MusicNum(MUS_E1M1.0 + ((episode - 1) * 9 + map - 1).clamp(0, 26) as u16)
        } else {
            spmus[(map - 1).clamp(0, 8) as usize]
        }
    }
}

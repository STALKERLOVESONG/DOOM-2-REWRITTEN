//! Raw map lumps (doomdata.h) and map-format detection.
//!
//! These are the on-disk records, decoded but not interpreted: indices are
//! kept as raw `u16`/`i16` exactly as stored. Building the runtime level
//! (resolving references, converting to fixed point, grouping lines) is the
//! simulation's job (`doom_sim::level`).

use crate::le;
use crate::name::LumpName;
use crate::resources::{LumpId, ResourceStack};
use crate::ContentError;

/// Doom-format lump order after the map marker (`ML_THINGS`..`ML_BLOCKMAP`).
pub const DOOM_MAP_LUMPS: [&str; 10] =
    ["THINGS", "LINEDEFS", "SIDEDEFS", "VERTEXES", "SEGS", "SSECTORS", "NODES", "SECTORS", "REJECT", "BLOCKMAP"];

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MapFormat {
    /// Vanilla Doom binary format.
    Doom,
    /// Hexen binary format (BEHAVIOR lump; ZDoom "Doom-in-Hexen" maps).
    Hexen,
    /// Universal Doom Map Format (TEXTMAP ... ENDMAP).
    Udmf,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NodeFormat {
    /// Vanilla SEGS/SSECTORS/NODES.
    Vanilla,
    /// DeePBSP "xNd4" extended nodes.
    DeepBsp,
    /// ZDoom extended/compressed nodes ("XNOD", "ZNOD", GL variants).
    Zdoom([u8; 4]),
    /// No nodes present: a node builder would be required.
    Missing,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MapVertex {
    pub x: i16,
    pub y: i16,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub struct MapThing {
    pub x: i16,
    pub y: i16,
    /// Degrees (0 = east, 90 = north).
    pub angle: i16,
    pub kind: i16,
    pub options: i16,
}

/// Linedef flags (`ML_*`).
pub mod ml {
    pub const BLOCKING: u16 = 1;
    pub const BLOCKMONSTERS: u16 = 2;
    pub const TWOSIDED: u16 = 4;
    pub const DONTPEGTOP: u16 = 8;
    pub const DONTPEGBOTTOM: u16 = 16;
    pub const SECRET: u16 = 32;
    pub const SOUNDBLOCK: u16 = 64;
    pub const DONTDRAW: u16 = 128;
    pub const MAPPED: u16 = 256;
}

/// Thing option flags (`MTF_*`).
pub mod mtf {
    pub const EASY: i16 = 1;
    pub const NORMAL: i16 = 2;
    pub const HARD: i16 = 4;
    pub const AMBUSH: i16 = 8;
    /// "Not in single player" (vanilla checks bit 16 directly in P_SpawnMapThing).
    pub const NOTSINGLE: i16 = 16;
}

/// Sentinel for an absent sidedef in `MapLinedef::sidenum`.
pub const NO_SIDEDEF: u16 = 0xFFFF;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MapLinedef {
    pub v1: u16,
    pub v2: u16,
    pub flags: u16,
    pub special: i16,
    pub tag: i16,
    /// Front (right) and back (left) sidedef; `NO_SIDEDEF` if absent.
    pub sidenum: [u16; 2],
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MapSidedef {
    pub texture_offset: i16,
    pub row_offset: i16,
    pub top: LumpName,
    pub bottom: LumpName,
    pub mid: LumpName,
    pub sector: u16,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MapSector {
    pub floor_height: i16,
    pub ceiling_height: i16,
    pub floor_pic: LumpName,
    pub ceiling_pic: LumpName,
    pub light_level: i16,
    pub special: i16,
    pub tag: i16,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MapSubsector {
    pub num_segs: u16,
    pub first_seg: u16,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MapSeg {
    pub v1: u16,
    pub v2: u16,
    /// BAM >> 16.
    pub angle: i16,
    pub linedef: u16,
    /// 0 = front side of the linedef, 1 = back.
    pub side: i16,
    /// Distance along the linedef to the seg start.
    pub offset: i16,
}

/// Child flag: the child index refers to a subsector (`NF_SUBSECTOR`).
pub const NF_SUBSECTOR: u16 = 0x8000;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MapNode {
    pub x: i16,
    pub y: i16,
    pub dx: i16,
    pub dy: i16,
    /// [child][BOXTOP, BOXBOTTOM, BOXLEFT, BOXRIGHT]
    pub bbox: [[i16; 4]; 2],
    /// Right (0) and left (1) children.
    pub children: [u16; 2],
}

/// All lumps of one Doom-format map, decoded into records.
#[derive(Clone, Debug)]
pub struct RawMap {
    pub name: LumpName,
    pub things: Vec<MapThing>,
    pub linedefs: Vec<MapLinedef>,
    pub sidedefs: Vec<MapSidedef>,
    pub vertexes: Vec<MapVertex>,
    pub segs: Vec<MapSeg>,
    pub subsectors: Vec<MapSubsector>,
    pub nodes: Vec<MapNode>,
    pub sectors: Vec<MapSector>,
    /// Raw REJECT bytes (may be short or empty; see `doom_sim::level`).
    pub reject: Vec<u8>,
    /// Raw BLOCKMAP as 16-bit words (may be empty: vanilla has no builder).
    pub blockmap: Vec<i16>,
    /// Non-fatal oddities (lump names out of place, trailing bytes, ...).
    pub warnings: Vec<String>,
}

fn records<'a>(lump: &str, data: &'a [u8], size: usize, warnings: &mut Vec<String>) -> std::slice::ChunksExact<'a, u8> {
    if data.len() % size != 0 {
        // Vanilla computes the count as len / size and ignores the remainder.
        warnings.push(format!("{lump}: {} trailing bytes ignored", data.len() % size));
    }
    data.chunks_exact(size)
}

/// Locate a map's lumps and identify its format.
pub fn detect_format(stack: &ResourceStack, marker: LumpId) -> MapFormat {
    let next = stack.next_in_source(marker);
    let name_at = |id: Option<LumpId>| id.map(|i| stack.info(i).name);
    if name_at(next) == Some(LumpName::new("TEXTMAP")) {
        return MapFormat::Udmf;
    }
    // BEHAVIOR directly follows BLOCKMAP in Hexen-format maps.
    let mut id = next;
    for _ in 0..DOOM_MAP_LUMPS.len() {
        id = id.and_then(|i| stack.next_in_source(i));
    }
    if name_at(id) == Some(LumpName::new("BEHAVIOR")) {
        MapFormat::Hexen
    } else {
        MapFormat::Doom
    }
}

pub fn detect_node_format(nodes: &[u8], segs_len: usize, ssectors_len: usize) -> NodeFormat {
    if nodes.len() >= 4 {
        let sig = [nodes[0], nodes[1], nodes[2], nodes[3]];
        match &sig {
            b"xNd4" => return NodeFormat::DeepBsp,
            b"XNOD" | b"ZNOD" | b"XGLN" | b"ZGLN" | b"XGL2" | b"ZGL2" | b"XGL3" | b"ZGL3" => {
                return NodeFormat::Zdoom(sig)
            }
            _ => {}
        }
    }
    if nodes.is_empty() || segs_len == 0 || ssectors_len == 0 {
        NodeFormat::Missing
    } else {
        NodeFormat::Vanilla
    }
}

impl RawMap {
    /// Load a Doom-format map by marker name (`E1M1`, `MAP01`, ...).
    ///
    /// Like vanilla `P_SetupLevel`, lumps are taken **by position** after the
    /// marker (marker+1 is THINGS, ...), not by name. Names that do not match
    /// the expected order are reported as warnings.
    pub fn load(stack: &ResourceStack, map: &str) -> Result<Self, ContentError> {
        let name = LumpName::new(map);
        let marker = stack.check_num(name).ok_or_else(|| ContentError::MissingLump(name.to_string()))?;
        match detect_format(stack, marker) {
            MapFormat::Doom => {}
            MapFormat::Hexen => {
                return Err(ContentError::Unsupported {
                    what: format!("map {name}"),
                    reason: "Hexen-format map (BEHAVIOR lump)".into(),
                })
            }
            MapFormat::Udmf => {
                return Err(ContentError::Unsupported { what: format!("map {name}"), reason: "UDMF map (TEXTMAP)".into() })
            }
        }

        let mut warnings = Vec::new();
        let mut lumps: [&[u8]; 10] = [&[]; 10];
        let mut id = marker;
        for (i, expected) in DOOM_MAP_LUMPS.iter().enumerate() {
            id = stack.next_in_source(id).ok_or_else(|| ContentError::MissingLump(format!("{name}/{expected}")))?;
            let actual = stack.info(id).name;
            if actual != LumpName::new(expected) {
                warnings.push(format!("{name}: lump {} is {actual}, expected {expected} (used positionally)", i + 1));
            }
            lumps[i] = stack.data(id);
        }
        let [things, linedefs, sidedefs, vertexes, segs, ssectors, nodes, sectors, reject, blockmap] = lumps;

        match detect_node_format(nodes, segs.len(), ssectors.len()) {
            NodeFormat::Vanilla => {}
            other => {
                return Err(ContentError::Unsupported {
                    what: format!("map {name} nodes"),
                    reason: format!("{other:?} node format"),
                })
            }
        }

        let things = records("THINGS", things, 10, &mut warnings)
            .map(|c| MapThing {
                x: le::i16(c, 0),
                y: le::i16(c, 2),
                angle: le::i16(c, 4),
                kind: le::i16(c, 6),
                options: le::i16(c, 8),
            })
            .collect();
        let linedefs = records("LINEDEFS", linedefs, 14, &mut warnings)
            .map(|c| MapLinedef {
                v1: le::u16(c, 0),
                v2: le::u16(c, 2),
                flags: le::u16(c, 4),
                special: le::i16(c, 6),
                tag: le::i16(c, 8),
                sidenum: [le::u16(c, 10), le::u16(c, 12)],
            })
            .collect();
        let sidedefs = records("SIDEDEFS", sidedefs, 30, &mut warnings)
            .map(|c| MapSidedef {
                texture_offset: le::i16(c, 0),
                row_offset: le::i16(c, 2),
                top: LumpName::from_raw(&c[4..12]),
                bottom: LumpName::from_raw(&c[12..20]),
                mid: LumpName::from_raw(&c[20..28]),
                sector: le::u16(c, 28),
            })
            .collect();
        let vertexes = records("VERTEXES", vertexes, 4, &mut warnings)
            .map(|c| MapVertex { x: le::i16(c, 0), y: le::i16(c, 2) })
            .collect();
        let segs = records("SEGS", segs, 12, &mut warnings)
            .map(|c| MapSeg {
                v1: le::u16(c, 0),
                v2: le::u16(c, 2),
                angle: le::i16(c, 4),
                linedef: le::u16(c, 6),
                side: le::i16(c, 8),
                offset: le::i16(c, 10),
            })
            .collect();
        let subsectors = records("SSECTORS", ssectors, 4, &mut warnings)
            .map(|c| MapSubsector { num_segs: le::u16(c, 0), first_seg: le::u16(c, 2) })
            .collect();
        let nodes = records("NODES", nodes, 28, &mut warnings)
            .map(|c| {
                let bb = |o: usize| [le::i16(c, o), le::i16(c, o + 2), le::i16(c, o + 4), le::i16(c, o + 6)];
                MapNode {
                    x: le::i16(c, 0),
                    y: le::i16(c, 2),
                    dx: le::i16(c, 4),
                    dy: le::i16(c, 6),
                    bbox: [bb(8), bb(16)],
                    children: [le::u16(c, 24), le::u16(c, 26)],
                }
            })
            .collect();
        let sectors = records("SECTORS", sectors, 26, &mut warnings)
            .map(|c| MapSector {
                floor_height: le::i16(c, 0),
                ceiling_height: le::i16(c, 2),
                floor_pic: LumpName::from_raw(&c[4..12]),
                ceiling_pic: LumpName::from_raw(&c[12..20]),
                light_level: le::i16(c, 20),
                special: le::i16(c, 22),
                tag: le::i16(c, 24),
            })
            .collect();
        let blockmap = records("BLOCKMAP", blockmap, 2, &mut warnings).map(|c| le::i16(c, 0)).collect();

        Ok(RawMap {
            name,
            things,
            linedefs,
            sidedefs,
            vertexes,
            segs,
            subsectors,
            nodes,
            sectors,
            reject: reject.to_vec(),
            blockmap,
            warnings,
        })
    }
}

/// Map marker names present in the stack, in load order of their *last*
/// definition: `ExMy` and `MAPxx`.
pub fn list_maps(stack: &ResourceStack) -> Vec<LumpName> {
    let mut out: Vec<LumpName> = Vec::new();
    for i in 0..stack.num_lumps() {
        let n = stack.info(LumpId(i as u32)).name;
        if is_map_name(&n) && !out.contains(&n) {
            out.push(n);
        }
    }
    out
}

fn is_map_name(n: &LumpName) -> bool {
    let b = n.as_bytes();
    (b.len() == 4 && b[0] == b'E' && b[1].is_ascii_digit() && b[2] == b'M' && b[3].is_ascii_digit())
        || (b.len() == 5 && b.starts_with(b"MAP") && b[3].is_ascii_digit() && b[4].is_ascii_digit())
}

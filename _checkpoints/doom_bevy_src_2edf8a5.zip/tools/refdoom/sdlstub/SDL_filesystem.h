#ifndef REFDOOM_SDL_FILESYSTEM_H
#define REFDOOM_SDL_FILESYSTEM_H
#include <stdlib.h>
#include <string.h>
static inline char *SDL_GetPrefPath(const char *org, const char *app) { (void)org; (void)app; return strdup("./"); }
static inline char *SDL_GetBasePath(void) { return strdup("./"); }
#define SDL_free free
#endif

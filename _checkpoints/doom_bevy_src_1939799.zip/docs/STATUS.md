# Status

Updated 2026-10-07.

## Project direction

- **The goal:** a clean, dependency-light, Rust-native Doom engine. It should be broadly faithful to classic Doom and serve as a foundation for new rendering features, gameplay systems, weapons, monsters, maps, effects and scripting.
- **Chocolate Doom is an oracle, not a spec.** Use it to catch major correctness bugs. Minor visual differences are acceptable.
- **Vanilla quirks:** reproduce them only when they materially affect gameplay or compatibility. Prefer clear, extensible code over copying how the C engine was implemented.
- **Done means playable and extensible,** not bit-exact.

## Works

- **Content:** WAD loading with PWAD overrides; palettes, colormaps, patches, flats, textures, sprites, sounds, music, maps (vanilla format); IWAD identification.
- **Playsim:** complete vanilla single-player gameplay. The 4 IWAD demos and 72 synthetic demos stay in sync with Chocolate Doom.
- **Classic renderer:** the vanilla column/span renderer. It matches Chocolate Doom frame for frame on the IWAD demos at the default view size.
- **Perspective renderer (default):** a polygon renderer through a free camera with yaw and **true pitch** (freelook).
  - Walls, flats, sky, sprites, masked midtextures are all perspective correct; nothing is stretched.
  - It uses the vanilla pegging rules, light tables, sprite rotations, fuzz and translations.
  - At pitch 0 it lines up with the classic renderer.
  - Sky follows vanilla's rules (sky ceilings are open to the sky; the both-sky upper-wall rule; missing upper/lower textures show the neighbouring flat as in vanilla). Above and below the sky texture it fades into a solid colour.
  - ~2–4 ms per frame at 320×200 on the IWAD maps (release build, one core).
- **Sound:** sound effects with vanilla `s_sound.c` logic (8 channels, priorities, distance attenuation and stereo separation); OPL2 music from MUS + GENMIDI, emulating the DMX driver.
- **Presentation:** title pages and the demo loop, menus (new game, episode, skill, options, sound volume, read-this, quit/end-game prompts), status bar and face, full-screen HUD, view border, HUD messages, automap (with `iddt`), intermission tally and episode maps, finales (text, art, bunny scroll, cast call), pause, palette flashes. All drawn in screen space from WAD graphics.
- **Bevy host:** window, keyboard/mouse at 35 Hz, auto mouse capture, mouse/keyboard freelook, audio output, 4:3 presentation, fullscreen, screenshots.
  - The previous host version compiled against real Bevy 0.16.1 on Windows. This version (audio, freelook, key routing) was type-checked against a stub here, because crates.io is unreachable from this container; it still needs a real build.

## Verified against Chocolate Doom (2026-10-07)

- **Lighting.** `examples/light_compare.rs` renders demo frames with both renderers through special colormap tables that reveal, per pixel, the texel and the light level (colormap) used. Where both sample the same texel, the perspective renderer picks the same colormap as vanilla for 98.4–98.7% of pixels (mean difference 0.01 levels) at every view size and detail level.
  - Fixed: in low detail the perspective renderer drew walls at half height and lit everything with a 4× scale error (far too bright).
  - Fixed: pixel sample positions now follow vanilla's `centerx`/`centery`, so the same texels are sampled (72% vs 55%).
  - Fixed: the sky always uses colormap 0, as in vanilla.
  - Added: vanilla gamma correction (F11, `gammatable`).
  - Added: Chocolate Doom's presentation scaling. The 200 rows are scaled by 1.2 for the 4:3 display, and plain nearest scaling (the previous host) makes rows uneven, which breaks up the light bands. The host now upscales by an integer factor, then resizes smoothly.
  - Regression test: `crates/doom_game/tests/lighting.rs`.
- **Music.** `tools/refopl` builds Chocolate Doom's `i_oplmusic.c` + `mus2mid.c` + `midifile.c` + Nuked OPL3 into a deterministic renderer that logs every OPL register write.
  - Our MUS player issues the **same register writes in the same order** for all 32 songs in the IWAD (120 s each, at volumes 64 and 127): notes, instruments, volumes, pitch bends.
  - Replaying the reference's writes through our `Opl` reproduces its PCM **bit for bit**. This needed two fixes: Nuked's buffered register writes (2 native samples apart) and the chip's one-sample channel pipeline delay. Before these, there was a −17 dB error signal: inaudible phase differences, not wrong notes.
  - Timing: we tick at exactly 140 Hz like DMX. Chocolate drifts about 0.06% slow, because each event is scheduled from when the previous callback ran.
  - Regression test: `crates/doom_audio/tests/opl_reference.rs` with fixtures from `tools/refopl/gen_fixtures.sh`.
  - What the OPL path cannot do: sound like General MIDI / SoundFont playback (Roland SC-55, GZDoom's FluidSynth default). That needs a separate synthesizer; see the roadmap.

## Corpses at map start

- The corpses at map start are **authored map things**, not engine-created.
  - E1M1 has dead marines (doomednum 15), bloody messes (10/12) and pools of blood (24).
- All monsters are alive at spawn and still alive after 10 seconds (checked on E1M1–3 and E2M1).
- Demo state hashes from tic 0 match Chocolate Doom.
- `crates/doom_game/examples/corpse_probe.rs` lists them per map.

## Known limitations

- **Freelook is presentation only.** Hitscan and projectiles still aim with vanilla autoaim, not along the view pitch.
- **Perspective renderer:**
  - Sprites are clipped by the depth buffer, so a sprite partly inside a wall is cut where vanilla would draw it whole.
  - There is no occlusion culling beyond the view cone, so very large maps may be slower.
- **Audio:**
  - OPL rhythm mode and 4-op voices are not emulated (DMX doesn't use them).
  - There is no PC speaker, MIDI-file, General MIDI/SoundFont, or OGG/MP3/MOD music.
  - Sound lumps are resampled linearly.
  - The mixer runs at 44.1 kHz like Chocolate Doom. If the output device runs at another rate, Bevy's audio backend (rodio) resamples with plain linear interpolation.
- **Not implemented:** savegames (the save/load menus say so), multiplayer, DEHACKED, PK3, UDMF, ZDoom nodes.
- **IWAD quirk:** the bundled `doom1.wad` is Ultimate Doom but lacks `M_EPI4`, so the menu draws "Thy Flesh Consumed" in the HUD font.

## Roadmap

Agreed order: baseline authenticity (lighting, music: done above), then the formats needed to load `MyHouse.pk3`, then settings, then advanced rendering.

1. **Mod formats (next)**
   - **UDMF:** a `TEXTMAP` parser (zdoom namespace) into the existing level structures.
   - **ZDoom nodes:** XNOD/ZNOD/XGLN loading. ZNOD/ZGLN are zlib-compressed, so this needs a dependency-free inflate, which PK3 needs too.
   - **PK3:** a virtual filesystem that mounts zip archives into the ResourceStack's namespaces (`textures/`, `flats/`, `sprites/`, `sounds/`, `music/`, `maps/`).
   - **Content:** TX_START textures, `TEXTURES` lump, DECORATE (subset), MAPINFO/ZMAPINFO, DEHACKED.
   - **Music:** Standard MIDI files on the OPL player. PWADs ship `.mid` as well as MUS.
2. **Settings / CVars:** a typed CVar registry with config file persistence. First users: freelook on/off (pitch locked to the horizon), mouse look invert, gamma, renderer choice, scaling mode, music device.
3. **Optional General MIDI music:** a SoundFont (SF2) synthesizer as an alternative to OPL, chosen by a CVar.
4. **Advanced rendering (perspective renderer):** voxel models (KVX, then MagicaVoxel `.vox`) as a sprite replacement; MD3 / glTF models tied to actor definitions; later dynamic lights, slopes and 3D floors.
5. **Also outstanding:** savegames, optional vertical aiming along the view pitch.

## Tooling

- **Frame dumps:** `cargo run -p doom_render --release --example demo_frames -- <iwad> DEMO1 <out> 11 0 70 400` writes PNGs.
- **Pitch shots:** `cargo run -p doom_game --release --example pitch_shots -- <iwad> <out> E1M1` renders classic vs perspective at several pitches, plus sky views.
- **UI shots:** `cargo run -p doom_game --release --example ui_shots -- <iwad> <out>` saves every presentation state.
- **Reference oracle:** see `tools/refdoom`. Fixtures cover demo sync and frame hashes.
- **Music reference:** `tools/refopl` (`build.sh <chocolate checkout>`, then `compare_logs.py` against `cargo run -p doom_audio --release --example music_trace`).
- **Lighting comparison:** `cargo run -p doom_game --release --example light_compare -- <iwad> [out dir]` (`LOW_DETAIL=1`, `BLOCKS=n`).
- **Open renderer item, parked:** a 1-pixel low-detail difference in two frames of `full_low` DEMO2/DEMO3.

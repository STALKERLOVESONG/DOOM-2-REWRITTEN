/*
 * Differential-test fixture generator for doom_core.
 *
 * Links against Chocolate Doom's m_fixed.c / tables.c and contains verbatim
 * copies of R_PointToAngle (r_main.c) and P_AproxDistance (p_maputl.c), then
 * prints "<op> <a> <b> <result>" lines for a deterministic set of inputs.
 * The Rust tests replay the file and require bit-identical results.
 *
 * Build/run: tools/refharness/gen_core_fixtures.sh <chocolate-doom checkout>
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
#include "m_fixed.h"
#include "tables.h"

/* m_fixed.c pulls in I_Error via i_system.h on some paths; stub it. */
void I_Error(const char *error, ...) { fprintf(stderr, "I_Error: %s\n", error); exit(1); }

/* ---- verbatim from r_main.c (viewx/viewy folded into arguments) ---- */
static angle_t R_PointToAngle(fixed_t x, fixed_t y)
{
    if ((!x) && (!y)) return 0;
    if (x >= 0) {
        if (y >= 0) {
            if (x > y) return tantoangle[SlopeDiv(y, x)];
            else return ANG90 - 1 - tantoangle[SlopeDiv(x, y)];
        } else {
            y = -y;
            if (x > y) return -tantoangle[SlopeDiv(y, x)];
            else return ANG270 + tantoangle[SlopeDiv(x, y)];
        }
    } else {
        x = -x;
        if (y >= 0) {
            if (x > y) return ANG180 - 1 - tantoangle[SlopeDiv(y, x)];
            else return ANG90 + tantoangle[SlopeDiv(x, y)];
        } else {
            y = -y;
            if (x > y) return ANG180 + tantoangle[SlopeDiv(y, x)];
            else return ANG270 - 1 - tantoangle[SlopeDiv(x, y)];
        }
    }
    return 0;
}

/* ---- verbatim from p_maputl.c ---- */
static fixed_t P_AproxDistance(fixed_t dx, fixed_t dy)
{
    dx = abs(dx);
    dy = abs(dy);
    if (dx < dy) return dx + dy - (dx >> 1);
    return dx + dy - (dy >> 1);
}

static uint32_t rng = 0x12345678u;
static uint32_t next(void)
{
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    return rng;
}

/* Mix of full-range, small, and edge-case values. */
static int32_t pick(void)
{
    static const int32_t edges[] = { 0, 1, -1, 2, -2, 255, 256, 511, 512, -512, 65535, 65536, -65536,
        0x7fffffff, (int32_t)0x80000000, 0x3fff, 0x4000, 0x7fff, 0x8000, 0x10000, 0x40000000, -0x40000000 };
    uint32_t r = next();
    switch (r % 4) {
    case 0: return edges[next() % (sizeof edges / sizeof edges[0])];
    case 1: return (int32_t)next();                  /* full range */
    case 2: return (int32_t)(next() % 0x2000000) - 0x1000000; /* map-ish coordinates */
    default: return (int32_t)(next() % 0x40000) - 0x20000;    /* small */
    }
}

int main(void)
{
    int i;
    for (i = 0; i < 6000; i++) {
        int32_t a = pick(), b = pick();
        printf("mul %d %d %d\n", a, b, FixedMul(a, b));
        /* FixedDiv(INT_MIN, 0) slips past the overflow test (abs(INT_MIN) is
         * negative) and traps with a divide error in the original. */
        if (b == 0 && a == INT_MIN)
            printf("div %d %d CRASH\n", a, b);
        else
            printf("div %d %d %d\n", a, b, FixedDiv(a, b));
        printf("ang %d %d %u\n", a, b, (unsigned)R_PointToAngle(a, b));
        printf("dist %d %d %d\n", a, b, P_AproxDistance(a, b));
    }
    return 0;
}

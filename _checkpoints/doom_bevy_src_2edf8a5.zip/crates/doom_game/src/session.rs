//! [`Session`]: the running game front end. Owns the loaded content, the
//! simulation [`World`], the renderer and the presentation layer, and runs
//! the d_main.c / g_game.c flow around the playsim: title pages and demo
//! loop, levels, intermission, finale, menus, automap, status bar and sound.
//!
//! Hosts drive it with [`Session::tick`] at 35 Hz, feed key presses with
//! [`Session::key_down`]/[`Session::key_up`], present
//! [`Session::render_rgba`], and play [`Session::take_audio_commands`]
//! through a `doom_audio::Mixer`.

use std::path::PathBuf;
use std::sync::Arc;

use doom_audio::{AudioCommand, Genmidi};
use doom_content::game::{GameInfo, GameMode, GameVersion};
use doom_content::picture::Picture;
use doom_content::texture::TextureSet;
use doom_content::ResourceStack;
use doom_render::{Camera, Limits, PerspectiveRenderer, RenderData, Renderer, ViewRect, SCREENHEIGHT, SCREENWIDTH};
use doom_sim::content::ContentInfo;
use doom_sim::demo::Demo;
use doom_sim::info::{Info, SfxNum};
use doom_sim::player::{cheat, power, PlayerState, Weapon, MAXPLAYERS, NUMWEAPONS};
use doom_sim::ticcmd::{bt, InputState, TicCmd, TicCmdBuilder};
use doom_sim::world::{GameExit, SimEvent};
use doom_sim::{GameAction, GameParams, Level, Skill, World};

use crate::cheats::{Cheat, CheatMatcher};
use crate::maps::{next_map, MapRef, Next};
use crate::sound::SoundSystem;
use crate::ui::automap::Automap;
use crate::ui::finale::{Finale, FinaleEvent};
use crate::ui::gfx::{draw_patch, Font, Patches};
use crate::ui::hud::{map_title, Hud as HudText};
use crate::ui::intermission::{Intermission, WbStart, WiEvent};
use crate::ui::menu::{MenuAction, MenuSystem, Settings};
use crate::ui::status_bar::{StatusBar, ST_Y};
use crate::ui::{Key, ViewBorder};

/// Tics per second.
pub const TICRATE: u32 = 35;

/// Which renderer draws the 3D view.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum RenderMode {
    /// The vanilla column/span renderer (bit-exact with Chocolate Doom; no
    /// pitch).
    Classic,
    /// The polygon renderer with a free camera (true pitch / freelook).
    #[default]
    Perspective,
}

/// Freelook limit (radians). GZDoom's default range is similar; the
/// projection itself stays valid a little further (see
/// [`Camera::pitch_limit`]).
pub const MAX_PITCH: f32 = 50.0 * std::f32::consts::PI / 180.0;

#[derive(Clone, Debug)]
pub struct SessionConfig {
    pub iwad: PathBuf,
    pub pwads: Vec<PathBuf>,
    /// Starting map (`E1M1`, `MAP01`, `-warp` forms). `None` (and no demo)
    /// starts at the title screen with the demo loop, like vanilla.
    pub map: Option<String>,
    pub skill: Skill,
    pub nomonsters: bool,
    pub fast: bool,
    pub respawn: bool,
    /// Play this demo (lump name or file path) instead of taking input.
    pub demo: Option<String>,
    pub render_mode: RenderMode,
}

impl SessionConfig {
    pub fn new(iwad: impl Into<PathBuf>) -> Self {
        SessionConfig {
            iwad: iwad.into(),
            pwads: Vec::new(),
            map: None,
            skill: Skill::Medium,
            nomonsters: false,
            fast: false,
            respawn: false,
            demo: None,
            render_mode: RenderMode::default(),
        }
    }
}

/// Snapshot of the player's status, for tools and tests.
#[derive(Clone, Debug, Default)]
pub struct Hud {
    pub map: String,
    pub health: i32,
    pub armor: i32,
    pub weapon: Weapon,
    /// (current, max) for the ready weapon's ammo type; `None` for fist/chainsaw.
    pub ammo: Option<(i32, i32)>,
    pub weapons_owned: [bool; NUMWEAPONS],
    /// Blue, yellow, red cards; blue, yellow, red skulls.
    pub keys: [bool; 6],
    pub kills: (i32, i32),
    pub items: (i32, i32),
    pub secrets: (i32, i32),
    pub dead: bool,
    pub god: bool,
    pub noclip: bool,
    pub message: Option<String>,
    pub level_seconds: u32,
}

/// `gamestate_t`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum GameState {
    Level,
    Intermission,
    Finale,
    /// A title/credit page of the demo loop.
    DemoScreen,
}

struct DemoPlayback {
    demo: Demo,
    pos: usize,
    /// Part of the title loop (vs. `--playdemo`).
    attract: bool,
}

pub struct Session {
    pub stack: ResourceStack,
    pub textures: TextureSet,
    pub game: GameInfo,
    pub render_data: RenderData,
    pub world: World,
    pub renderer: Renderer,
    /// The free-camera renderer used in [`RenderMode::Perspective`].
    pub perspective: PerspectiveRenderer,
    pub render_mode: RenderMode,
    pub settings: Settings,
    /// View pitch in radians (> 0 looks up). Presentation only: the playsim
    /// still aims vertically with vanilla autoaim.
    look_pitch: f32,
    state: GameState,
    current: MapRef,
    base_params: GameParams,
    screen: Vec<u8>,
    builder: TicCmdBuilder,
    demo: Option<DemoPlayback>,
    /// `usergame`: a game the player started is in progress.
    usergame: bool,
    paused: bool,
    secret_exit: bool,
    demosequence: i32,
    pagetic: i32,
    page: Option<Arc<Picture>>,
    quit_countdown: Option<i32>,
    quit: bool,
    // Presentation.
    patches: Patches,
    font: Font,
    status_bar: StatusBar,
    hud_text: HudText,
    menu: MenuSystem,
    automap: Automap,
    border: ViewBorder,
    intermission: Option<Intermission>,
    finale: Option<Finale>,
    sound: SoundSystem,
    cheats: CheatMatcher,
    events: Vec<SimEvent>,
    /// Content warnings collected while loading (PWAD problems etc.).
    pub warnings: Vec<String>,
}

impl Session {
    pub fn new(cfg: &SessionConfig) -> Result<Session, String> {
        let stack = ResourceStack::load(&cfg.iwad, &cfg.pwads).map_err(|e| format!("loading WADs: {e}"))?;
        let textures = TextureSet::load(&stack).map_err(|e| format!("textures: {e}"))?;
        let game = doom_content::game::identify(&stack, None).ok_or("not a Doom IWAD (no map or game lumps found)")?;
        let render_data = RenderData::build(&stack, &textures, &Info::doom().sprnames).map_err(|e| format!("graphics: {e}"))?;
        let mut warnings = stack.warnings.clone();
        warnings.extend(render_data.warnings.iter().cloned());

        let start = match &cfg.map {
            Some(m) => MapRef::parse(m, game.mode).ok_or_else(|| format!("bad map name {m}"))?,
            None => first_map(&stack, game.mode).ok_or("the WADs contain no playable map")?,
        };
        if !start.exists(&stack, game.mode) {
            return Err(format!("map {} not found", start.lump_name(game.mode)));
        }
        let base_params = GameParams {
            mode: game.mode,
            version: game.version,
            skill: cfg.skill,
            episode: start.episode,
            map: start.map,
            deathmatch: 0,
            netgame: false,
            respawnmonsters: cfg.respawn,
            nomonsters: cfg.nomonsters,
            fastparm: cfg.fast,
            consoleplayer: 0,
        };
        let level = Level::load(&stack, &textures, &start.lump_name(game.mode)).map_err(|e| e.to_string())?;
        warnings.extend(level.warnings.iter().cloned());
        let content = ContentInfo::from_content(&stack, &textures);
        let world = World::new_game(Info::doom(), content, base_params, single_player(), level)?;

        let mut patches = Patches::default();
        let font = Font::load(&stack, &mut patches);
        let status_bar = StatusBar::new(&stack, &mut patches);
        let menu = MenuSystem::new(&stack, &mut patches, game);
        let automap = Automap::new(&stack, &mut patches, SCREENWIDTH as i32, ST_Y);
        let border = ViewBorder::new(&stack, &mut patches, game.mode);
        let sound = SoundSystem::new(&stack);
        let settings = Settings::default();

        let mut s = Session {
            stack,
            textures,
            game,
            render_data,
            world,
            renderer: Renderer::new(settings.screenblocks, settings.low_detail, Limits::VANILLA),
            perspective: PerspectiveRenderer::new(),
            render_mode: cfg.render_mode,
            settings,
            look_pitch: 0.0,
            state: GameState::Level,
            current: start,
            base_params,
            screen: vec![0; SCREENWIDTH * SCREENHEIGHT],
            builder: TicCmdBuilder::default(),
            demo: None,
            usergame: false,
            paused: false,
            secret_exit: false,
            demosequence: -1,
            pagetic: 0,
            page: None,
            quit_countdown: None,
            quit: false,
            patches,
            font,
            status_bar,
            hud_text: HudText::default(),
            menu,
            automap,
            border,
            intermission: None,
            finale: None,
            sound,
            cheats: CheatMatcher::default(),
            events: Vec::new(),
            warnings,
        };
        s.sound.set_volumes(s.settings.sfx_volume, s.settings.music_volume);

        if let Some(d) = &cfg.demo {
            let data = match s.stack.lump(&d.to_ascii_uppercase()) {
                Some(l) => l.to_vec(),
                None => std::fs::read(d).map_err(|e| format!("demo {d}: {e}"))?,
            };
            let demo = Demo::parse(&data)?;
            s.play_demo(demo, false)?;
        } else if cfg.map.is_some() {
            s.usergame = true;
            s.start_level();
        } else {
            s.start_title();
        }
        Ok(s)
    }

    // ---- queries ------------------------------------------------------------

    pub fn map(&self) -> MapRef {
        self.current
    }

    pub fn map_name(&self) -> String {
        self.current.lump_name(self.game.mode)
    }

    pub fn state(&self) -> GameState {
        self.state
    }

    pub fn is_demo(&self) -> bool {
        self.demo.is_some()
    }

    /// True once a `--playdemo` demo has played all its tics.
    pub fn demo_finished(&self) -> bool {
        match &self.demo {
            Some(d) => d.pos >= d.demo.tics.len(),
            None => !self.usergame && self.state != GameState::Level,
        }
    }

    pub fn menu_open(&self) -> bool {
        self.menu.is_open()
    }

    pub fn automap_active(&self) -> bool {
        self.automap.active
    }

    /// The host should stop: the player confirmed Quit.
    pub fn quit_requested(&self) -> bool {
        self.quit
    }

    /// Mouse capture makes sense: a level is being played by the user.
    pub fn wants_mouse(&self) -> bool {
        self.state == GameState::Level && self.demo.is_none() && !self.menu.is_open() && !self.paused
    }

    /// Arrow keys pan the automap instead of moving the player.
    pub fn captures_arrows(&self) -> bool {
        self.automap.active && !self.automap.follow()
    }

    /// The GENMIDI instrument bank for the host's mixer.
    pub fn genmidi(&self) -> Option<Arc<Genmidi>> {
        self.sound.genmidi.clone()
    }

    /// Mixer commands produced since the last call.
    pub fn take_audio_commands(&mut self) -> Vec<AudioCommand> {
        self.sound.take_commands()
    }

    /// Simulation events (sounds) seen since the last call.
    pub fn take_events(&mut self) -> Vec<SimEvent> {
        std::mem::take(&mut self.events)
    }

    /// Show a HUD message for the standard 4 seconds.
    pub fn show_message(&mut self, m: impl Into<String>) {
        self.hud_text.show(m);
    }

    /// View size as in the vanilla menu: 3..=11 (10 = full width above the
    /// status bar, 11 = full screen).
    pub fn set_view(&mut self, screenblocks: i32, low_detail: bool) {
        self.settings.screenblocks = screenblocks.clamp(3, 11);
        self.settings.low_detail = low_detail;
        self.apply_view();
    }

    fn apply_view(&mut self) {
        self.renderer.set_view_size(self.settings.screenblocks, self.settings.low_detail);
        self.look_pitch = self.look_pitch.clamp(-self.max_pitch(), self.max_pitch());
    }

    // ---- camera -------------------------------------------------------------

    /// Current view pitch (radians, > 0 up).
    pub fn pitch(&self) -> f32 {
        self.look_pitch
    }

    /// The pitch range allowed for the current view window.
    pub fn max_pitch(&self) -> f32 {
        let r = &self.renderer;
        let vw = r.scaledviewwidth >> self.settings.low_detail as i32;
        Camera::pitch_limit(r.viewheight as f32, vw as f32 / 2.0).min(MAX_PITCH)
    }

    /// Add to the view pitch (mouse/keyboard look). Ignored by the classic
    /// renderer, during demos and while the player is dead.
    pub fn look(&mut self, delta: f32) {
        if self.render_mode != RenderMode::Perspective || self.demo.is_some() {
            return;
        }
        let max = self.max_pitch();
        self.look_pitch = (self.look_pitch + delta).clamp(-max, max);
    }

    /// Level the view (`centerview`).
    pub fn center_view(&mut self) {
        self.look_pitch = 0.0;
    }

    pub fn set_render_mode(&mut self, mode: RenderMode) {
        self.render_mode = mode;
        if mode == RenderMode::Classic {
            self.look_pitch = 0.0;
        }
    }

    // ---- level / game flow --------------------------------------------------

    fn load_level(&self, m: MapRef) -> Result<Level, String> {
        Level::load(&self.stack, &self.textures, &m.lump_name(self.game.mode)).map_err(|e| e.to_string())
    }

    /// The per-level part of `G_DoLoadLevel`, `S_Start`, `ST_Start`,
    /// `AM_LevelInit`.
    fn start_level(&mut self) {
        self.state = GameState::Level;
        self.intermission = None;
        self.finale = None;
        self.automap.stop();
        self.automap.level_init(&self.world);
        self.renderer.mapped_lines.clear();
        self.perspective.level_changed();
        self.look_pitch = 0.0;
        self.status_bar.start(&self.world);
        self.hud_text.clear();
        self.sound.stop_all();
        let music = SoundSystem::level_music(self.game.mode, self.current.episode, self.current.map);
        self.sound.change_music(&self.stack, music, true);
    }

    fn reload_level(&mut self) -> Result<(), String> {
        let level = self.load_level(self.current)?;
        self.world.setup_level(level)?;
        self.start_level();
        Ok(())
    }

    /// Start a fresh game on `m` (new inventory), like `G_InitNew`.
    pub fn new_game(&mut self, m: MapRef) -> Result<(), String> {
        self.new_game_with(m, self.base_params.skill)
    }

    fn new_game_with(&mut self, m: MapRef, skill: Skill) -> Result<(), String> {
        if !m.exists(&self.stack, self.game.mode) {
            return Err(format!("map {} not found", m.lump_name(self.game.mode)));
        }
        let level = self.load_level(m)?;
        let mut params = self.base_params;
        params.episode = m.episode;
        params.map = m.map;
        params.skill = skill;
        self.base_params.skill = skill;
        let content = ContentInfo::from_content(&self.stack, &self.textures);
        self.world = World::new_game(Info::doom(), content, params, single_player(), level)?;
        self.current = m;
        self.demo = None;
        self.usergame = true;
        self.paused = false;
        self.start_level();
        Ok(())
    }

    /// `G_DoCompleted`: leave the level for the intermission (or straight to
    /// the finale after Doom 1's map 8).
    fn level_completed(&mut self, exit: GameExit) {
        self.automap.stop();
        self.secret_exit = exit == GameExit::Secret;
        let mode = self.game.mode;
        let MapRef { episode, map } = self.current;
        if mode != GameMode::Commercial {
            if map == 8 {
                self.start_finale();
                return;
            }
            if map == 9 {
                for p in &mut self.world.players {
                    p.didsecret = true;
                }
            }
        }
        let next = match next_map(mode, self.current, self.secret_exit) {
            Next::Map(m) => m.map - 1,
            Next::EpisodeEnd => map,
        };
        let p = self.world.console_player();
        let wbs = WbStart {
            epsd: episode - 1,
            last: map - 1,
            next,
            didsecret: p.didsecret,
            maxkills: self.world.totalkills,
            maxitems: self.world.totalitems,
            maxsecret: self.world.totalsecret,
            partime: WbStart::par_time(mode, episode, map),
            kills: p.killcount,
            items: p.itemcount,
            secret: p.secretcount,
            time: self.world.leveltime,
        };
        self.intermission =
            Some(Intermission::new(&self.stack, &mut self.patches, mode, self.game.version, wbs, &mut self.world.rng));
        self.state = GameState::Intermission;
    }

    /// `G_WorldDone` + `G_DoWorldDone`.
    fn world_done(&mut self) {
        if self.secret_exit {
            for p in &mut self.world.players {
                p.didsecret = true;
            }
        }
        if self.game.mode == GameMode::Commercial && self.state != GameState::Finale {
            let map = self.current.map;
            let finale = match map {
                15 | 31 => self.secret_exit,
                6 | 11 | 20 | 30 => true,
                _ => false,
            };
            if finale {
                self.start_finale();
                return;
            }
        }
        match next_map(self.game.mode, self.current, self.secret_exit) {
            Next::Map(m) if m.exists(&self.stack, self.game.mode) => {
                let result = self.load_level(m).and_then(|level| self.world.next_level(m.episode, m.map, level));
                match result {
                    Ok(()) => {
                        self.current = m;
                        self.start_level();
                    }
                    Err(e) => {
                        self.start_title();
                        self.show_message(e);
                    }
                }
            }
            // The game is over (or the next map is missing): title screen.
            _ => self.start_title(),
        }
    }

    fn start_finale(&mut self) {
        let mut out = Vec::new();
        self.finale = Some(Finale::new(&self.stack, &mut self.patches, &self.game, self.current.episode, self.current.map, &mut out));
        self.intermission = None;
        self.state = GameState::Finale;
        self.handle_finale_events(out);
    }

    fn handle_finale_events(&mut self, events: Vec<FinaleEvent>) {
        for ev in events {
            match ev {
                FinaleEvent::StartSound(s) => self.local_sound(s),
                FinaleEvent::ChangeMusic(m) => self.sound.change_music(&self.stack, m, true),
                FinaleEvent::WorldDone => self.world_done(),
            }
        }
    }

    fn local_sound(&mut self, sfx: SfxNum) {
        self.sound.start_local(&self.stack, &self.world.info, sfx, &mut self.world.rng);
    }

    // ---- title / demo loop (d_main.c) ----------------------------------------

    /// `D_StartTitle`.
    fn start_title(&mut self) {
        self.usergame = false;
        self.demo = None;
        self.paused = false;
        self.automap.stop();
        self.demosequence = -1;
        self.advance_demo();
    }

    /// `D_DoAdvanceDemo`.
    fn advance_demo(&mut self) {
        self.demo = None;
        self.paused = false;
        let commercial = self.game.mode == GameMode::Commercial;
        let ultimate = matches!(self.game.version, GameVersion::Ultimate | GameVersion::Final | GameVersion::Final2);
        self.demosequence = (self.demosequence + 1) % if ultimate { 7 } else { 6 };
        let page = |s: &mut Session, name: &str, tics: i32| {
            s.state = GameState::DemoScreen;
            s.pagetic = tics;
            s.page = s.patches.get(&s.stack, name);
        };
        match self.demosequence {
            0 => {
                page(self, "TITLEPIC", if commercial { 35 * 11 } else { 170 });
                let m = if commercial { doom_sim::info::MUS_DM2TTL } else { doom_sim::info::MUS_INTRO };
                self.sound.change_music(&self.stack, m, false);
            }
            2 => page(self, "CREDIT", 200),
            4 => {
                if commercial {
                    page(self, "TITLEPIC", 35 * 11);
                    self.sound.change_music(&self.stack, doom_sim::info::MUS_DM2TTL, false);
                } else {
                    page(self, if self.game.version >= GameVersion::Ultimate { "CREDIT" } else { "HELP2" }, 200);
                }
            }
            n => {
                let name = match n {
                    1 => "DEMO1",
                    3 => "DEMO2",
                    5 => "DEMO3",
                    _ => "DEMO4",
                };
                let demo = self.stack.lump(name).and_then(|d| Demo::parse(d).ok());
                if demo.and_then(|d| self.play_demo(d, true).ok()).is_none() {
                    // Missing or unplayable demo: skip it.
                    self.advance_demo();
                }
            }
        }
    }

    fn play_demo(&mut self, demo: Demo, attract: bool) -> Result<(), String> {
        let m = MapRef::new(demo.episode, demo.map);
        let level = self.load_level(m)?;
        let params = GameParams {
            mode: self.game.mode,
            version: self.game.version,
            skill: demo.skill,
            episode: demo.episode,
            map: demo.map,
            deathmatch: demo.deathmatch,
            netgame: demo.playeringame[1..].iter().any(|&p| p),
            respawnmonsters: demo.respawnparm,
            nomonsters: demo.nomonsters,
            fastparm: demo.fastparm,
            consoleplayer: demo.consoleplayer,
        };
        let content = ContentInfo::from_content(&self.stack, &self.textures);
        self.world = World::new_game(Info::doom(), content, params, demo.playeringame, level)?;
        self.current = m;
        self.demo = Some(DemoPlayback { demo, pos: 0, attract });
        self.usergame = false;
        self.start_level();
        Ok(())
    }

    // ---- input --------------------------------------------------------------

    /// A key was pressed (including auto-repeat for menu navigation).
    pub fn key_down(&mut self, key: Key) {
        if self.quit_countdown.is_some() {
            return;
        }
        // M_Responder gets first chance.
        let mut actions = Vec::new();
        let in_game = self.usergame && self.state == GameState::Level;
        let eaten = self.menu.responder(key, &mut self.settings, self.world.gametic, in_game, &mut actions);
        self.handle_menu_actions(actions);
        if eaten {
            return;
        }
        // Screen size keys outside the automap (also M_Responder).
        if !self.automap.active && matches!(key, Key::Minus | Key::Equals) && self.state == GameState::Level {
            let b = self.settings.screenblocks + if key == Key::Minus { -1 } else { 1 };
            self.settings.screenblocks = b.clamp(3, 11);
            self.apply_view();
            self.local_sound(doom_sim::info::SFX_STNMOV);
            return;
        }
        // G_Responder: during the title loop or demo playback any key opens
        // the menu.
        if !self.usergame && (self.demo.is_some() || self.state == GameState::DemoScreen) {
            self.menu.open();
            self.local_sound(doom_sim::info::SFX_SWTCHN);
            return;
        }
        match self.state {
            GameState::Finale => {
                let mut out = Vec::new();
                if let Some(f) = &mut self.finale {
                    f.responder(&self.world.info, &mut out);
                }
                self.handle_finale_events(out);
            }
            GameState::Level => {
                if key == Key::Pause {
                    self.paused = !self.paused;
                    self.sound.pause_music(self.paused);
                    return;
                }
                if key == Key::Tab {
                    if self.automap.active {
                        self.automap.stop();
                    } else {
                        self.automap.start(&self.world);
                    }
                    return;
                }
                if let Some(msg) = self.automap.responder(key, true, &self.world) {
                    self.show_message(msg);
                }
                if let Key::Char(c) = key {
                    if let Some(cheat) = self.cheats.feed(c) {
                        self.cheat(cheat);
                    }
                }
            }
            _ => {}
        }
    }

    pub fn key_up(&mut self, key: Key) {
        let _ = self.automap.responder(key, false, &self.world);
    }

    fn cheat(&mut self, cheat: Cheat) {
        // ST_Responder: no cheats on Nightmare (except map reveal/warp).
        let nightmare = self.world.params.skill == Skill::Nightmare;
        match cheat {
            Cheat::MapReveal => {
                if self.automap.active {
                    self.automap.cheating = (self.automap.cheating + 1) % 3;
                }
            }
            Cheat::Warp(_) => self.apply_cheat(&cheat),
            _ if nightmare => {}
            _ => self.apply_cheat(&cheat),
        }
    }

    fn handle_menu_actions(&mut self, actions: Vec<MenuAction>) {
        for a in actions {
            match a {
                MenuAction::StartSound(s) => self.local_sound(s),
                MenuAction::NewGame { episode, skill } => {
                    let m = if self.game.mode == GameMode::Commercial { MapRef::new(1, 1) } else { MapRef::new(episode, 1) };
                    if let Err(e) = self.new_game_with(m, skill) {
                        self.show_message(e);
                    }
                }
                MenuAction::EndGame => self.start_title(),
                MenuAction::Quit => self.quit_countdown = Some(53),
                MenuAction::ViewChanged => self.apply_view(),
                MenuAction::VolumeChanged => self.sound.set_volumes(self.settings.sfx_volume, self.settings.music_volume),
                MenuAction::Message(m) => self.show_message(m),
            }
        }
    }

    // ---- ticking --------------------------------------------------------------

    /// Run one 35 Hz tic with this input (ignored during demo playback).
    pub fn tick(&mut self, input: &InputState) {
        self.menu.ticker();
        if let Some(n) = &mut self.quit_countdown {
            *n -= 1;
            if *n <= 0 {
                self.quit = true;
            }
            self.sound.update(None, false);
            return;
        }
        // P_Ticker does nothing while the menu is up in a user game.
        let menu_pause = self.menu.is_open() && self.demo.is_none() && self.usergame;
        let mut cmds = [TicCmd::default(); MAXPLAYERS];
        let neutral = InputState::default();
        let input = if self.menu.is_open() { &neutral } else { input };
        // G_Ticker reads demo commands in every game state.
        match &mut self.demo {
            Some(d) => match d.demo.tics.get(d.pos) {
                Some(c) => {
                    cmds = *c;
                    d.pos += 1;
                }
                None => {
                    // G_CheckDemoStatus: demo over.
                    let attract = d.attract;
                    self.demo = None;
                    if attract {
                        self.advance_demo();
                    } else {
                        self.start_title();
                    }
                    return;
                }
            },
            None => cmds[self.world.params.consoleplayer] = self.builder.build(input),
        }

        match self.state {
            GameState::Level => {
                if !(self.paused || menu_pause) {
                    self.level_tic(&cmds);
                }
                if self.state == GameState::Level {
                    self.status_bar.ticker(&mut self.world);
                    self.automap.ticker(&self.world);
                    self.hud_text.ticker();
                }
            }
            GameState::Intermission => {
                let b = cmds[self.world.params.consoleplayer].buttons;
                let mut out = Vec::new();
                if let Some(wi) = &mut self.intermission {
                    wi.ticker(b & bt::ATTACK != 0, b & bt::USE != 0, &mut self.world.rng, &mut out);
                }
                for ev in out {
                    match ev {
                        WiEvent::StartSound(s) => self.local_sound(s),
                        WiEvent::ChangeMusic(m) => self.sound.change_music(&self.stack, m, true),
                        WiEvent::Done => self.world_done(),
                    }
                }
            }
            GameState::Finale => {
                let any_button = cmds[self.world.params.consoleplayer].buttons != 0;
                let mut out = Vec::new();
                if let Some(f) = &mut self.finale {
                    f.ticker(&self.world.info, any_button, &mut out);
                }
                self.handle_finale_events(out);
            }
            GameState::DemoScreen => {
                self.pagetic -= 1;
                if self.pagetic < 0 {
                    self.advance_demo();
                }
            }
        }
        let boss_map = self.current.map == 8;
        let w = (self.state == GameState::Level).then_some(&self.world);
        self.sound.update(w, boss_map);
    }

    fn level_tic(&mut self, cmds: &[TicCmd; MAXPLAYERS]) {
        match self.world.tick(cmds) {
            None => {}
            Some(GameAction::LoadLevel) => {
                // Single-player death: `G_DoReborn` reloads the level; the
                // tic then runs on the fresh level as in G_Ticker.
                if let Err(e) = self.reload_level() {
                    self.show_message(e);
                    return;
                }
                self.world.tick(cmds);
            }
            Some(GameAction::Completed(exit)) => {
                self.level_completed(exit);
                return;
            }
        }
        // HU_Ticker: pick up the player's message.
        let cp = self.world.params.consoleplayer;
        if let Some(m) = self.world.players[cp].message.take() {
            if self.settings.show_messages {
                self.hud_text.show(m);
            }
        }
        let events = std::mem::take(&mut self.world.events);
        let boss_map = self.current.map == 8;
        self.sound.handle_events(&self.stack, &mut self.world, &events, boss_map);
        self.events.extend(events);
    }

    // ---- developer cheats (st_stuff.c equivalents) ------------------------

    fn player_mut(&mut self) -> &mut doom_sim::player::Player {
        let cp = self.world.params.consoleplayer;
        &mut self.world.players[cp]
    }

    /// `iddqd`.
    pub fn toggle_god(&mut self) {
        let p = self.player_mut();
        p.cheats ^= cheat::GODMODE;
        let on = p.cheats & cheat::GODMODE != 0;
        if on {
            p.health = 100;
            if let Some(mo) = p.mo {
                self.world.mo_mut(mo).health = 100;
            }
        }
        self.show_message(if on { "Degreelessness Mode On" } else { "Degreelessness Mode Off" });
    }

    /// `idclip`.
    pub fn toggle_noclip(&mut self) {
        let p = self.player_mut();
        p.cheats ^= cheat::NOCLIP;
        let on = p.cheats & cheat::NOCLIP != 0;
        self.show_message(if on { "No Clipping Mode ON" } else { "No Clipping Mode OFF" });
    }

    /// `idkfa`.
    pub fn give_all(&mut self) {
        let p = self.player_mut();
        p.armorpoints = 200;
        p.armortype = 2;
        p.weaponowned = [true; NUMWEAPONS];
        p.ammo = p.maxammo;
        p.cards = [true; 6];
        self.show_message("Very Happy Ammo Added");
    }

    /// `idclev`: new game on another map.
    pub fn warp(&mut self, map: &str) -> Result<(), String> {
        let m = MapRef::parse(map, self.game.mode).ok_or_else(|| format!("bad map name {map}"))?;
        self.new_game(m)
    }

    /// Exit the level as if the exit switch was used (developer shortcut).
    pub fn exit_level(&mut self) {
        if self.state == GameState::Level {
            self.level_completed(GameExit::Normal);
        }
    }

    // ---- presentation -------------------------------------------------------

    /// `ST_doPaletteStuff`: PLAYPAL index for damage/pickup/radiation tints.
    pub fn palette_index(&self) -> usize {
        if self.state != GameState::Level {
            return 0;
        }
        let p = self.world.console_player();
        let mut cnt = p.damagecount;
        if p.powers[power::STRENGTH] != 0 {
            // Slowly fade the berserk out.
            let bzc = 12 - (p.powers[power::STRENGTH] >> 6);
            cnt = cnt.max(bzc);
        }
        if cnt > 0 {
            1 + (((cnt + 7) >> 3) as usize).min(7)
        } else if p.bonuscount > 0 {
            9 + (((p.bonuscount + 7) >> 3) as usize).min(3)
        } else if p.powers[power::IRONFEET] > 4 * 32 || p.powers[power::IRONFEET] & 8 != 0 {
            13
        } else {
            0
        }
    }

    /// `D_Display`: compose the whole 320x200 frame (palette indices).
    pub fn render_indexed(&mut self) -> &[u8] {
        let screen = &mut self.screen;
        match self.state {
            GameState::Level => {
                let blocks = self.settings.screenblocks;
                if self.automap.active {
                    self.automap.draw(screen, &self.world, &self.renderer.mapped_lines);
                } else if self.world.console_player().mo.is_some() {
                    let player = self.world.params.consoleplayer;
                    match self.render_mode {
                        RenderMode::Classic => self.renderer.render_player_view(&self.render_data, &self.world, player, screen),
                        RenderMode::Perspective => {
                            let r = &self.renderer;
                            let rect = ViewRect {
                                x: r.viewwindowx,
                                y: r.viewwindowy,
                                width: r.scaledviewwidth,
                                height: r.viewheight,
                                low_detail: self.settings.low_detail,
                            };
                            // A dead player's view stays level as the eye sinks.
                            let pitch = if self.world.players[player].playerstate == PlayerState::Dead { 0.0 } else { self.look_pitch };
                            if let Some(cam) = Camera::from_player(&self.world, player, pitch) {
                                self.perspective.render(&self.render_data, &self.world, player, &cam, rect, screen);
                            }
                            // The weapon is screen space, drawn as in vanilla.
                            self.renderer.render_psprites(&self.render_data, &self.world, player, screen);
                            // One automap memory whichever renderer drew.
                            let seen = &self.perspective.mapped_lines;
                            let mapped = &mut self.renderer.mapped_lines;
                            if mapped.len() < seen.len() {
                                mapped.resize(seen.len(), false);
                            }
                            for (m, &s) in mapped.iter_mut().zip(seen) {
                                *m |= s;
                            }
                        }
                    }
                    let r = &self.renderer;
                    self.border.draw(screen, r.viewwindowx, r.viewwindowy, r.scaledviewwidth, r.viewheight, ST_Y);
                }
                if self.automap.active || blocks <= 10 {
                    self.status_bar.draw(screen, &self.world);
                } else {
                    self.status_bar.draw_fullscreen(screen, &self.world);
                }
                if self.automap.active {
                    let title = map_title(&self.game, self.current.episode, self.current.map);
                    self.font.draw(screen, 0, ST_Y - 1 - self.font.height(), &title);
                }
                self.hud_text.draw(screen, &self.font);
                if self.paused {
                    let top = if self.automap.active { 4 } else { self.renderer.viewwindowy };
                    self.menu.draw_pause(screen, top);
                }
            }
            GameState::Intermission => {
                if let Some(wi) = &self.intermission {
                    wi.draw(screen);
                }
            }
            GameState::Finale => {
                let mut out = Vec::new();
                if let Some(f) = &mut self.finale {
                    f.draw(screen, &self.font, &self.render_data, &self.world.info, &mut out);
                }
                self.handle_finale_events(out);
            }
            GameState::DemoScreen => {
                if let Some(p) = &self.page {
                    draw_patch(&mut self.screen, 0, 0, p);
                }
            }
        }
        self.menu.draw(&mut self.screen, &self.font, &self.settings);
        &self.screen
    }

    /// Render and convert to RGBA8 (`out.len() == 320 * 200 * 4`), applying
    /// the current palette effect.
    pub fn render_rgba(&mut self, out: &mut [u8]) {
        assert_eq!(out.len(), SCREENWIDTH * SCREENHEIGHT * 4);
        let pal = *self.render_data.palettes.get(self.palette_index());
        let screen = self.render_indexed();
        for (px, &i) in out.chunks_exact_mut(4).zip(screen) {
            let [r, g, b] = pal[i as usize];
            px.copy_from_slice(&[r, g, b, 255]);
        }
    }

    pub fn hud(&self) -> Hud {
        let w = &self.world;
        let p = w.console_player();
        let ammo_type = w.weaponinfo.get(p.readyweapon as usize).map_or(usize::MAX, |wi| wi.ammo);
        Hud {
            map: self.map_name(),
            health: p.health,
            armor: p.armorpoints,
            weapon: p.readyweapon,
            ammo: (ammo_type < 4).then(|| (p.ammo[ammo_type], p.maxammo[ammo_type])),
            weapons_owned: p.weaponowned,
            keys: p.cards,
            kills: (p.killcount, w.totalkills),
            items: (p.itemcount, w.totalitems),
            secrets: (p.secretcount, w.totalsecret),
            dead: p.playerstate == PlayerState::Dead,
            god: p.cheats & cheat::GODMODE != 0,
            noclip: p.cheats & cheat::NOCLIP != 0,
            message: self.hud_text.message().map(str::to_string),
            level_seconds: (w.leveltime.max(0) as u32) / TICRATE,
        }
    }
}

fn single_player() -> [bool; MAXPLAYERS] {
    let mut pig = [false; MAXPLAYERS];
    pig[0] = true;
    pig
}

/// The first map present: E1M1 / MAP01, else the first map lump found.
fn first_map(stack: &ResourceStack, mode: GameMode) -> Option<MapRef> {
    let preferred = MapRef::new(1, 1);
    if preferred.exists(stack, mode) {
        return Some(preferred);
    }
    doom_content::map::list_maps(stack).iter().find_map(|n| MapRef::parse(&n.to_string(), mode))
}

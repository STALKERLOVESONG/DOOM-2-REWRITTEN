//! Playsim smoke tests on real content (skipped without an IWAD).

use std::path::PathBuf;

use doom_content::game::identify;
use doom_content::texture::TextureSet;
use doom_content::ResourceStack;
use doom_sim::demo::Demo;
use doom_sim::info::Info;
use doom_sim::level::Level;
use doom_sim::player::MAXPLAYERS;
use doom_sim::ticcmd::TicCmd;
use doom_sim::{GameParams, Skill, World};

fn stack() -> Option<ResourceStack> {
    let path = std::env::var_os("DOOM_IWAD")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../WADS/doom1.wad"));
    path.exists().then(|| ResourceStack::load(&path, &[]).unwrap())
}

fn start(stack: &ResourceStack, map: &str, skill: Skill) -> World {
    let tex = TextureSet::load(stack).unwrap();
    let gi = identify(stack, None).unwrap();
    let level = Level::load(stack, &tex, map).unwrap();
    let params = GameParams {
        mode: gi.mode,
        version: gi.version,
        skill,
        episode: 1,
        map: 1,
        deathmatch: 0,
        netgame: false,
        respawnmonsters: false,
        nomonsters: false,
        fastparm: false,
        consoleplayer: 0,
    };
    World::new_game(Info::doom(), doom_sim::content::ContentInfo::from_content(stack, &tex), params, [true, false, false, false], level).unwrap()
}

#[test]
fn walk_forward_in_e1m1() {
    let Some(stack) = stack() else { return };
    let mut w = start(&stack, "E1M1", Skill::Medium);
    let mo = w.players[0].mo.unwrap();
    let (x0, y0) = (w.mo(mo).x, w.mo(mo).y);
    let mut cmds = [TicCmd::default(); MAXPLAYERS];
    cmds[0].forwardmove = 50;
    for _ in 0..35 {
        w.tick(&cmds);
    }
    let m = w.mo(mo);
    assert!(m.x != x0 || m.y != y0, "player should have moved");
    // Player 1 start in E1M1 faces north (angle 90): moved along +y.
    assert!(m.y > y0);
    assert_eq!(w.leveltime, 35);
    eprintln!("unimplemented: {:?}", w.unimplemented);
}

#[test]
fn demos_parse() {
    let Some(stack) = stack() else { return };
    for i in 1..=4 {
        let Some(d) = stack.lump(&format!("DEMO{i}")) else { continue };
        let demo = Demo::parse(d).unwrap();
        eprintln!("DEMO{i}: v{:?} E{}M{} skill {:?} {} tics", demo.version, demo.episode, demo.map, demo.skill, demo.tics.len());
        assert!(demo.tics.len() > 100);
    }
}

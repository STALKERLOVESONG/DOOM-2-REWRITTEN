/* Minimal stand-in so Chocolate Doom's portable code builds without SDL. */
#ifndef REFDOOM_SDL_STDINC_H
#define REFDOOM_SDL_STDINC_H
#include <stdlib.h>
#define SDL_qsort qsort
#endif

# doom_bevy

A Rust-native Doom engine with a Bevy front end. It aims to be broadly faithful to classic Doom while staying easy to read, modify and extend into a Doom-style engine and modding platform.

## Run

```
cargo run --release -- --iwad WADS/doom1.wad
cargo run --release -- --iwad WADS/doom1.wad --map E2M1 --skill 4
cargo run --release -- --iwad WADS/doom1.wad --pwad mymap.wad --map E1M1
cargo run --release -- --iwad WADS/doom1.wad --playdemo DEMO1
```

Other options: `--nomonsters`, `--fast`, `--respawn`, `--scale N` (window = N × 320×240), `--sensitivity F`, `--mouse-move`, `--screen-size 3..11`, `--low-detail`. Run with `--help` for the full list.

**Controls**

| Action | Keys |
|---|---|
| Move / strafe | WASD |
| Turn | Arrow keys, or the mouse (click the window to capture it, Esc to release) |
| Run | Shift |
| Strafe modifier | Alt + turn keys |
| Fire | Ctrl or left mouse |
| Use | Space, E, or right mouse |
| Weapons | 1–7 |
| View size | − and = |
| Detail | F5 |
| Pause | Pause or F12 |
| Next map | F6 |
| Quit | F10 |

Vanilla cheat codes work: `iddqd`, `idkfa`, `idfa`, `idclip`, `idclevXY`.

## Layout

| Crate | Role |
|---|---|
| `crates/doom_core` | Fixed point, angles, trig tables, RNG. No dependencies. |
| `crates/doom_content` | WAD loading, resource lookup with PWAD overrides, graphics/texture/map lump parsing. |
| `crates/doom_sim` | The deterministic playsim: thinkers, mobjs, movement, AI, weapons, sector specials. It is driven one tic at a time and knows nothing about rendering or the host. |
| `crates/doom_render` | Software renderer producing a 320×200 palette-indexed frame. |
| `crates/doom_game` | Host-independent session layer: loading, level flow, input → ticcmd, palette effects, HUD data, cheats. Tools and tests use it headless. |
| `src/main.rs` | Bevy host: window, input, framebuffer upload, text HUD. No game logic. |

The simulation is plain Rust rather than Bevy ECS on purpose. Doom's behaviour depends on the order thinkers run and objects are linked, and Bevy queries don't guarantee order. Bevy owns presentation; the engine crates own the game.

## Tests

```
cargo test --release -p doom_core -p doom_content -p doom_sim -p doom_render -p doom_game
```

The tests use `WADS/doom1.wad` and skip when it is absent. Simulation and renderer tests replay demos and compare against traces and frames recorded from Chocolate Doom (`tools/refdoom`). Chocolate Doom is a regression oracle for catching real bugs, not a specification: deviations are fine when they are deliberate and documented.

See `docs/STATUS.md` for what works and what's next.

License: GPL-2.0-or-later, because the gameplay code is derived from the GPL Doom source.

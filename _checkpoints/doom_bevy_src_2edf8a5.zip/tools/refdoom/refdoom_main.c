/*
 * refdoom main + per-tic state dump.
 *
 * g_game.c is compiled with -DG_Ticker=G_Ticker_real; this file provides
 * G_Ticker, which runs the real one and then writes one line per level tic:
 *
 *   tic <gametic> <leveltime> <prndindex> <player mobj x y z angle momx momy momz>
 *       <viewz> <nmobjs> <hash>
 *
 * The hash covers every mobj in thinker order (type, x, y, z, angle, state,
 * tics, flags, health). doom_sim's differential test computes the same.
 */
#include <stdio.h>
#include <stdlib.h>
#include "doomdef.h"
#include "doomstat.h"
#include "d_main.h"
#include "m_argv.h"
#include "p_local.h"

extern int prndindex;
extern thinker_t thinkercap;
void G_Ticker_real(void);

static FILE *out;

static unsigned int mix(unsigned int h, int v)
{
    h ^= (unsigned int)v;
    h *= 16777619u;
    return h;
}

void G_Ticker(void)
{
    thinker_t *th;
    unsigned int hash = 2166136261u;
    int n = 0;
    mobj_t *pmo;

    G_Ticker_real();
    if (gamestate != GS_LEVEL || !out)
        return;

    for (th = thinkercap.next; th != &thinkercap; th = th->next) {
        mobj_t *mo;
        if (th->function.acp1 != (actionf_p1)P_MobjThinker)
            continue;
        mo = (mobj_t *)th;
        hash = mix(hash, mo->type);
        hash = mix(hash, mo->x);
        hash = mix(hash, mo->y);
        hash = mix(hash, mo->z);
        hash = mix(hash, (int)mo->angle);
        hash = mix(hash, (int)(mo->state - states));
        hash = mix(hash, mo->tics);
        hash = mix(hash, mo->flags);
        hash = mix(hash, mo->health);
        n++;
    }
    {
        /* Debug aid: REFDOOM_DUMP_TIC=<gametic> lists every mobj at that tic. */
        static int dump_tic = -2;
        if (dump_tic == -2) {
            const char *d = getenv("REFDOOM_DUMP_TIC");
            dump_tic = d ? atoi(d) : -1;
        }
        if (gametic == dump_tic || (dump_tic >= 0 && gametic == dump_tic - 1)) {
            int i = 0;
            for (th = thinkercap.next; th != &thinkercap; th = th->next) {
                mobj_t *mo;
                if (th->function.acp1 != (actionf_p1)P_MobjThinker)
                    continue;
                mo = (mobj_t *)th;
                fprintf(stderr, "T%d mobj %d type %d xyz %d %d %d ang %u state %d tics %d flags %x health %d mom %d %d %d\n",
                        gametic, i++, mo->type, mo->x, mo->y, mo->z, (unsigned)mo->angle, (int)(mo->state - states),
                        mo->tics, mo->flags, mo->health, mo->momx, mo->momy, mo->momz);
            }
        }
    }
    pmo = players[consoleplayer].mo;
    {
        /* REFDOOM_COMPACT=1: only every 35th tic carries the full line;
         * others carry gametic, prndindex and the mobj hash. */
        static int compact = -1;
        if (compact < 0)
            compact = getenv("REFDOOM_COMPACT") != NULL;
        if (compact && gametic % 35 != 0) {
            fprintf(out, "c %d %d %08x\n", gametic, prndindex, hash);
            return;
        }
    }
    fprintf(out, "tic %d %d %d %d %d %d %u %d %d %d %d %d %08x\n",
            gametic, leveltime, prndindex,
            pmo ? pmo->x : 0, pmo ? pmo->y : 0, pmo ? pmo->z : 0,
            pmo ? (unsigned)pmo->angle : 0u,
            pmo ? pmo->momx : 0, pmo ? pmo->momy : 0, pmo ? pmo->momz : 0,
            players[consoleplayer].viewz, n, hash);
}

int main(int argc, char **argv)
{
    const char *path = getenv("REFDOOM_OUT");
    out = path ? fopen(path, "w") : stdout;
    myargc = argc;
    myargv = argv;
    M_FindResponseFile();
    M_SetExeDir();
    D_DoomMain();
    return 0;
}

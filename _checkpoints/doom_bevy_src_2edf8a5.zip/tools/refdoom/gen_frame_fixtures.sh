#!/bin/sh
# Record renderer reference frames with refdoom and turn them into hash
# fixtures for crates/doom_render/tests/frames.rs. Frames are captured,
# verified against our renderer and deleted one demo at a time (raw dumps
# are 64 KB per frame).
#
# Usage: tools/refdoom/gen_frame_fixtures.sh <refdoom binary> <iwad> <config> <every> <demo ids...>
#   config: default | full_low | full_high | small_low  (see CONFIGS in frames.rs)
#   every:  capture every Nth gametic
#   demo id: DEMO1..DEMO4 (IWAD lumps) or <set>/<stem> (doom_sim synthetic demos, e.g. a/DE1M1)
# Env: CARGO (default "cargo") runs the test, e.g. a wrapper script.
# A demo whose frames do not match is reported and left out of the fixture.
set -e
BIN=$(cd "$(dirname "$1")" && pwd)/$(basename "$1")
IWAD=$(cd "$(dirname "$2")" && pwd)/$(basename "$2")
CONFIG=$3
EVERY=$4
shift 4
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT="$HERE/../.."
SYN="$ROOT/crates/doom_sim/tests/fixtures/synthetic"
CARGO=${CARGO:-cargo}
case "$CONFIG" in
    default)   BLOCKS=9;  DETAIL=0; MSGS=1 ;;
    full_low)  BLOCKS=11; DETAIL=1; MSGS=0 ;;
    full_high) BLOCKS=11; DETAIL=0; MSGS=0 ;;
    small_low) BLOCKS=5;  DETAIL=1; MSGS=0 ;;
    *) echo "unknown config $CONFIG"; exit 1 ;;
esac
TMP=$(mktemp -d)
# Messages are disabled for full-screen views: HU text would cover the view.
printf 'screenblocks %s\ndetaillevel %s\nshow_messages %s\n' $BLOCKS $DETAIL $MSGS > "$TMP/default.cfg"
FAILED=""
for id in "$@"; do
    case "$id" in
        DEMO*) DEMOARG=$(echo "$id" | tr 'A-Z' 'a-z') ;;
        *) DEMOARG="$SYN/$id.lmp" ;;
    esac
    rm -rf "$TMP/shots"; mkdir -p "$TMP/shots"
    ( cd "$TMP" && HOME="$TMP" REFDOOM_OUT=/dev/null REFDOOM_SHOT_DIR="$TMP/shots" REFDOOM_SHOT_FROM=60 \
        REFDOOM_SHOT_EVERY=$EVERY "$BIN" -iwad "$IWAD" -config "$TMP/default.cfg" -timedemo "$DEMOARG" \
        -nosound -nomusic >/dev/null 2>&1 ) || true
    if ( cd "$ROOT" && REFDOOM_SHOTS="$TMP/shots" FRAME_CONFIG=$CONFIG FRAME_DEMO=$id WRITE_FRAME_FIXTURES=1 FRAME_FIXTURE_DIR="$(cd "$ROOT" && pwd)/crates/doom_render/tests/fixtures/frames" \
        $CARGO test -p doom_render --release --test frames -- --nocapture 2>&1 | grep -E "frames match|mismatch" ); then :; else
        FAILED="$FAILED $id"
    fi
done
rm -rf "$TMP"
[ -z "$FAILED" ] || { echo "not recorded:$FAILED"; exit 1; }

//! UDMF maps (`TEXTMAP` ... `ENDMAP`) into [`RawMap`] records.
//!
//! Namespaces `doom`, `zdoom`, `hexen`, `heretic`, `strife` and
//! `zdoomtranslated` are read. The playsim implements Doom-format line and
//! sector specials, so Hexen-style specials (`zdoom`/`hexen` namespaces) are
//! translated to their Doom equivalents where one exists (doors, lifts,
//! floors, ceilings, exits); others are dropped with a warning. Geometry,
//! textures, things, per-part texture offsets, per-side and per-plane light
//! and flat panning/scaling/rotation are kept.

use std::collections::BTreeMap;

use crate::map::{
    MapFormat, MapLinedef, MapSector, MapSidedef, MapThing, MapVertex, PlaneXform, RawMap, ml, mtf, NO_SIDEDEF,
};
use crate::name::LumpName;
use crate::resources::{LumpId, ResourceStack};
use crate::script::{Scanner, Token};
use crate::ContentError;

#[derive(Clone, Debug)]
enum Value {
    Int(i64),
    Float(f64),
    Bool(bool),
    Str(String),
}

impl Value {
    fn f(&self) -> f64 {
        match *self {
            Value::Int(i) => i as f64,
            Value::Float(f) => f,
            Value::Bool(b) => b as i32 as f64,
            Value::Str(_) => 0.0,
        }
    }
    fn i(&self) -> i64 {
        match *self {
            Value::Int(i) => i,
            Value::Float(f) => f as i64,
            Value::Bool(b) => b as i64,
            Value::Str(_) => 0,
        }
    }
    fn b(&self) -> bool {
        match *self {
            Value::Bool(b) => b,
            Value::Int(i) => i != 0,
            _ => false,
        }
    }
}

/// One UDMF block: lower-case key -> value.
struct Block {
    kind: String,
    fields: BTreeMap<String, Value>,
}

impl Block {
    fn f(&self, k: &str, default: f64) -> f64 {
        self.fields.get(k).map_or(default, Value::f)
    }
    fn i(&self, k: &str, default: i64) -> i64 {
        self.fields.get(k).map_or(default, Value::i)
    }
    fn b(&self, k: &str) -> bool {
        self.fields.get(k).is_some_and(Value::b)
    }
    fn s(&self, k: &str) -> Option<&str> {
        match self.fields.get(k) {
            Some(Value::Str(s)) => Some(s),
            _ => None,
        }
    }
}

fn parse(text: &str) -> Result<(String, Vec<Block>), String> {
    let mut sc = Scanner::new(text);
    let mut namespace = String::new();
    let mut blocks = Vec::new();
    let value = |sc: &mut Scanner| -> Result<Value, String> {
        let neg = sc.eat('-');
        if !neg {
            sc.eat('+');
        }
        let v = match sc.next() {
            Some(Token::Int(i)) => Value::Int(if neg { -i } else { i }),
            Some(Token::Float(f)) => Value::Float(if neg { -f } else { f }),
            Some(Token::Str(s)) => Value::Str(s),
            Some(Token::Ident(w)) if w.eq_ignore_ascii_case("true") => Value::Bool(true),
            Some(Token::Ident(w)) if w.eq_ignore_ascii_case("false") => Value::Bool(false),
            Some(Token::Ident(w)) => Value::Str(w),
            other => return Err(format!("line {}: bad value {other:?}", sc.line())),
        };
        if !sc.eat(';') {
            return Err(format!("line {}: expected ';'", sc.line()));
        }
        Ok(v)
    };
    while let Some(t) = sc.next() {
        let Token::Ident(name) = t else { return Err(format!("line {}: expected an identifier", sc.line())) };
        if sc.eat('=') {
            let v = value(&mut sc)?;
            if name.eq_ignore_ascii_case("namespace") {
                if let Value::Str(s) = v {
                    namespace = s.to_ascii_lowercase();
                }
            }
            continue;
        }
        if !sc.eat('{') {
            return Err(format!("line {}: expected '{{' after {name}", sc.line()));
        }
        let mut fields = BTreeMap::new();
        loop {
            if sc.eat('}') {
                break;
            }
            let Some(Token::Ident(key)) = sc.next() else { return Err(format!("line {}: expected a key", sc.line())) };
            if !sc.eat('=') {
                return Err(format!("line {}: expected '=' after {key}", sc.line()));
            }
            fields.insert(key.to_ascii_lowercase(), value(&mut sc)?);
        }
        blocks.push(Block { kind: name.to_ascii_lowercase(), fields });
    }
    Ok((namespace, blocks))
}

fn tex(s: Option<&str>, long: &mut Vec<String>) -> LumpName {
    let s = s.unwrap_or("-");
    if s.len() > 8 && !long.iter().any(|l| l == s) {
        long.push(s.to_string());
    }
    LumpName::new(s)
}

/// Load the UDMF map whose marker is `marker`.
pub fn load(stack: &ResourceStack, marker: LumpId, name: LumpName) -> Result<RawMap, ContentError> {
    // Lumps between the marker and ENDMAP, by name.
    let mut textmap = None;
    let mut znodes = None;
    let mut id = marker;
    while let Some(next) = stack.next_in_source(id) {
        id = next;
        match stack.info(id).name.as_bytes() {
            b"TEXTMAP" => textmap = Some(id),
            b"ZNODES" => znodes = Some(id),
            b"ENDMAP" => break,
            _ => {}
        }
    }
    let textmap = textmap.ok_or_else(|| ContentError::MissingLump(format!("{name}/TEXTMAP")))?;
    let text = String::from_utf8_lossy(stack.data(textmap));
    let (namespace, blocks) = parse(&text).map_err(|e| ContentError::malformed(format!("{name}/TEXTMAP"), e))?;
    let mut warnings = Vec::new();
    let hexen_specials = matches!(namespace.as_str(), "zdoom" | "hexen" | "vavoom" | "eternity");
    if !matches!(namespace.as_str(), "doom" | "zdoom" | "hexen" | "heretic" | "strife" | "zdoomtranslated" | "vavoom" | "eternity") {
        warnings.push(format!("{name}: unknown UDMF namespace {namespace:?}"));
    }

    let mut map = RawMap {
        name,
        format: MapFormat::Udmf,
        things: Vec::new(),
        linedefs: Vec::new(),
        sidedefs: Vec::new(),
        vertexes: Vec::new(),
        segs: Vec::new(),
        subsectors: Vec::new(),
        nodes: Vec::new(),
        sectors: Vec::new(),
        reject: Vec::new(),
        blockmap: Vec::new(),
        warnings: Vec::new(),
    };
    let fx = |v: f64| (v * 65536.0).round() as i32;
    let mut long_names = Vec::new();
    let mut dropped: BTreeMap<i64, usize> = BTreeMap::new();
    for b in &blocks {
        match b.kind.as_str() {
            "vertex" => map.vertexes.push(MapVertex { x: fx(b.f("x", 0.0)), y: fx(b.f("y", 0.0)) }),
            "linedef" => {
                let mut flags = 0u16;
                for (k, bit) in [
                    ("blocking", ml::BLOCKING),
                    ("blockmonsters", ml::BLOCKMONSTERS),
                    ("twosided", ml::TWOSIDED),
                    ("dontpegtop", ml::DONTPEGTOP),
                    ("dontpegbottom", ml::DONTPEGBOTTOM),
                    ("secret", ml::SECRET),
                    ("blocksound", ml::SOUNDBLOCK),
                    ("dontdraw", ml::DONTDRAW),
                    ("mapped", ml::MAPPED),
                    // Closest vanilla behaviour for "blocks everything".
                    ("blockeverything", ml::BLOCKING),
                    ("blockplayers", ml::BLOCKING),
                ] {
                    if b.b(k) {
                        flags |= bit;
                    }
                }
                let side = |v: i64| if v < 0 { NO_SIDEDEF } else { v as u32 };
                let special = b.i("special", 0);
                let args = [b.i("arg0", 0), b.i("arg1", 0), b.i("arg2", 0), b.i("arg3", 0), b.i("arg4", 0)];
                let (special, tag) = if hexen_specials {
                    match translate_special(special, args, b) {
                        Some(t) => t,
                        None => {
                            if special != 0 {
                                *dropped.entry(special).or_default() += 1;
                            }
                            (0, 0)
                        }
                    }
                } else {
                    // Doom namespace: the line id is the tag.
                    (special as i16, b.i("id", 0).max(0) as i16)
                };
                map.linedefs.push(MapLinedef {
                    v1: b.i("v1", 0) as u32,
                    v2: b.i("v2", 0) as u32,
                    flags,
                    special,
                    tag,
                    sidenum: [side(b.i("sidefront", -1)), side(b.i("sideback", -1))],
                    alpha: b.f("alpha", 1.0) as f32,
                });
            }
            "sidedef" => map.sidedefs.push(MapSidedef {
                texture_offset: b.f("offsetx", 0.0) as f32,
                row_offset: b.f("offsety", 0.0) as f32,
                top: tex(b.s("texturetop"), &mut long_names),
                bottom: tex(b.s("texturebottom"), &mut long_names),
                mid: tex(b.s("texturemiddle"), &mut long_names),
                sector: b.i("sector", 0) as u32,
                part_offsets: [
                    [b.f("offsetx_top", 0.0) as f32, b.f("offsety_top", 0.0) as f32],
                    [b.f("offsetx_mid", 0.0) as f32, b.f("offsety_mid", 0.0) as f32],
                    [b.f("offsetx_bottom", 0.0) as f32, b.f("offsety_bottom", 0.0) as f32],
                ],
                light: b.i("light", 0) as i16,
                light_absolute: b.b("lightabsolute"),
            }),
            "sector" => {
                let xform = |p: &str| PlaneXform {
                    x_offset: b.f(&format!("xpanning{p}"), 0.0) as f32,
                    y_offset: b.f(&format!("ypanning{p}"), 0.0) as f32,
                    x_scale: b.f(&format!("xscale{p}"), 1.0) as f32,
                    y_scale: b.f(&format!("yscale{p}"), 1.0) as f32,
                    rotation: b.f(&format!("rotation{p}"), 0.0) as f32,
                };
                let raw_special = b.i("special", 0);
                let special = if hexen_specials { translate_sector_special(raw_special) } else { raw_special as i16 };
                map.sectors.push(MapSector {
                    floor_height: fx(b.f("heightfloor", 0.0)),
                    ceiling_height: fx(b.f("heightceiling", 0.0)),
                    floor_pic: tex(b.s("texturefloor"), &mut long_names),
                    ceiling_pic: tex(b.s("textureceiling"), &mut long_names),
                    light_level: b.i("lightlevel", 160) as i16,
                    special,
                    tag: b.i("id", 0) as i16,
                    floor_xform: xform("floor"),
                    ceiling_xform: xform("ceiling"),
                    floor_light: (b.i("lightfloor", 0) as i16, b.b("lightfloorabsolute")),
                    ceiling_light: (b.i("lightceiling", 0) as i16, b.b("lightceilingabsolute")),
                });
            }
            "thing" => {
                let mut options = 0i16;
                if b.b("skill1") || b.b("skill2") {
                    options |= mtf::EASY;
                }
                if b.b("skill3") {
                    options |= mtf::NORMAL;
                }
                if b.b("skill4") || b.b("skill5") {
                    options |= mtf::HARD;
                }
                if b.b("ambush") {
                    options |= mtf::AMBUSH;
                }
                if !b.b("single") {
                    options |= mtf::NOTSINGLE;
                }
                map.things.push(MapThing {
                    x: fx(b.f("x", 0.0)),
                    y: fx(b.f("y", 0.0)),
                    z: fx(b.f("height", 0.0)),
                    angle: b.i("angle", 0) as i16,
                    kind: b.i("type", 0) as i16,
                    options,
                });
            }
            _ => {}
        }
    }
    for l in long_names.iter().take(10) {
        warnings.push(format!("{name}: texture name {l:?} is longer than 8 characters (truncated)"));
    }
    if !dropped.is_empty() {
        let list: Vec<String> = dropped.iter().map(|(s, n)| format!("{s} x{n}")).collect();
        warnings.push(format!("{name}: line specials without a Doom equivalent (inert): {}", list.join(", ")));
    }
    map.warnings = warnings;

    let Some(znodes) = znodes else {
        return Err(ContentError::Unsupported {
            what: format!("map {name}"),
            reason: "UDMF map without ZNODES (node builder not implemented)".into(),
        });
    };
    crate::nodes::load_zdoom(&mut map, stack.data(znodes))?;
    Ok(map)
}

/// ZDoom/Hexen sector types to Doom ones: 65..=81 are Doom's 1..=17;
/// bit 1024 is "secret", bits 32/64 Boom-style damage.
fn translate_sector_special(s: i64) -> i16 {
    let base = s & 0xff;
    let mut doom = if (65..=81).contains(&base) { (base - 64) as i16 } else { 0 };
    if doom == 0 {
        if s & 1024 != 0 {
            doom = 9;
        } else {
            doom = match (s >> 5) & 3 {
                1 => 7,
                2 => 5,
                3 => 16,
                _ => 0,
            };
        }
    }
    doom
}

/// Hexen-style line special + activation flags -> (Doom special, tag).
fn translate_special(special: i64, args: [i64; 5], b: &Block) -> Option<(i16, i16)> {
    let tag = args[0] as i16;
    let repeat = b.b("repeatspecial");
    // Activation: W(alk), S(witch/use), G(un).
    #[derive(PartialEq)]
    enum Act {
        Walk,
        Use,
        Gun,
    }
    let act = if b.b("playeruse") || b.b("monsteruse") {
        Act::Use
    } else if b.b("impact") {
        Act::Gun
    } else if b.b("playercross") || b.b("monstercross") || b.b("anycross") {
        Act::Walk
    } else {
        return None;
    };
    // Pick from (W1, WR, S1, SR, G1, GR); 0 = no equivalent.
    let pick = |w1: i16, wr: i16, s1: i16, sr: i16, g1: i16, gr: i16| -> Option<i16> {
        let v = match (&act, repeat) {
            (Act::Walk, false) => w1,
            (Act::Walk, true) => wr,
            (Act::Use, false) => s1,
            (Act::Use, true) => sr,
            (Act::Gun, false) => g1,
            (Act::Gun, true) => gr,
        };
        (v != 0).then_some(v)
    };
    let fast = |speed: i64| speed >= 64;
    // ZDoom lock numbers: 1/4/129 red, 2/5/130 blue, 3/6/131 yellow.
    let lock = match b.i("locknumber", 0) {
        0 => None,
        1 | 4 | 129 => Some('r'),
        2 | 5 | 130 => Some('b'),
        3 | 6 | 131 => Some('y'),
        _ => None,
    };
    let s = match special {
        // Door_Raise(tag, speed, delay, lighttag) / Door_LockedRaise(tag, speed, delay, lock, lighttag)
        12 | 13 => {
            let lock = if special == 13 {
                match args[3] {
                    1 | 4 | 129 => Some('r'),
                    2 | 5 | 130 => Some('b'),
                    3 | 6 | 131 => Some('y'),
                    _ => None,
                }
            } else {
                lock
            };
            if tag == 0 && act == Act::Use {
                // Manual door on the line's back sector.
                return Some((
                    match lock {
                        Some('b') => 26,
                        Some('y') => 27,
                        Some('r') => 28,
                        _ if fast(args[1]) => 117,
                        _ => 1,
                    },
                    0,
                ));
            }
            match lock {
                Some('b') => pick(0, 0, 133, 99, 0, 0)?,
                Some('r') => pick(0, 0, 135, 134, 0, 0)?,
                Some('y') => pick(0, 0, 137, 136, 0, 0)?,
                _ if fast(args[1]) => pick(108, 105, 111, 114, 0, 0)?,
                _ => pick(4, 90, 29, 63, 0, 0)?,
            }
        }
        // Door_Open(tag, speed, lighttag)
        11 => {
            if tag == 0 && act == Act::Use {
                return Some((if fast(args[1]) { 118 } else { 31 }, 0));
            }
            if fast(args[1]) {
                pick(109, 106, 112, 115, 0, 0)?
            } else {
                pick(2, 86, 103, 61, 46, 0)?
            }
        }
        // Door_Close(tag, speed, lighttag)
        10 => {
            if fast(args[1]) {
                pick(110, 107, 113, 116, 0, 0)?
            } else {
                pick(3, 75, 50, 42, 0, 0)?
            }
        }
        // Door_CloseWaitOpen(tag, speed, delay, lighttag)
        14 => pick(16, 76, 0, 0, 0, 0)?,
        // Plat_DownWaitUpStay(tag, speed, delay) / Plat_DownWaitUpStayLip
        62 | 206 => {
            if fast(args[1]) {
                pick(121, 120, 122, 123, 0, 0)?
            } else {
                pick(10, 88, 21, 62, 0, 0)?
            }
        }
        // Plat_PerpetualRaise(tag, speed, delay)
        60 => pick(53, 87, 0, 0, 0, 0)?,
        // Plat_Stop(tag)
        61 => pick(54, 89, 0, 0, 0, 0)?,
        // Floor_LowerToLowest(tag, speed)
        21 => pick(38, 82, 23, 60, 0, 0)?,
        // Floor_LowerToHighest(tag, speed, adjust)
        24 => pick(19, 83, 102, 45, 0, 0)?,
        // Floor_RaiseToNearest(tag, speed)
        28 => pick(119, 128, 18, 69, 0, 0)?,
        // Floor_RaiseToLowestCeiling(tag, speed)
        238 => pick(5, 91, 101, 64, 0, 0)?,
        // Ceiling_LowerToFloor(tag, speed)
        43 => pick(0, 0, 41, 43, 0, 0)?,
        // Ceiling_CrushAndRaise / Ceiling_CrushRaiseAndStay(tag, speed, crush)
        42 | 45 => pick(25, 73, 49, 0, 0, 0)?,
        // Ceiling_CrushStop(tag)
        44 => pick(57, 74, 0, 0, 0, 0)?,
        // Stairs_BuildUpDoom(tag, speed, height)
        217 => pick(8, 0, 7, 0, 0, 0)?,
        // Exit_Normal / Exit_Secret
        243 => pick(52, 0, 11, 0, 0, 0)?,
        244 => pick(124, 0, 51, 0, 0, 0)?,
        // Teleport(tid, sector, nofog) uses TIDs: no Doom equivalent.
        _ => return None,
    };
    Some((s, tag))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_blocks() {
        let (ns, blocks) = parse(
            "namespace = \"zdoom\";\n// comment\nvertex { x = -16.5; y = 0x20; }\nlinedef // 0\n{ v1 = 0; blocking = true; arg0 = -3; }",
        )
        .unwrap();
        assert_eq!(ns, "zdoom");
        assert_eq!(blocks.len(), 2);
        assert_eq!(blocks[0].f("x", 0.0), -16.5);
        assert_eq!(blocks[0].i("y", 0), 32);
        assert!(blocks[1].b("blocking"));
        assert_eq!(blocks[1].i("arg0", 0), -3);
    }

    #[test]
    fn door_translation() {
        let (_, blocks) = parse("linedef { playeruse = true; repeatspecial = true; locknumber = 2; }").unwrap();
        assert_eq!(translate_special(12, [0, 16, 150, 0, 0], &blocks[0]), Some((26, 0)));
        let (_, blocks) = parse("linedef { playercross = true; }").unwrap();
        assert_eq!(translate_special(243, [0; 5], &blocks[0]), Some((52, 0)));
        assert_eq!(translate_special(62, [7, 32, 105, 0, 0], &blocks[0]), Some((10, 7)));
        assert_eq!(translate_special(70, [1, 0, 0, 0, 0], &blocks[0]), None);
    }
}

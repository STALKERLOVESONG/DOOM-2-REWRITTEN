//! The layered resource stack: every loaded container contributes lumps in
//! load order, and lookups resolve overrides.
//!
//! Two lookup models coexist, because both are part of the compatibility
//! target:
//!
//! * **Global lookup** ([`ResourceStack::check_num_for_name`]) is vanilla
//!   `W_CheckNumForName`: the *last loaded* lump with that name wins,
//!   regardless of markers. Used for PLAYPAL, COLORMAP, patches (via PNAMES),
//!   TEXTURE1/2, sounds, music, map markers, etc.
//!
//! * **Namespaces** ([`Namespace`]) are lump ranges delimited by markers
//!   (`S_START`/`S_END`, `F_START`/`F_END`, ...). Vanilla resolves the markers
//!   globally, so a PWAD with its own sprites or flats *replaces the whole
//!   range* and breaks the game unless the PWAD was merged with DeuSF/NWT.
//!   We do what Boom and ZDoom do instead: each file's marked ranges are
//!   merged into one list per namespace. A lump whose name already exists
//!   replaces the earlier entry **in place** (keeping its position, which
//!   matters for flat/texture animation ranges); new names are appended.
//!   For an unmodified IWAD this produces exactly the vanilla ordering.

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use crate::name::LumpName;
use crate::wad::{WadFile, WadKind};
use crate::ContentError;

/// Vanilla-style lump number: position in global load order.
#[derive(Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Debug)]
pub struct LumpId(pub u32);

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub enum Namespace {
    Global,
    Sprites,
    Flats,
    Patches,
    /// ZDoom `TX_START`: stand-alone textures (patch/PNG format).
    Textures,
    /// Boom `C_START`: extra colormaps.
    Colormaps,
    /// ZDoom `HI_START`: high-resolution replacements.
    Hires,
    /// ZDoom `A_START`: ACS libraries.
    Acs,
    /// ZDoom `V_START`: voxels.
    Voxels,
}

/// Marker -> (namespace, is_start). Sub-markers like `F1_START` are listed so
/// that they are recognised as markers rather than entries.
fn classify_marker(name: &LumpName) -> Option<(Namespace, bool)> {
    use Namespace::*;
    Some(match name.as_bytes() {
        b"S_START" | b"SS_START" => (Sprites, true),
        b"S_END" | b"SS_END" => (Sprites, false),
        b"F_START" | b"FF_START" => (Flats, true),
        b"F_END" | b"FF_END" => (Flats, false),
        b"P_START" | b"PP_START" => (Patches, true),
        b"P_END" | b"PP_END" => (Patches, false),
        b"TX_START" => (Textures, true),
        b"TX_END" => (Textures, false),
        b"C_START" => (Colormaps, true),
        b"C_END" => (Colormaps, false),
        b"HI_START" => (Hires, true),
        b"HI_END" => (Hires, false),
        b"A_START" => (Acs, true),
        b"A_END" => (Acs, false),
        b"V_START" => (Voxels, true),
        b"V_END" => (Voxels, false),
        _ => return None,
    })
}

/// Sub-range markers inside flat and patch namespaces (registered/retail IWADs).
fn is_sub_marker(name: &LumpName) -> bool {
    matches!(
        name.as_bytes(),
        b"F1_START" | b"F1_END" | b"F2_START" | b"F2_END" | b"F3_START" | b"F3_END"
            | b"P1_START" | b"P1_END" | b"P2_START" | b"P2_END" | b"P3_START" | b"P3_END"
    )
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum SourceKind {
    Iwad,
    Pwad,
}

pub struct Source {
    pub path: PathBuf,
    pub kind: SourceKind,
    data: Vec<u8>,
}

#[derive(Clone, Debug)]
pub struct LumpInfo {
    pub name: LumpName,
    pub source: usize,
    pub namespace: Namespace,
    offset: usize,
    size: usize,
}

#[derive(Default)]
struct NamespaceIndex {
    order: Vec<LumpId>,
    position: HashMap<LumpName, usize>,
}

impl NamespaceIndex {
    fn insert(&mut self, name: LumpName, id: LumpId) {
        match self.position.get(&name) {
            Some(&i) => self.order[i] = id,
            None => {
                self.position.insert(name, self.order.len());
                self.order.push(id);
            }
        }
    }
}

#[derive(Default)]
pub struct ResourceStack {
    sources: Vec<Source>,
    lumps: Vec<LumpInfo>,
    by_name: HashMap<LumpName, Vec<LumpId>>,
    namespaces: HashMap<Namespace, NamespaceIndex>,
    /// Non-fatal problems (bad directory entries, unbalanced markers, ...).
    pub warnings: Vec<String>,
}

impl ResourceStack {
    pub fn new() -> Self {
        Self::default()
    }

    /// Convenience: base IWAD followed by PWADs in order.
    pub fn load(iwad: &Path, pwads: &[PathBuf]) -> Result<Self, ContentError> {
        let mut s = Self::new();
        s.add_file(iwad)?;
        for p in pwads {
            s.add_file(p)?;
        }
        Ok(s)
    }

    /// Add a container. Only WADs are supported so far; PK3 is Phase 12.
    pub fn add_file(&mut self, path: &Path) -> Result<(), ContentError> {
        let ext = path.extension().and_then(|e| e.to_str()).map(str::to_ascii_lowercase);
        if matches!(ext.as_deref(), Some("pk3" | "pk7" | "zip" | "ipk3")) {
            return Err(ContentError::Unsupported {
                what: format!("{}", path.display()),
                reason: "PK3/ZIP containers are not implemented yet".into(),
            });
        }
        self.add_wad(WadFile::open(path)?);
        Ok(())
    }

    pub fn add_wad(&mut self, wad: WadFile) {
        let source = self.sources.len();
        self.warnings.extend(wad.warnings.iter().cloned());
        let mut open: Option<Namespace> = None;

        for e in &wad.entries {
            let id = LumpId(self.lumps.len() as u32);
            let mut namespace = open.unwrap_or(Namespace::Global);

            if let Some((ns, is_start)) = classify_marker(&e.name) {
                // Markers themselves are global lumps (vanilla finds them by name).
                namespace = Namespace::Global;
                match (is_start, open) {
                    (true, Some(cur)) => self.warnings.push(format!(
                        "{}: {} opened inside {cur:?} namespace; switching",
                        wad.path.display(),
                        e.name
                    )),
                    (false, Some(cur)) if cur != ns => self.warnings.push(format!(
                        "{}: {} closes {ns:?} but {cur:?} is open",
                        wad.path.display(),
                        e.name
                    )),
                    (false, None) => self.warnings.push(format!(
                        "{}: stray end marker {}",
                        wad.path.display(),
                        e.name
                    )),
                    _ => {}
                }
                open = if is_start { Some(ns) } else { None };
            } else if open.is_some() && is_sub_marker(&e.name) {
                // Vanilla numbers flats as `lumpnum - firstflat` over the whole
                // F_START..F_END range, so F1_START etc. occupy flat numbers.
                // That matters: P_UpdateSpecials uses the absolute flat number
                // in `(leveltime / speed + i) % numpics`, so dropping the
                // sub-markers shifts every flat animation's phase.
                if open == Some(Namespace::Flats) {
                    self.namespaces.entry(Namespace::Flats).or_default().insert(e.name, id);
                } else {
                    namespace = Namespace::Global;
                }
            } else if namespace != Namespace::Global {
                self.namespaces.entry(namespace).or_default().insert(e.name, id);
            }

            self.by_name.entry(e.name).or_default().push(id);
            self.lumps.push(LumpInfo { name: e.name, source, namespace, offset: e.offset, size: e.size });
        }
        if let Some(ns) = open {
            self.warnings.push(format!("{}: {ns:?} namespace is never closed", wad.path.display()));
        }

        self.sources.push(Source {
            path: wad.path,
            kind: match wad.kind {
                WadKind::Iwad => SourceKind::Iwad,
                WadKind::Pwad => SourceKind::Pwad,
            },
            data: wad.data,
        });
    }

    pub fn sources(&self) -> &[Source] {
        &self.sources
    }

    pub fn num_lumps(&self) -> usize {
        self.lumps.len()
    }

    pub fn info(&self, id: LumpId) -> &LumpInfo {
        &self.lumps[id.0 as usize]
    }

    pub fn data(&self, id: LumpId) -> &[u8] {
        let l = &self.lumps[id.0 as usize];
        &self.sources[l.source].data[l.offset..l.offset + l.size]
    }

    /// `W_CheckNumForName`: last loaded lump with this name, any namespace.
    pub fn check_num_for_name(&self, name: &str) -> Option<LumpId> {
        self.check_num(LumpName::new(name))
    }

    pub fn check_num(&self, name: LumpName) -> Option<LumpId> {
        self.by_name.get(&name).and_then(|v| v.last().copied())
    }

    /// Lump data by name with global (vanilla) resolution.
    pub fn lump(&self, name: &str) -> Option<&[u8]> {
        self.check_num_for_name(name).map(|id| self.data(id))
    }

    pub fn require(&self, name: &str) -> Result<&[u8], ContentError> {
        self.lump(name).ok_or_else(|| ContentError::MissingLump(name.to_ascii_uppercase()))
    }

    /// All lumps with this name in load order (used for lumps that stack,
    /// e.g. ZDoom's DECORATE or multiple TEXTURE lumps).
    pub fn all_named(&self, name: &str) -> &[LumpId] {
        self.by_name.get(&LumpName::new(name)).map_or(&[], Vec::as_slice)
    }

    /// Merged contents of a namespace, in stable order (see module docs).
    pub fn namespace(&self, ns: Namespace) -> &[LumpId] {
        self.namespaces.get(&ns).map_or(&[], |n| n.order.as_slice())
    }

    /// Position of `name` inside a merged namespace (the "flat number" etc.).
    pub fn namespace_index(&self, ns: Namespace, name: LumpName) -> Option<usize> {
        self.namespaces.get(&ns)?.position.get(&name).copied()
    }

    /// Lump id for `name` inside a namespace.
    pub fn find_in(&self, ns: Namespace, name: LumpName) -> Option<LumpId> {
        let n = self.namespaces.get(&ns)?;
        n.position.get(&name).map(|&i| n.order[i])
    }

    /// The lump that follows `id` in its source file (map lumps are positional).
    pub fn next_in_source(&self, id: LumpId) -> Option<LumpId> {
        let next = LumpId(id.0 + 1);
        let l = self.lumps.get(next.0 as usize)?;
        (l.source == self.lumps[id.0 as usize].source).then_some(next)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::wad::tests::build_wad;

    fn stack(files: &[Vec<u8>]) -> ResourceStack {
        let mut s = ResourceStack::new();
        for (i, f) in files.iter().enumerate() {
            s.add_wad(WadFile::parse(format!("{i}.wad").into(), f.clone()).unwrap());
        }
        s
    }

    #[test]
    fn global_last_wins() {
        let a = build_wad(b"IWAD", &[("PLAYPAL", b"iwad")]);
        let b = build_wad(b"PWAD", &[("PLAYPAL", b"pwad")]);
        let s = stack(&[a, b]);
        assert_eq!(s.lump("playpal").unwrap(), b"pwad");
        assert_eq!(s.all_named("PLAYPAL").len(), 2);
    }

    #[test]
    fn namespaces_merge_in_place() {
        let a = build_wad(
            b"IWAD",
            &[("F_START", b""), ("F1_START", b""), ("NUKAGE1", b"a"), ("NUKAGE2", b"b"), ("NUKAGE3", b"c"), ("F1_END", b""), ("F_END", b"")],
        );
        let b = build_wad(b"PWAD", &[("FF_START", b""), ("NUKAGE2", b"B"), ("NEWFLAT", b"n"), ("FF_END", b"")]);
        let s = stack(&[a, b]);
        let names: Vec<_> = s.namespace(Namespace::Flats).iter().map(|&id| s.data(id).to_vec()).collect();
        // Sub-markers keep their vanilla flat numbers (empty entries).
        assert_eq!(names, vec![b"".to_vec(), b"a".to_vec(), b"B".to_vec(), b"c".to_vec(), b"".to_vec(), b"n".to_vec()]);
        assert_eq!(s.namespace_index(Namespace::Flats, LumpName::new("NUKAGE3")), Some(3));
        assert!(s.warnings.is_empty(), "{:?}", s.warnings);
    }

    #[test]
    fn markers_are_global() {
        let a = build_wad(b"IWAD", &[("S_START", b""), ("TROOA1", b"x"), ("S_END", b"")]);
        let s = stack(&[a]);
        assert!(s.check_num_for_name("S_START").is_some());
        assert_eq!(s.namespace(Namespace::Sprites).len(), 1);
    }
}

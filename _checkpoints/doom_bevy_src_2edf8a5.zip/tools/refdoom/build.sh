#!/bin/sh
# Build the headless reference binary from a Chocolate Doom checkout.
# Usage: tools/refdoom/build.sh <chocolate-doom checkout> [output]
set -e
CHOCO=${1:?usage: $0 <chocolate-doom checkout> [output]}/src
OUT=${2:-refdoom}
HERE=$(cd "$(dirname "$0")" && pwd)
OBJ=$(mktemp -d)
CFLAGS="-O1 -fwrapv -w -I$HERE -I$HERE/sdlstub -I$CHOCO -I$CHOCO/doom"
SKIP='/(i_[a-z]*|net_sdl|aes_prng|midifile|mus2mid|gusconf|d_dedicated|net_dedicated|net_gui|net_server|net_client|net_query|net_common|net_io|net_loop|net_packet|net_structrw|net_petname|z_native|w_file_win32|statdump|midifallback)\.c$'
for f in $(ls "$CHOCO"/doom/*.c) $(ls "$CHOCO"/*.c | grep -v -E "$SKIP"); do
    extra=""
    case "$f" in */doom/g_game.c) extra="-DG_Ticker=G_Ticker_real";; esac
    cc -c $CFLAGS $extra "$f" -o "$OBJ/$(basename "$f" .c).o"
done
cc -c $CFLAGS "$HERE/refdoom_stubs.c" -o "$OBJ/refdoom_stubs.o"
cc -c $CFLAGS "$HERE/refdoom_main.c" -o "$OBJ/refdoom_main.o"
cc "$OBJ"/*.o -lm -o "$OUT"
rm -rf "$OBJ"
echo "built $OUT"

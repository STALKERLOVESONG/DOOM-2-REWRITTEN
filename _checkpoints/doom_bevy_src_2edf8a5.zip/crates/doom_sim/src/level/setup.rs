//! `P_SetupLevel` data loading: `P_LoadBlockMap`, `P_LoadVertexes`,
//! `P_LoadSectors`, `P_LoadSideDefs`, `P_LoadLineDefs`, `P_LoadSubsectors`,
//! `P_LoadNodes`, `P_LoadSegs`, `P_GroupLines`, `P_LoadReject`.
//!
//! Thing spawning (`P_LoadThings`) and `P_SpawnSpecials` belong to the
//! playsim and run after this.
//!
//! Where vanilla would dereference an out-of-range index (crash or garbage)
//! we return an error instead; this never rejects a map vanilla can run.

use std::fmt;

use doom_content::map::{RawMap, NO_SIDEDEF};
use doom_content::texture::TextureSet;
use doom_content::{ContentError, LumpName, Namespace, ResourceStack};
use doom_core::bbox::{BOXBOTTOM, BOXLEFT, BOXRIGHT, BOXTOP};
use doom_core::{Angle, BBox, Fixed};

use super::*;

#[derive(Debug)]
pub enum LevelLoadError {
    Content(ContentError),
    Invalid { map: String, reason: String },
}

impl fmt::Display for LevelLoadError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Content(e) => e.fmt(f),
            Self::Invalid { map, reason } => write!(f, "map {map} is invalid: {reason}"),
        }
    }
}

impl std::error::Error for LevelLoadError {}

impl From<ContentError> for LevelLoadError {
    fn from(e: ContentError) -> Self {
        Self::Content(e)
    }
}

/// Content needed to resolve texture and flat names to numbers.
pub struct LevelResources<'a> {
    pub stack: &'a ResourceStack,
    pub textures: &'a TextureSet,
}

impl LevelResources<'_> {
    /// `R_FlatNumForName`, resolved in the merged flat namespace.
    fn flat_num(&self, name: LumpName, warnings: &mut Vec<String>) -> FlatNum {
        match self.stack.namespace_index(Namespace::Flats, name) {
            Some(i) => FlatNum(i as u16),
            None => {
                warnings.push(format!("flat {name} not found"));
                FlatNum::MISSING
            }
        }
    }

    /// `R_TextureNumForName`. Missing textures become 0 ("no texture") with a
    /// warning; vanilla aborts.
    fn tex_num(&self, name: LumpName, warnings: &mut Vec<String>) -> TexNum {
        match self.textures.check_num(name) {
            Some(i) => TexNum(i as u16),
            None => {
                warnings.push(format!("texture {name} not found"));
                TexNum(0)
            }
        }
    }
}

/// Floor/ceiling of the "null sector" read through a NULL pointer by the
/// glass-hack (two-sided line without a back sidedef). These are the bytes
/// Chocolate Doom's default DOS 7.1 memory emulation returns for offsets 0
/// and 4.
const NULL_SECTOR_FLOOR: Fixed = Fixed(0x00C9_0F9E);
const NULL_SECTOR_CEILING: Fixed = Fixed(0x0070_0465);

impl Level {
    pub fn load(stack: &ResourceStack, textures: &TextureSet, map: &str) -> Result<Self, LevelLoadError> {
        let raw = RawMap::load(stack, map)?;
        Self::from_raw(&raw, &LevelResources { stack, textures })
    }

    pub fn from_raw(raw: &RawMap, res: &LevelResources) -> Result<Self, LevelLoadError> {
        let map = raw.name.to_string();
        let invalid = |reason: String| LevelLoadError::Invalid { map: map.clone(), reason };
        let mut warnings = raw.warnings.clone();

        // --- P_LoadBlockMap -------------------------------------------------
        if raw.blockmap.len() < 4 {
            // Boom and later build a blockmap when it is missing; vanilla
            // cannot. TODO(phase 5): blockmap builder for modern maps.
            return Err(LevelLoadError::Content(ContentError::Unsupported {
                what: format!("map {map}"),
                reason: "missing BLOCKMAP (blockmap builder not implemented)".into(),
            }));
        }
        let (bw, bh) = (raw.blockmap[2] as i32, raw.blockmap[3] as i32);
        if bw <= 0 || bh <= 0 || raw.blockmap.len() < 4 + (bw * bh) as usize {
            return Err(invalid(format!("BLOCKMAP header {bw}x{bh} does not fit the lump")));
        }
        let blockmap = Blockmap {
            org_x: Fixed::from_int(raw.blockmap[0] as i32),
            org_y: Fixed::from_int(raw.blockmap[1] as i32),
            width: bw,
            height: bh,
            lump: raw.blockmap.clone(),
            links: vec![None; (bw * bh) as usize],
        };

        // --- P_LoadVertexes -------------------------------------------------
        let vertexes: Vec<Vertex> = raw
            .vertexes
            .iter()
            .map(|v| Vertex { x: Fixed::from_int(v.x as i32), y: Fixed::from_int(v.y as i32) })
            .collect();

        // --- P_LoadSectors --------------------------------------------------
        let mut sectors: Vec<Sector> = raw
            .sectors
            .iter()
            .map(|s| Sector {
                floor_height: Fixed::from_int(s.floor_height as i32),
                ceiling_height: Fixed::from_int(s.ceiling_height as i32),
                floor_pic: res.flat_num(s.floor_pic, &mut warnings),
                ceiling_pic: res.flat_num(s.ceiling_pic, &mut warnings),
                light_level: s.light_level,
                special: s.special,
                tag: s.tag,
                sound_traversed: 0,
                sound_target: None,
                blockbox: [0; 4],
                sound_org: SoundOrigin::default(),
                thing_list: None,
                special_data: None,
                lines_start: 0,
                line_count: 0,
            })
            .collect();
        let num_map_sectors = sectors.len();

        // --- P_LoadSideDefs -------------------------------------------------
        let mut sides = Vec::with_capacity(raw.sidedefs.len());
        for (i, s) in raw.sidedefs.iter().enumerate() {
            if s.sector as usize >= num_map_sectors {
                return Err(invalid(format!("sidedef {i} references missing sector {}", s.sector)));
            }
            sides.push(Side {
                texture_offset: Fixed::from_int(s.texture_offset as i32),
                row_offset: Fixed::from_int(s.row_offset as i32),
                top_texture: res.tex_num(s.top, &mut warnings),
                bottom_texture: res.tex_num(s.bottom, &mut warnings),
                mid_texture: res.tex_num(s.mid, &mut warnings),
                sector: SectorId(s.sector as u32),
            });
        }

        // --- P_LoadLineDefs -------------------------------------------------
        let side_ref = |n: u16| (n != NO_SIDEDEF).then_some(n as usize);
        let mut lines = Vec::with_capacity(raw.linedefs.len());
        for (i, l) in raw.linedefs.iter().enumerate() {
            let (Some(&a), Some(&b)) = (vertexes.get(l.v1 as usize), vertexes.get(l.v2 as usize)) else {
                return Err(invalid(format!("linedef {i} references a missing vertex")));
            };
            let dx = b.x - a.x;
            let dy = b.y - a.y;
            let slope_type = if dx.0 == 0 {
                SlopeType::Vertical
            } else if dy.0 == 0 {
                SlopeType::Horizontal
            } else if (dy / dx).0 > 0 {
                SlopeType::Positive
            } else {
                SlopeType::Negative
            };
            let mut bbox = BBox::cleared();
            (bbox.0[BOXLEFT], bbox.0[BOXRIGHT]) = if a.x < b.x { (a.x, b.x) } else { (b.x, a.x) };
            (bbox.0[BOXBOTTOM], bbox.0[BOXTOP]) = if a.y < b.y { (a.y, b.y) } else { (b.y, a.y) };

            let mut sidenum = [None; 2];
            for k in 0..2 {
                if let Some(s) = side_ref(l.sidenum[k]) {
                    if s >= sides.len() {
                        return Err(invalid(format!("linedef {i} references missing sidedef {s}")));
                    }
                    sidenum[k] = Some(SideId(s as u32));
                }
            }
            let Some(front) = sidenum[0] else {
                // Vanilla dereferences NULL in P_GroupLines.
                return Err(invalid(format!("linedef {i} has no front sidedef")));
            };
            lines.push(Line {
                v1: VertexId(l.v1 as u32),
                v2: VertexId(l.v2 as u32),
                dx,
                dy,
                flags: l.flags,
                special: l.special,
                tag: l.tag,
                sidenum,
                bbox,
                slope_type,
                front_sector: Some(sides[front.idx()].sector),
                back_sector: sidenum[1].map(|s| sides[s.idx()].sector),
                special_data: None,
            });
        }

        // --- P_LoadSubsectors / P_LoadNodes ----------------------------------
        let mut subsectors = Vec::with_capacity(raw.subsectors.len());
        for (i, s) in raw.subsectors.iter().enumerate() {
            if s.num_segs == 0 || s.first_seg as usize + s.num_segs as usize > raw.segs.len() {
                return Err(invalid(format!("subsector {i} has an invalid seg range")));
            }
            subsectors.push(Subsector { sector: SectorId(0), num_lines: s.num_segs, first_line: s.first_seg });
        }
        let mut nodes = Vec::with_capacity(raw.nodes.len());
        for (i, n) in raw.nodes.iter().enumerate() {
            for &c in &n.children {
                let ok = if c & NF_SUBSECTOR != 0 {
                    ((c & !NF_SUBSECTOR) as usize) < subsectors.len()
                } else {
                    (c as usize) < raw.nodes.len()
                };
                if !ok {
                    return Err(invalid(format!("node {i} has an out-of-range child {c:#06x}")));
                }
            }
            let bb = |b: [i16; 4]| BBox(b.map(|v| Fixed::from_int(v as i32)));
            nodes.push(Node {
                x: Fixed::from_int(n.x as i32),
                y: Fixed::from_int(n.y as i32),
                dx: Fixed::from_int(n.dx as i32),
                dy: Fixed::from_int(n.dy as i32),
                bbox: [bb(n.bbox[0]), bb(n.bbox[1])],
                children: n.children,
            });
        }

        // --- P_LoadSegs ------------------------------------------------------
        let mut null_sector = None;
        let mut segs = Vec::with_capacity(raw.segs.len());
        for (i, s) in raw.segs.iter().enumerate() {
            if s.v1 as usize >= vertexes.len() || s.v2 as usize >= vertexes.len() {
                return Err(invalid(format!("seg {i} references a missing vertex")));
            }
            let Some(ldef) = lines.get(s.linedef as usize) else {
                return Err(invalid(format!("seg {i} references missing linedef {}", s.linedef)));
            };
            // Vanilla indexes sidenum[side] with whatever `side` holds; only
            // 0 and 1 are meaningful.
            let side = (s.side & 1) as usize;
            if s.side != side as i16 {
                warnings.push(format!("seg {i} has side value {}", s.side));
            }
            let Some(sidedef) = ldef.sidenum[side] else {
                return Err(invalid(format!(
                    "linedef {} for seg {i} references a non-existent sidedef",
                    s.linedef
                )));
            };
            let back_sector = if ldef.flags & doom_content::map::ml::TWOSIDED != 0 {
                match ldef.sidenum[side ^ 1] {
                    Some(b) => Some(sides[b.idx()].sector),
                    None => {
                        // "Glass hack": see Seg::back_sector.
                        Some(*null_sector.get_or_insert(SectorId(num_map_sectors as u32)))
                    }
                }
            } else {
                None
            };
            segs.push(Seg {
                v1: VertexId(s.v1 as u32),
                v2: VertexId(s.v2 as u32),
                // `SHORT(angle) << FRACBITS` into an unsigned angle_t.
                angle: Angle(((s.angle as i32) << 16) as u32),
                offset: Fixed::from_int(s.offset as i32),
                sidedef,
                linedef: LineId(s.linedef as u32),
                front_sector: sides[sidedef.idx()].sector,
                back_sector,
            });
        }
        if let Some(id) = null_sector {
            warnings.push("two-sided line without back sidedef (glass hack); using emulated null sector".into());
            debug_assert_eq!(id.idx(), sectors.len());
            sectors.push(Sector {
                floor_height: NULL_SECTOR_FLOOR,
                ceiling_height: NULL_SECTOR_CEILING,
                floor_pic: FlatNum(0),
                ceiling_pic: FlatNum(0),
                light_level: 0,
                special: 0,
                tag: 0,
                sound_traversed: 0,
                sound_target: None,
                blockbox: [0; 4],
                sound_org: SoundOrigin::default(),
                thing_list: None,
                special_data: None,
                lines_start: 0,
                line_count: 0,
            });
        }

        // --- P_GroupLines ----------------------------------------------------
        for ss in &mut subsectors {
            ss.sector = sides[segs[ss.first_line as usize].sidedef.idx()].sector;
        }
        let mut counts = vec![0u32; sectors.len()];
        for l in &lines {
            counts[l.front_sector.unwrap().idx()] += 1;
            if let Some(b) = l.back_sector {
                if Some(b) != l.front_sector {
                    counts[b.idx()] += 1;
                }
            }
        }
        let mut start = 0;
        for (s, &c) in sectors.iter_mut().zip(&counts) {
            s.lines_start = start;
            start += c;
        }
        let mut sector_lines = vec![LineId(0); start as usize];
        for (i, l) in lines.iter().enumerate() {
            let mut push = |s: SectorId| {
                let sec = &mut sectors[s.idx()];
                sector_lines[(sec.lines_start + sec.line_count) as usize] = LineId(i as u32);
                sec.line_count += 1;
            };
            let front = l.front_sector.unwrap();
            push(front);
            if let Some(b) = l.back_sector {
                if b != front {
                    push(b);
                }
            }
        }
        for s in sectors.iter_mut() {
            let mut bbox = BBox::cleared();
            for &li in &sector_lines[s.lines_start as usize..(s.lines_start + s.line_count) as usize] {
                let l = &lines[li.idx()];
                let (a, b) = (vertexes[l.v1.idx()], vertexes[l.v2.idx()]);
                bbox.add_point(a.x, a.y);
                bbox.add_point(b.x, b.y);
            }
            s.sound_org.x = (bbox.right() + bbox.left()) / 2;
            s.sound_org.y = (bbox.top() + bbox.bottom()) / 2;

            let (ox, oy) = (blockmap.org_x, blockmap.org_y);
            let block = |v: Fixed| v.0 >> MAPBLOCKSHIFT;
            s.blockbox[BOXTOP] = block(bbox.top() - oy + MAXRADIUS).min(bh - 1);
            s.blockbox[BOXBOTTOM] = block(bbox.bottom() - oy - MAXRADIUS).max(0);
            s.blockbox[BOXRIGHT] = block(bbox.right() - ox + MAXRADIUS).min(bw - 1);
            s.blockbox[BOXLEFT] = block(bbox.left() - ox - MAXRADIUS).max(0);
        }

        // --- P_LoadReject ----------------------------------------------------
        let total_lines = lines
            .iter()
            .map(|l| 1 + (l.back_sector.is_some() && l.back_sector != l.front_sector) as usize)
            .sum::<usize>();
        let reject = pad_reject(&raw.reject, num_map_sectors, total_lines, &mut warnings);

        let valid = ValidCount::new(lines.len(), sectors.len());
        let sky_flat = res.stack.namespace_index(Namespace::Flats, LumpName::new("F_SKY1")).map_or(FlatNum::MISSING, |i| FlatNum(i as u16));
        Ok(Level {
            name: map,
            vertexes,
            sectors,
            sides,
            lines,
            segs,
            subsectors,
            nodes,
            blockmap,
            reject,
            sector_lines,
            null_sector,
            valid,
            sky_flat,
            things: raw.things.clone(),
            warnings,
        })
    }
}

/// `P_LoadReject` + `PadRejectArray`: a short REJECT lump is extended with the
/// bytes vanilla would have read from the zone memory that follows it.
fn pad_reject(lump: &[u8], num_sectors: usize, total_lines: usize, warnings: &mut Vec<String>) -> Vec<u8> {
    let min_len = (num_sectors * num_sectors).div_ceil(8);
    let mut out = lump.to_vec();
    if out.len() >= min_len {
        return out;
    }
    warnings.push(format!("REJECT is {} bytes, expected {min_len}; padded", lump.len()));
    let pad: [u32; 4] = [
        (((total_lines * 4 + 3) & !3) + 24) as u32, // zone block size
        0,                                          // part of the zone block header
        50,                                         // PU_LEVEL
        0x1d4a11,                                   // ZONEID
    ];
    let len = min_len - out.len();
    for i in 0..len {
        if i < 16 {
            out.push((pad[i / 4] >> ((i % 4) * 8)) as u8);
        } else {
            out.push(0); // Chocolate's default beyond the emulated header
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reject_padding_matches_chocolate() {
        let mut w = Vec::new();
        let r = pad_reject(&[], 9, 10, &mut w); // 81 bits -> 11 bytes
        assert_eq!(r.len(), 11);
        // size = ((10*4+3)&~3)+24 = 64
        assert_eq!(&r[..8], &[64, 0, 0, 0, 0, 0, 0, 0]);
        assert_eq!(&r[8..11], &[50, 0, 0]);
    }
}
